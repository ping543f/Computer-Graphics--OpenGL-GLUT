**NOTE: CONTRIBUTORS, DO NOT CHANGE README. CHECK FOR YOUR TASKS IN BACKLOG.md (if any)**

# Orbit

The  game concept is like shooting some objects in the space which will rotate and translate along with the orbits of the planets, moon and sun. The game score will evaluate by calculating the total time taken for the object to collide with the planets, moon and sun.

## Resources and Developments

This game is developing by using OpenGl libraries. All the sources are written in c++ programming language.
