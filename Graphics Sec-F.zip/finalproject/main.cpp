// Rahman , Md. Mustafizur (15-28953-1)  sec :F

// Saha , Tonmoy (1528961-1) sec:F



#include<windows.h>
#include<gl/glut.h>
#include<stdio.h>
#include<stdio.h>
#include <iostream>

using namespace std;
#include<string.h>


void displayloop(void);
void pscore(void);

int tt=0;
int ttt=0;
int w,count=0,gflag=0,lev1=0,lev2=0,lev3=0,lev4=0,lev5=0,lev6=0;
float x=0,a=7.5,b=8.0,c=6.5,d=8,e=14.5,f=15.0,g=13.5,h=15,flag=0,m,n;
float i=0,j=7.5,k=15;
float p=0.0,q=0.5,r=2.0,s=2.5,t=3.0;
int sel,fl,crash=0,rem=0,z=0;
int score=0,sco,mx,my;
float aa=1.0,bb=4.0,cc=6.0,dd=9.0,ee=11.0,ff=14.0,gg=16,hh=19.0,pos[10],ss=11.75,zz,yy,lx,ly;
int rr,road=0,entered=0,sel_map=0,sel_level=0,sel_inst=0,line=1,hp_menu,screen=1;

int y,mm,nn;
char game[70]={"Mini Car Run"};

char c1[20]={"Current level"};
char player[36];
char strt[7]={"START"};
char help[6]={""};
char s_game[30]={"START THE GAME"};
char map[30]={"MAP SELECTION"};
char level[30]={"LEVEL SELECTION"};





char back[50]={"Press b to go back"};


char map1[20]={"RACE TRACK"};
char map2[20]={"GRASS LAND"};
char map3[20]={"ICE LAND"};




char level1[15]={"LEVEL 1"};
char level2[15]={"LEVEL 2"};
char level3[15]={"LEVEL 3"};
char level4[15]={"LEVEL 4"};
char level5[15]={"LEVEL 5"};
char level6[15]={"LEVEL 6"};





char name[20]={"CRASH"};
char sc[20]={"Ur score is: "};
char go[20]={"GAME OVER"};
char es[20]={"Press ESC to exit"};
char back2[30]={"press b or B to go back"};




void display(void)
{glClearColor(0.1,0.1,0.13,0.0);
if (gflag==0)                       //for first screen in the output.
{
glClear(GL_COLOR_BUFFER_BIT);


           glColor3f(1,0,0);
glRasterPos2f(5,13.0);                       //displaying game name


                      //displaying game name
for(w=0;w<sizeof(game);w++)
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,game[w]);


            glColor3f(1,0,0);
glRasterPos2f(6,2);                       //displaying game name



            glColor3f(0.5,0.5,0.5);
glRasterPos2f(6,1.5);                        //display start game at the left side

glColor3f(0.5,0.5,0.5);
glRasterPos2f(2.5,9.0);                        //display start game at the left side
for(w=0;w<sizeof(s_game);w++)
glutBitmapCharacter(GLUT_BITMAP_9_BY_15,s_game[w]);


glColor3f(0.5,0.5,0.5);
glRasterPos2f(2.5,8);                         //displays "map selectionn"
for(w=0;w<sizeof(map);w++)
glutBitmapCharacter(GLUT_BITMAP_9_BY_15,map[w]);


glColor3f(0.5,0.5,0.5);
glRasterPos2f(2.5,7.0);                            //displays "level"
for(w=0;w<sizeof(level);w++)
glutBitmapCharacter(GLUT_BITMAP_9_BY_15,level[w]);






glColor3f(.7,0.7,0.7);
glRectf(5.5,9,6.5,9.5);


glColor3f(0.7,0.7,.7);


for ( m=0;m<4.5;m+=1.5)
glRectf(5.5+m,8,6.5+m,8.5);
glColor3f(0.7,0.7,.7);
for ( n=0;n<9;n+=1.5)
glRectf(5.5+n,7,6.5+n,7.5);
glColor3f(0.7,0.7,.7);



glColor3f(.9,0.3,0.3);       //selecting option shows in color
glRectf(5.5+lx,9+ly,6.5+lx,9.5+ly);


glColor3f(0.0,0.0,0.0);
glRasterPos2f(5.7,9.2);
for(w=0;w<sizeof(strt);w++)      //display start
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,strt[w]);


glColor3f(0.0,0.0,0.0);
glRasterPos2f(5.55,8.2);
for(w=0;w<sizeof(map1);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,map1[w]);
glColor3f(0.0,0.0,0.0);
glRasterPos2f(7.05,8.2);
for(w=0;w<sizeof(map2);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,map2[w]);


glRasterPos2f(8.65,8.2);
for(w=0;w<sizeof(map3);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,map3[w]);


glColor3f(1,1,1);
glBegin(GL_LINE_LOOP);
glVertex2f(5.85+zz,8.65);    //displaying right mark  coressponding to map selected
glVertex2f(6+zz,8.5);
glVertex2f(6.4+zz,8.9);
glVertex2f(6+zz,8.55);
glEnd();
glColor3f(1,1,1);
glBegin(GL_LINE_LOOP);
glVertex2f(5.85+yy,7.65);   //displaying right mark.corresponding to level selected
glVertex2f(6+yy,7.5);
glVertex2f(6.4+yy,7.9);
glVertex2f(6+yy,7.55);
glEnd();


glColor3f(0.0,0.0,0.0);
glRasterPos2f(5.7,7.2);
for(w=0;w<sizeof(level1);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,level1[w]);//displaying level 1


glColor3f(0.0,0.0,0.0);
glRasterPos2f(7.2,7.2);
for(w=0;w<sizeof(level2);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,level2[w]);
glColor3f(0.0,0.0,0.0);
glRasterPos2f(8.7,7.2);
for(w=0;w<sizeof(level3);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,level3[w]);


glRasterPos2f(10.2,7.2);
for(w=0;w<sizeof(level4);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,level4[w]);



glRasterPos2f(11.7,7.2);
for(w=0;w<sizeof(level5);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,level5[w]);


glRasterPos2f(13.2,7.2);
for(w=0;w<sizeof(level6);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12,level6[w]);










}




if(gflag==1 && crash==0)
{
glClear(GL_COLOR_BUFFER_BIT);


if (zz==0)
{
glColor3f(0.6,0.6,0.6);
glRectf(0.1,0,0.5,15);


glColor3f(0.6,0.6,0.6);
glRectf(8.6,0,9,15);


glBegin(GL_LINES);
glColor3f(0.0,0.0,0.0);
glVertex2f(0.1,0.0); //lines
glVertex2f(0.1,15.0);


glVertex2f(0.5,0.0);
glVertex2f(0.5,15.0);


glVertex2f(8.6,0.0);
glVertex2f(8.6,15.0);


glVertex2f(9.0,0.0);
glVertex2f(9.0,15.0); //lines



for( y=0;y<15;y++) //shading
{
glVertex2f(0.1,y);
glVertex2f(0.5,y+1);
}


for( y=0;y<15;y++)
{
glVertex2f(8.6,y);
glVertex2f(9.0,y+1); //shading
}
glEnd();
glColor3f(1.0,1.0,1.0); //middle rectangle
    glRectf(4.2,aa,4.8,aa+3);
glRectf(4.2,cc,4.8,cc+3);
glRectf(4.2,ee,4.8,ee+3);
glRectf(4.2,gg,4.8,gg+3);

}


else if(zz==1.5)
{

glColor3f(0,1,0);

glRectf(0,0,9,15);

glColor3f(0.6,0.6,0.6);
glRectf(0.1,0,0.5,15);


glColor3f(0.6,0.6,0.6);
glRectf(8.6,0,9,15);

glBegin(GL_LINES);
glColor3f(0.0,0.0,0.0);
glVertex2f(0.1,0.0); //lines
glVertex2f(0.1,15.0);


glVertex2f(0.5,0.0);
glVertex2f(0.5,15.0);


glVertex2f(8.6,0.0);
glVertex2f(8.6,15.0);


glVertex2f(9.0,0.0);
glVertex2f(9.0,15.0); //lines


//glColor3f(0.0,0.0,0.0);
for( y=0;y<15;y++) //shading
{
glVertex2f(0.1,y);
glVertex2f(0.5,y+1);
}


for( y=0;y<15;y++)
{
glVertex2f(8.6,y);
glVertex2f(9.0,y+1); //shading
}
glEnd();







}


else
{
glColor3f(1,1,1);
glRectf(0,0,9,15);

glColor3f(0.6,0.6,0.6);
glRectf(0.1,0,0.5,15);


glColor3f(0.6,0.6,0.6);
glRectf(8.6,0,9,15);

glBegin(GL_LINES);
glColor3f(0.0,0.0,0.0);
glVertex2f(0.1,0.0); //lines
glVertex2f(0.1,15.0);


glVertex2f(0.5,0.0);
glVertex2f(0.5,15.0);


glVertex2f(8.6,0.0);
glVertex2f(8.6,15.0);


glVertex2f(9.0,0.0);
glVertex2f(9.0,15.0); //lines


//glColor3f(0.0,0.0,0.0);
for( y=0;y<15;y++) //shading
{
glVertex2f(0.1,y);
glVertex2f(0.5,y+1);
}


for( y=0;y<15;y++)
{
glVertex2f(8.6,y);
glVertex2f(9.0,y+1); //shading
}
glEnd();


}


glColor3f(.9,.3,.3);
glRectf(9,0,9.2,15);
glRectf(9,14.8,15,15);
glRectf(14.8,0,15,15);
glRectf(9,0,15,.2);

     glPointSize(10.0);
    glBegin(GL_POINTS);//tire
        glColor3f(0,0,0);
        glVertex2f(2+x,3+tt);
          glVertex2f(2+x,2+tt);
         glVertex2f(3+x,2+tt);
         glVertex2f(3+x,3+tt);
    glEnd();

  glBegin(GL_QUADS);
        glColor3f(0.73,0.23,0.15);//middle body
          glVertex2f(2+x,3+tt);
          glVertex2f(2+x,2+tt);
         glVertex2f(3+x,2+tt);
         glVertex2f(3+x,3+tt);

    glEnd();


 glBegin(GL_QUADS);//up body
        glColor3f(0,0,1);
        glVertex2f(2.25+x,3.5+tt);
        glVertex2f(2+x,3+tt);
        glVertex2f(3+x,3+tt);
        glVertex2f(2.75+x,3.5+tt);
    glEnd();

    glBegin(GL_QUADS);//down body
        glColor3f(0,0,1);
        glVertex2f(2+x,2+tt);
        glVertex2f(2.25+x,1.5+tt);
        glVertex2f(2.75+x,1.5+tt);
        glVertex2f(3+x,2+tt);
    glEnd();







//making of car ended


if (aa<-3 )     aa=17.0;
if (cc<-3 )     cc=17.0;
if (ee<-3 )     ee=17.0;
if (gg<-3)      gg=17.0;
if (i<-7.5)     i=15;
if (j<-7.5)     j=15;
if (k<-7.5)     k=15;
if (f<.1)                 //Recreating the obstacle 1
{
e=14.5; f=15; g=13.5; h=15;

if (sel==1) score+=100;


if (sel==2) score+=200;


if (sel==3) score+=300;


if (sel==4) score+=400;


if (sel==5) score+=500;


if (sel==6) score+=600;
}


if (b<.1) //Recreating the obstacle 2
{
a=14.5; b=15; c=13.5; d=15;
if (sel==1) score+=100;


if (sel==2) score+=200;


if (sel==3) score+=300;


if (sel==4) score+=400;


if (sel==5) score+=500;


if (sel==6) score+=600;
}

if (zz==0)   glColor3f(.6,.6,.6);
if (zz==1.5)   glColor3f(0.7,1,0.5); //static obstacles
if (zz==3)   glColor3f(0.7,0.1,0.9);
glRectf(5.0,a,8.0,b);



glBegin(GL_TRIANGLES);
glVertex2f(5,d);
glVertex2f(5.5,c);
glVertex2f(6,d);
glVertex2f(6,d);
glVertex2f(6.5,c);
glVertex2f(7,d);
glVertex2f(7,d);
glVertex2f(7.5,c);
glVertex2f(8,d);
glEnd();


glRectf(1.0,e,4.0,f); //static obstacles
glBegin(GL_TRIANGLES);
glVertex2f(1,h);
glVertex2f(1.5,g);
glVertex2f(2,h);
glVertex2f(2,h);
glVertex2f(2.5,g);
glVertex2f(3,h);
glVertex2f(3,h);
glVertex2f(3.5,g);
glVertex2f(4,h);
glEnd();
glColor3f(1.0,1.0,1.0);
glRasterPos2f(10.0,12.0);
for(w=0;w<sizeof(c1);w++)               //Printing as "Current level"
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,c1[w]);


if (sel<=1)
{
glColor3f(0.7,0.3,0.9);              //to  print LEVEL 1
glRasterPos2f(10.0,11.0);
for(w=0;w<sizeof(level1);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,level1[w]);
}


if (sel<=2 && (lev1>=1000 || fl==2))
{
sel=2;
glColor3f(0.7,0.3,0.9);
glRasterPos2f(10.0,11);
for(w=0;w<sizeof(level2);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,level2[w]);
}


if (sel<=3 && (lev2>=1000 || fl==3))
{
sel=3;
glColor3f(0.7,0.3,0.9);
glRasterPos2f(10.0,11.0);
for(w=0;w<sizeof(level3);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,level3[w]);
}


if (sel<=4 && (lev3>=1000 || fl==4) )
{
sel=4;
glColor3f(0.7,0.3,0.9);
glRasterPos2f(10.0,11);
for(w=0;w<sizeof(level4);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,level4[w]);
}


if (sel<=5 &&  (lev4>=1000 || fl==5))
{
sel=5;
glColor3f(0.7,0.3,0.9);
glRasterPos2f(10.0,11);
for(w=0;w<sizeof(level5);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,level5[w]);
}


if (sel<=6 &&  (lev5>=1000 || fl==6))
{
sel=6;
glColor3f(0.7,0.3,0.9);
glRasterPos2f(10.0,11);
for(w=0;w<sizeof(level6);w++)
glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18,level6[w]);
}
 if(lev6<=1000)
{
if (gflag==1)
displayloop();
}
   if(lev6>=1000)
   {
strcpy(go,"finished\0");
crash=1;
   }


glColor3f(1.0,0.0,0.0);
if(flag==0 && f<1.8 && f>0.0)
{
glRasterPos2f(11.0,8.0);
for(w=0;w<sizeof(name);w++) // BEGINING OF CRASH CONDITIONS
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,name[w]);
glFlush();
crash=1;
glutPostRedisplay();
}


if(flag==1 && c<1.8 && b>0)
{
glRasterPos2f(11.0,8.0);
for(w=0;w<sizeof(name);w++)
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,name[w]);
glFlush();
crash=1;
glutPostRedisplay();
}


if(flag==1 && b<3.6 && b>0.0)
{
glRasterPos2f(11.0,8.0);
for(w=0;w<sizeof(name);w++)
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,name[w]);
glFlush();
crash=1;
glutPostRedisplay();
}


if(flag==0 && g<3.6 && f>0.0)
{
glRasterPos2f(11.0,8.0);
for(w=0;w<sizeof(name);w++)
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,name[w]);
crash=1;
glutPostRedisplay();
} //ENDING OF CRASH CONDITIONS
}
if (crash==1)
{
glColor3f(0.0,1.0,0.0);
glRasterPos2f(11.0,7.0);
for(w=0;w<sizeof(sc);w++)
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,sc[w]);


if (score<100)
{
glColor3f(1.0,0.0,0.0);
glRasterPos2f(11.25,6.0);
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,48);
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,48);
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,48);
glFlush();
}


else
{
for ( rr=0;rr<10;rr++)
{
pos[rr]=ss-0.15;        //calculating position of score digits in reverse
ss=pos[rr];
}
sco=score;
for (mm=1;mm<=10000;mm++)
for ( nn=1;nn<=25000;nn++) {}
rr=0;
while (score!=0)
{
rem=score%10;
glColor3f(1.0,0.0,0.0);
glRasterPos2f(pos[rr++],6.0);
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,48+rem);
score=score/10;
glFlush();
}
score=sco;
ss=11.75;
}
glColor3f(0.0,1.0,0.0);
glRasterPos2f(11.0,5.0);
for(w=0;w<sizeof(go);w++)
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,go[w]);
glFlush();
glColor3f(0.0,1.0,0.0);
glRasterPos2f(11.0,4.0);
for(w=0;w<sizeof(es);w++)
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,es[w]);


         glColor3f(0.0,1.0,0.0);
glRasterPos2f(11.0,3.0);
for(w=0;w<sizeof(back2);w++)
glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,back2[w]);


glFlush();


}


glFlush();
}




void mouse(int button,int state,int mousex,int mousey)
{
if (button==GLUT_LEFT_BUTTON && state==GLUT_DOWN && flag!=0) //to move the car left
{
x=x-4; flag=0;
}


if (button==GLUT_RIGHT_BUTTON && state==GLUT_DOWN && flag!=1)    // to move the car right
{
x=x+4;flag=1;
}


glutPostRedisplay();
}



void keyb(unsigned char key,int mx,int my)
{                                           //seting the controles used for screen 1
if (key==27)
exit(0);
if (key=='b' || key=='B')
{


       if(crash==1)
{
gflag=0;
   tt=0;
   ttt=0;
          count=0,gflag=0,lev1=0,lev2=0,lev3=0,lev4=0,lev5=0,lev6=0,score=0;
                  x=0,a=7.5,b=8.0,c=6.5,d=8,e=14.5,f=15.0,g=13.5,h=15,flag=0;
                 i=0,j=7.5,k=15;

                p=0.0;q=0.5;r=2.0;s=2.5;t=3.0;
                aa=1.0;bb=4.0;cc=6.0;dd=9.0;ee=11.0;ff=14.0;gg=16;hh=19.0;ss=11.75 ;
                 road=0;entered=0;sel_map=0;sel_level=0;sel_inst=0;line=1;screen=1;
                crash=0;rem=0;z=0;zz=0;yy=0;
glutPostRedisplay();
}
if (line==4 && hp_menu==1 && screen==2)
{
screen=1;
hp_menu=0;
}
}


if (key==13)    //ASCII for line feed
{
if (line==1)
{
gflag=1;
displayloop();
}
if (line==4 && hp_menu==0 && screen==1)
{
hp_menu=1; screen=2;
}


if (yy==0) {fl=1 ; sel=1;}
if (yy==1.5) fl=2;
if (yy==3) fl=3;
if (yy==4.5) fl=4;
if (yy==6) fl=5;
if (yy==7.5) fl=6;
}
if (key=='m'||key=='M')   sel_map=1;
if (key=='l'||key=='L')   sel_level=1;
if (key=='c'||key=='C')   sel_inst=1;


glutPostRedisplay();
}




void keyboard(int key ,int mousex,int mousey)   //to controlearrowmark keys and enter key
{
if (key=='\n')
entered=1;


if (key==GLUT_KEY_DOWN && gflag==0 )
{
if (line<4)
line++;
if (ly>-3)
ly-=1;
}


if (key==GLUT_KEY_UP && gflag==0 )
{
if (line>1)
line--;
if (ly<0)
ly+=1;
}


if (key==GLUT_KEY_RIGHT)
{
if (line==2 && zz<2)
zz+=1.5;
if (line==3 && yy<6.5)
yy+=1.5;
}
if (key==GLUT_KEY_LEFT)
{
if (line==2 && zz>0)
zz-=1.5;
if (line==3 && yy>0)
yy-=1.5;
}
if(key==GLUT_KEY_RIGHT &&flag==0 && gflag==1) //moving car right
{
x=x+4;flag=1;
}


else if(key==GLUT_KEY_LEFT &&flag==1 && gflag==1) //moving car left
{
x=x-4;flag=0;
}


  if(key==GLUT_KEY_UP)
{
   tt++;

}



 if(key==GLUT_KEY_DOWN)
{
tt--;

}


glutPostRedisplay();
}




void displayloop()       //to give moving effect to obstacla
{
if (sel==1 && lev1<1000)
{
a=a-.01;  aa-=0.01;
b=b-0.01;  //bb-=0.02;
c=c-0.01;  cc-=0.01;
d=d-0.01; // dd-=0.02;
e=e-0.01;  ee-=0.01;
f=f-0.01;  ff-=0.01;
g=g-0.01;  //gg-=0.02;
h=h-0.01;  k-=0.01;
i=i-0.01;  j=j-0.01;
lev1++;
}


if  (sel==2 && lev2<1000)
{
a=a-0.012;  aa-=0.012;
b=b-0.012;  bb-=0.012;
c=c-0.012;  cc-=0.012;
d=d-0.012;  dd-=0.012;
e=e-0.012;  ee-=0.012;
f=f-0.012;  ff-=0.012;
  g=g-0.012;  gg-=0.012;
h=h-0.012;  k-=0.012;
i=i-0.012;  j=j-0.012;
lev2++;
}


if  (sel==3 && lev3<1000)
{
a=a-0.015;  aa-=0.015;
b=b-0.015;  bb-=0.015;
c=c-0.015;  cc-=0.015;
d=d-0.015;  dd-=0.015;
e=e-0.015;  ee-=0.015;
f=f-0.015;  ff-=0.015;
  g=g-0.015;  gg-=0.015;
h=h-0.015;  k-=0.015;
i=i-0.015;  j=j-0.015;
lev3++;
}


if  (sel==4 && lev4<1000)
{
a=a-0.018;  aa-=0.018;
b=b-0.018;  bb-=0.018;
c=c-0.018;  cc-=0.018;
d=d-0.018;  dd-=0.018;
e=e-0.018;  ee-=0.018;
f=f-0.018;  ff-=0.018;
g=g-0.018;  gg-=0.018;
h=h-0.018;  k-=0.018;
i=i-0.018;  j=j-0.018;
lev4++;
}




if  (sel==5 && lev5<1000)
{
a=a-0.02;  aa-=0.02;
b=b-0.02;  bb-=0.02;
c=c-0.02;  cc-=0.02;
d=d-0.02;  dd-=0.02;
e=e-0.02;  ee-=0.02;
f=f-0.02;  ff-=0.02;
g=g-0.02;  gg-=0.02;
h=h-0.02;  k-=0.02;
i=i-0.02;   j=j-0.13;
lev5++;
}


if  (sel==6 && lev6<1000)
{
//for (int ab=1;ab<=1;ab++)
{
a=a-0.022;  aa-=0.022;
b=b-0.022;  bb-=0.022;
c=c-0.022;  cc-=0.022;
d=d-0.022;  dd-=0.022;
e=e-0.022;  ee-=0.022;
f=f-0.022;  ff-=0.022;
g=g-0.022;  gg-=0.022;
h=h-0.022;  k-=0.022;
i=i-0.022;  j=j-0.022;
}
//lev6++;
}


glutPostRedisplay();
}


void myinit()
{
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0.0,15.0,0.0,15.0);
glMatrixMode(GL_MODELVIEW);
glPointSize(5);
}


void pscore()
{
printf("Ur Score is: %d\n",score);
crash=9;
return;
}


int main(int argc,char **argv)
{
glutInit(&argc,argv);
glutInitWindowSize(1280,1024);
glutCreateWindow("CAR RACE");
glClearColor(1,1,1,1);
myinit();
glutDisplayFunc(display);
glutSpecialFunc(keyboard);

glutKeyboardFunc(keyb);
glutMouseFunc(mouse);
glutMainLoop();
return 0;
}
