/*
Members: 
1.Hossain, Md Tanvir , ID: 14-25524-1
 2.Dipta Sarakar tanmay Id: 14-26050-1
3. Morshed, Md. Munjur Id: 14-26054-1
4. Kibria Golam Id: 14-26036-1 


*/

#include <windows.h>
#include<cstring>
#include <iostream>
#include <stdlib.h>
#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h>
#include <time.h>
#include "imageloader.h"

using namespace std;

                                    ///all global variables here

GLuint _textureId;
GLuint _textureId2;

GLuint dice1;
GLuint dice2;
GLuint dice3;
GLuint dice4;
GLuint dice5;
GLuint dice6;

GLuint player1;
GLuint player2;
GLuint player1won;
GLuint player2won;




int diceNo = 1;
bool isFront = true;
bool player1Move = true;
bool player2Move = false;
bool moveGuti1 = false;
bool moveGuti2 = false;

                                        ///Game over or not
bool isGameOver = false;
bool won1 = false;
bool won2 = false;

float guti1x = 100.0;
float guti1y = 150.0;
float guti2x = 100.0;
float guti2y = 150.0;

                                            ///all global variables here
                                            ///front page animation
float f_x = 0.0;
float f_y = 0.0;
float ff_x = 0.0;
float ff_y = 0.0;
                                            ///front page animation
int position1 = 0;
int position2 = 0;

float position[100] = { 200.0, 300.0, 400.0, 500.0, 600.0, 700.0, 800.0, 900.0, 1000.0, 1100.0, 1100.0, 1000.0, 900.0, 800.0, 700.0, 600.0, 500.0, 400.0, 300.0, 200.0, 200.0, 300.0, 400.0, 500.0, 600.0, 700.0, 800.0, 900.0, 1000.0, 1100.0, 1100.0, 1000.0, 900.0, 800.0, 700.0, 600.0, 500.0, 400.0, 300.0, 200.0, 200.0, 300.0, 400.0, 500.0, 600.0, 700.0, 800.0, 900.0, 1000.0, 1100.0, 1100.0, 1000.0, 900.0, 800.0, 700.0, 600.0, 500.0, 400.0, 300.0, 200.0, 200.0, 300.0, 400.0, 500.0, 600.0, 700.0, 800.0, 900.0, 1000.0, 1100.0, 1100.0, 1000.0, 900.0, 800.0, 700.0, 600.0, 500.0, 400.0, 300.0, 200.0, 200.0, 300.0, 400.0, 500.0, 600.0, 700.0, 800.0, 900.0, 1000.0, 1100.0, 1100.0, 1000.0, 900.0, 800.0, 700.0, 600.0, 500.0, 400.0, 300.0, 200.0 };

                                            ///custom function ////
void setXYofGuit1()
{
    cout<<"Current value of position  1 is"<<position1<<endl;



                                            /// replace of first players snake head
    if (position1 == 17) {
        position1 = 7;
    }
    else if (position1 == 54) {
        position1 = 34;
    }
    else if (position1 == 62) {
        position1 = 19;
    }
    else if (position1 == 64) {
        position1 = 60;
    }
    else if (position1 == 87) {
        position1 = 24;
    }
    else if (position1 == 93) {
        position1 = 73;
    }
    else if (position1 == 95) {
        position1 = 75;
    }
    else if (position1 == 98) {
        position1 = 79;
    }
    else if (position1 == 1) {
        position1 = 38;
    }
    else if (position1 == 4) {
        position1 = 14;
    }
    else if (position1 == 9) {
        position1 = 31;
    }
    else if (position1 == 21) {
        position1 = 42;
    }
    else if (position1 == 28) {
        position1 = 84;
    }
    else if (position1 == 51) {
        position1 = 67;
    }
    else if (position1 == 71) {
        position1 = 91;
    }
    else if (position1 == 80) {
        position1 = 100;
    }

    if (position1 >= 1 && position1 <= 10) {
        guti1y = 150.0;
        guti1x = position[position1 - 1];
    }
    else if (position1 >= 11 && position1 <= 20) {
        guti1y = 250.0;
        guti1x = position[position1 - 1];
    }

    else if (position1 >= 21 && position1 <= 30) {
        guti1y = 350.0;
        guti1x = position[position1 - 1];
    }

    else if (position1 >= 31 && position1 <= 40) {
        guti1y = 450.0;
        guti1x = position[position1 - 1];
    }

    else if (position1 >= 41 && position1 <= 50) {
        guti1y = 550.0;
        guti1x = position[position1 - 1];
    }

    else if (position1 >= 51 && position1 <= 60) {
        guti1y = 650.0;
        guti1x = position[position1 - 1];
    }

    else if (position1 >= 61 && position1 <= 70) {
        guti1y = 750.0;
        guti1x = position[position1 - 1];
    }

    else if (position1 >= 71 && position1 <= 80) {
        guti1y = 850.0;
        guti1x = position[position1 - 1];
    }
    else if (position1 >= 81 && position1 <= 90) {
        guti1y = 950.0;
        guti1x = position[position1 - 1];
    }
    else if (position1 >= 91 && position1 <= 100) {
        guti1y = 1050.0;
        guti1x = position[position1 - 1];
    }

      if(position1 >100){

    position1 = position1-diceNo;
        return;
    }


     if(position1 == 100) {
        won1 = true;
        won2=false;
        isGameOver = true;
        glutPostRedisplay();
    }

}

void setXYofGuit2()
{
     cout<<"Current value of position  2 is"<<position2<<endl;



    if (position2 == 17) {
        position2 = 7;
    }
    else if (position2 == 54) {
        position2 = 34;
    }
    else if (position2 == 62) {
        position2 = 19;
    }
    else if (position2 == 64) {
        position2 = 60;
    }
    else if (position2 == 87) {
        position2 = 24;
    }
    else if (position2 == 93) {
        position2 = 73;
    }
    else if (position2 == 95) {
        position2 = 75;
    }
    else if (position2 == 98) {
        position2 = 79;
    }
    else if (position2 == 1) {
        position2 = 38;
    }
    else if (position2 == 4) {
        position2 = 14;
    }
    else if (position2 == 9) {
        position2 = 31;
    }
    else if (position2 == 21) {
        position2 = 42;
    }
    else if (position2 == 28) {
        position2 = 84;
    }
    else if (position2 == 51) {
        position2 = 67;
    }
    else if (position2 == 71) {
        position2 = 91;
    }
    else if (position2 == 80) {
        position2 = 100;
    }

    if (position2 >= 1 && position2 <= 10) {
        guti2y = 150.0;
        guti2x = position[position2 - 1];
    }
    else if (position2 >= 11 && position2 <= 20) {
        guti2y = 250.0;
        guti2x = position[position2 - 1];
    }

    else if (position2 >= 21 && position2 <= 30) {
        guti2y = 350.0;
        guti2x = position[position2 - 1];
    }

    else if (position2 >= 31 && position2 <= 40) {
        guti2y = 450.0;
        guti2x = position[position2 - 1];
    }

    else if (position2 >= 41 && position2 <= 50) {
        guti2y = 550.0;
        guti2x = position[position2 - 1];
    }

    else if (position2 >= 51 && position2 <= 60) {
        guti2y = 650.0;
        guti2x = position[position2 - 1];
    }

    else if (position2 >= 61 && position2 <= 70) {
        guti2y = 750.0;
        guti2x = position[position2 - 1];
    }

    else if (position2 >= 71 && position2 <= 80) {
        guti2y = 850.0;
        guti2x = position[position2 - 1];
    }
    else if (position2 >= 81 && position2 <= 90) {
        guti2y = 950.0;
        guti2x = position[position2 - 1];
    }
    else if (position2 >= 91 && position2 <= 100) {
        guti2y = 1050.0;
        guti2x = position[position2 - 1];
    }
    if(position2 > 100){
            position2 = position2-diceNo;
            return;
    }


      if(position2 == 100) {
        won2 = true;
        won1=false;
        isGameOver = true;
        glutPostRedisplay();
    }
}

                                                    ///custom function //////////
void drawScene()
{

    if (isFront) {

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glMatrixMode(GL_MODELVIEW);
        glEnable(GL_DEPTH_TEST);
        glLoadIdentity();

        glPushMatrix();

                                                    /// GL Translate(50.0, 5.0,0.0);

        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, _textureId2);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        glColor3f(1.0f, 1.0f, 1.0f);
        glBegin(GL_QUADS);

        glNormal3f(0.0f, 0.0f, 1.0f);
                                                    ///left bottom
        glTexCoord2f(0.0, 0.0);
        glVertex2d(250.0, 250.0);
                                                    ///right bottom
        glTexCoord2f(1.0, 0.0);
        glVertex2d(1300.0, 250.0);

        glTexCoord2f(1.0, 1.0);
        glVertex2d(1300.0, 1300.0);

        glTexCoord2f(0.0, 1.0);
        glVertex2d(250.0, 1300.0);

        glEnd();
        glPopMatrix();
                                                    ///top animation start here

        glPushMatrix();
        glDisable(GL_TEXTURE_2D);
        glTranslatef(f_x, 0.0, 0.0);
        f_x = f_x + 0.5;
        if (f_x == 1500.0) {
            f_x = 0.0;
        }
        glColor3ub(0, 0, 102);
        glBegin(GL_QUADS);
        glVertex2d(0.0, 1450.0);
        glVertex2d(50.0, 1450.0);
        glVertex2d(50.0, 1490.0);
        glVertex2d(0.0, 1490.0);
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glDisable(GL_TEXTURE_2D);
        glTranslatef(-f_y, 0.0, 0.0);
        f_y = f_y + 0.5;
        if (f_y == 1500.0) {
            f_y = 0.0;
        }
        glColor3ub(255, 0, 0);

        glBegin(GL_QUADS);
        glVertex2d(1450.0, 1450.0);
        glVertex2d(1490.0, 1450.0);
        glVertex2d(1490.0, 1490.0);
        glVertex2d(1450.0, 1490.0);
        glEnd();
        glPopMatrix();
                                                        ///top animation ends here

                                                        ///bottom animation ////

        glPushMatrix();
        glDisable(GL_TEXTURE_2D);
        glTranslatef(ff_x, 0.0, 0.0);
        ff_x = ff_x + 0.5;
        if (ff_x == 1500.0) {
            ff_x = 0.0;
        }
        glColor3ub(0, 0, 102);
        glBegin(GL_QUADS);
        glVertex2d(0.0, 0.0);
        glVertex2d(50.0, 0.0);
        glVertex2d(50.0, 50.0);
        glVertex2d(0.0, 50.0);
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glDisable(GL_TEXTURE_2D);
        glTranslatef(-ff_y, 0.0, 0.0);
        ff_y = ff_y + 0.5;
        if (ff_y == 1500.0) {
            ff_y = 0.0;
        }
        glColor3ub(255, 0, 0);

        glBegin(GL_QUADS);
        glVertex2d(1450.0, 0.0);
        glVertex2d(1500.0, 0.0);
        glVertex2d(1500.0, 50.0);
        glVertex2d(1450.0, 50.0);
        glEnd();
        glPopMatrix();

                                                                ///bottom animation

        glutSwapBuffers();
        glFlush();
        glutPostRedisplay();
    }

    else if(!isGameOver){

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        glPushMatrix();

        glTranslatef(50.0, 5.0, 0.0);

        glEnable(GL_TEXTURE_2D);
        glBindTexture(GL_TEXTURE_2D, _textureId);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        glColor3f(1.0f, 1.0f, 1.0f);
        glBegin(GL_QUADS);

        glNormal3f(0.0f, 0.0f, 1.0f);
                                                    ///left bottom
        glTexCoord2f(0.0, 0.0);
        glVertex2d(100.0, 100.0);
                                                    ///right bottom
        glTexCoord2f(1.0, 0.0);
        glVertex2d(1100.0, 100.0);

        glTexCoord2f(1.0, 1.0);
        glVertex2d(1100.0, 1100.0);

        glTexCoord2f(0.0, 1.0);
        glVertex2d(100.0, 1100.0);

        glEnd();

                                                    ///display dice
        glEnable(GL_TEXTURE_2D);
        if (diceNo == 1) {
            glBindTexture(GL_TEXTURE_2D, dice1);
        }
        else if (diceNo == 2) {
            glBindTexture(GL_TEXTURE_2D, dice2);
        }

        else if (diceNo == 3) {
            glBindTexture(GL_TEXTURE_2D, dice3);
        }
        else if (diceNo == 4) {
            glBindTexture(GL_TEXTURE_2D, dice4);
        }
        else if (diceNo == 5) {
            glBindTexture(GL_TEXTURE_2D, dice5);
        }
        else if (diceNo == 6) {
            glBindTexture(GL_TEXTURE_2D, dice6);
        }


        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        glColor3ub(255, 255, 2);
        glBegin(GL_QUADS);

        glNormal3f(255, 175, 2);
                                                ///left bottom
        glTexCoord2f(0.0, 0.0);
        glVertex2d(1200.0, 500.0);
                                                ///right bottom
        glTexCoord2f(1.0, 0.0);
        glVertex2d(1400.0, 500.0);

        glTexCoord2f(1.0, 1.0);
        glVertex2d(1400.0, 900.0);

        glTexCoord2f(0.0, 1.0);
        glVertex2d(1200.0, 900.0);

        glEnd();
                                                ///setting player 1 turn image
        if(player1Move){
              glBindTexture(GL_TEXTURE_2D, player1);
        }
        else if(player2Move){
            glBindTexture(GL_TEXTURE_2D, player2);
        }

         glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        glColor3ub(131, 180, 209);
        glBegin(GL_QUADS);

        glNormal3f(0.0f, 0.0f, 1.0f);
                                                ///left bottom
        glTexCoord2f(0.0, 0.0);
        glVertex2d(50.0, 1150.0);
                                                ///right bottom
        glTexCoord2f(1.0, 0.0);
        glVertex2d(1150.0, 1150.0);

        glTexCoord2f(1.0, 1.0);
        glVertex2d(1150.0, 1500.0);

        glTexCoord2f(0.0, 1.0);
        glVertex2d(50.0, 1500.0);

        glEnd();

                                            ///setting player 1 turn image


        glPopMatrix();
                                            ///two guti
        glPushMatrix();
                                            /// GL Translate (0.0, 0.0,-5.0);

        glDisable(GL_TEXTURE_2D);

        if (moveGuti1 == true) {
            setXYofGuit1();
        }
        if (moveGuti2 == true) {
            setXYofGuit2();
        }
                                                ///player 1
        glColor3ub(255, 0, 0);
        glPointSize(25.0);
        glBegin(GL_POINTS);

        glVertex3f(guti1x, guti1y, -1.0);
        glEnd();
                                                ///player 1 end
                                                ///player 2
        glColor3ub(0, 255, 0);
        glPointSize(28.0);
        glBegin(GL_POINTS);

        glVertex3f(guti2x, guti2y, -1.0);
        glEnd();
                                                ///player 2 end

        glPopMatrix();

                                                ///Two guti
        glutSwapBuffers();
        glFlush();
    }

    else if(isGameOver){

             glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glMatrixMode(GL_MODELVIEW);
        glEnable(GL_DEPTH_TEST);
        glLoadIdentity();

        glPushMatrix();

                                                /// GL Translate(50.0, 5.0,0.0);

        glEnable(GL_TEXTURE_2D);

        if(won1){
            glBindTexture(GL_TEXTURE_2D, player1won);
        }
    if(won2){
             glBindTexture(GL_TEXTURE_2D, player2won);
        }


        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        glColor3f(1,1,1);
        glBegin(GL_QUADS);

        glNormal3f(0.0f, 0.0f, 1.0f);
                                                        ///left bottom
        glTexCoord2f(0.0, 0.0);
        glVertex2d(200.0, 200.0);
                                                        ///right bottom
        glTexCoord2f(1.0, 0.0);
        glVertex2d(1400.0, 200.0);

        glTexCoord2f(1.0, 1.0);
        glVertex2d(1400.0, 1400.0);

        glTexCoord2f(0.0, 1.0);
        glVertex2d(200.0, 1400.0);

        glEnd();
        glPopMatrix();

        glutSwapBuffers();
        glFlush();

    }

}

                                               ///function for texture loading///////////////////
GLuint loadTexture(Image* image)
{
    GLuint textureId;
    glGenTextures(1, &textureId);              ///Make room for our texture
    glBindTexture(GL_TEXTURE_2D, textureId);   ///Tell OpenGL which texture to edit
                                               ///Map the image to the texture
    glTexImage2D(GL_TEXTURE_2D,                ///Always GL_TEXTURE_2D
        0,                                     ///0 for now
        GL_RGB,                                ///Format OpenGL uses for image
        image->width, image->height,           ///Width and height
        0,                                     ///The border of the image
        GL_RGB,                                ///GL_RGB, because pixels are stored in RGB format
        GL_UNSIGNED_BYTE,                      ///GL_UNSIGNED_BYTE, because pixels are stored
                                               ///as unsigned numbers
        image->pixels);                        ///The actual pixel data
    return textureId;                          ///Returns the id of the texture
}

                                                ///function for texture loading///////////////////

void initialize()
{

    glClearColor(1.0, 1.0, 1.0, 1.0);
    glMatrixMode(GL_PROJECTION);
    gluPerspective(45.0, 1.00, 1.0, 200.0);
    Image* image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/main.bmp");
    _textureId = loadTexture(image);
    delete image;
    image = loadBMP("C:/Users/student/Desktop/FInal_project/FInal_project/Frontlogo.bmp");
    _textureId2 = loadTexture(image);
    delete image;

                                                                                /// loading of dices
    image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/1.bmp");
    dice1 = loadTexture(image);
    delete image;

    image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/2.bmp");
    dice2 = loadTexture(image);
    delete image;

    image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/3.bmp");
    dice3 = loadTexture(image);
    delete image;

    image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/4.bmp");
    dice4 = loadTexture(image);
    delete image;
    image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/5.bmp");
    dice5 = loadTexture(image);
    delete image;
    image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/6.bmp");
    dice6 = loadTexture(image);
    delete image;

                                                                                   ///loading texture image
   image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/player1won.bmp");
    player1won = loadTexture(image);
    delete image;
    image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/player2won.bmp");
    player2won = loadTexture(image);
    delete image;

    image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/player1.bmp");
    player1 = loadTexture(image);
    delete image;

    image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/player2.bmp");
    player2 = loadTexture(image);
    delete image;

}

void lightSetting()
{

    GLfloat ambientIntensity[4] = { 0.6, 0.6, 0.6, 1.0 };
    GLfloat position[4] = { 0.0, 1.0, 0.0, 0.0 };
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambientIntensity);
    glLightfv(GL_LIGHT0, GL_POSITION, position);

}

void myInit()
{
    glClearColor(1.0, 1.0, 1.0, 0.0);
    glColor3f(0.0f, 0.0f, 0.0f);
    glPointSize(15.0);
    glLineWidth(4.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0f, 1600.0, 0.0, 1600.0, 1.0, -1.0);
}

void keyboard(unsigned char key, int x, int y)
{

    if (key == 's') {
        isFront = false;
        glutPostRedisplay();
    }
    if (key == 'S') {
        isFront = false;
        glutPostRedisplay();
    }

    if (key == 'p') {
        if (player1Move == false)
            return;
        player1Move = false;
        player2Move = true;
        moveGuti1 = true;
        moveGuti2 = false;
                                                    ///Beep(440, 500);

        srand(time(NULL));
        diceNo = rand() % (6 - 1 + 1) + 1;
        position1 = position1 + diceNo;
        cout << diceNo;
        glutPostRedisplay();
    }
    if (key == 'l') {
        if (player2Move == false)
            return;
                                           ///Beep(440, 500);
        player2Move = false;
        player1Move = true;

        moveGuti1 = false;
        moveGuti2 = true;

        srand(time(NULL));
        diceNo = rand() % (6 - 1 + 1) + 1;
        position2 = position2 + diceNo;
        cout << diceNo;
        glutPostRedisplay();
    }
}

int main(int argc, char** argv)
{

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(1200, 1200);
    glutCreateWindow("SAAP LUDU");
    initialize();
    myInit();
    lightSetting();
    glutDisplayFunc(drawScene);
    glutKeyboardFunc(keyboard);
    glutMainLoop();
    return 0;
}
