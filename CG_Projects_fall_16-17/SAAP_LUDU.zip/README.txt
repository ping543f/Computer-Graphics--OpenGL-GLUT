Please change the file path for images in the following lines:

643,646,651,655,659,663,666,669,674,677,681,685.


sample line: Image* image = loadBMP("C:/Users/Munjur Murshed/Desktop/FInal_project/main.bmp");
changed line: Image* image = loadBMP("YOUR_PATH_PROJECT/main.bmp");

Please open FInal_project.cbp in codeblocks.