#include <stdio.h>
#include <iostream>
#include <windows.h>
#include <GL/glut.h>
#include <time.h>
//#include <GL/freeglut.h>
//#include <sstream>

int flag=1;

using namespace std;

void ice();
void display1();
void display2();
void display3();
void ship();
void water();


GLint a=0,b=0,c=0,d=0,e=0,f=0,g=500,h=600,x=100,i=0;
GLubyte iceX=450,iceY=50;
GLint ay=75,by=75,cy=0;
GLfloat theta=0.0;


void drawPolygon(float tx,float ty, float tz , float sx, float sy, float sz , float r,float g, float b , int numArgs ,...){

    glPushMatrix();

    glTranslatef(tx,ty,tz);
    glScalef(sx,sy,sz);
    glRotatef(180,1.0,0.0,0.0);
    glRotatef(180,0.0,1.0,0.0);


    va_list points;
    va_start(points,numArgs);
    int i;


    glColor3f (r,g,b);

    glBegin(GL_POLYGON);
    for(i=1;i<numArgs;i+=2){
        int px,py;
        px=va_arg(points,int);
        py=va_arg(points,int);

        glVertex2f(px,py);
    }
    glEnd();

    va_end(points);

    glPopMatrix();
}

void drawOrdinaryPolygon(float tx,float ty, float tz  , float r,float g, float b , int numArgs ,...){

    glPushMatrix();

    glTranslatef(tx,ty,tz);
    glScalef(5,8,0);

    va_list points;
    va_start(points,numArgs);
    int i;


    glColor3f (r,g,b);

    glBegin(GL_POLYGON);
    for(i=1;i<numArgs;i+=2){
        int px,py;
        px=va_arg(points,int);
        py=va_arg(points,int);

        glVertex2f(px,py);
    }
    glEnd();

    va_end(points);

    glPopMatrix();
}

void update(int value)
{
	a+=20.0;//if > start from 2nd stage
	glutPostRedisplay();
	glutTimerFunc(200,update,0);//motion
}

void display()
{
	//glClear(GL_COLOR_BUFFER_BIT);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	display1();

	if(a>950)
	{
		b+=20;
		display2();
	}
	if(b>950 )
	{
		c+=10;
		display3();

	}

	glFlush();
	glutSwapBuffers();
}


void display1()
{
    water();
	glPushMatrix();
	glTranslated(a,ay,0.0);
	ship();
	glPopMatrix();

}

void display2()
{

	glClear(GL_COLOR_BUFFER_BIT);
	water();
	ice();
	glPushMatrix();
	glTranslated(b,by,0.0);
	ship();
	glPopMatrix();

}

void display3()
{
	glClear(GL_COLOR_BUFFER_BIT);
	x-=5;
	glPushMatrix();
	glTranslated(c,x,0.0);
	glRotated(-15,0,0,1);
	ship();
	glPopMatrix();
	water();
}

void water()
{
	glColor3ub(77, 166, 255);
	glBegin(GL_POLYGON);
		/*glVertex2f(0,0);
		glVertex2f(4000,0);
		glVertex2f(4000,400);
		glVertex2f(0,400);*/
		glVertex2f(100,100);
		glVertex2f(1000,100);
		glVertex2f(1000,-950);
		glVertex2f(-10000,-950);
	glEnd();
}

void ship()
{

	glScaled(15,15,0);
	glColor3ub(153, 153, 102);
    glBegin(GL_POLYGON);
		glVertex2f(3.5,5.5);
		glVertex2f(3.5,8.5);
		glVertex2f(19.5,8.5);
		glVertex2f(19.5,5.5);
	glEnd();
	glColor3f(0.0,0.0,0.0);
	glBegin(GL_POLYGON);
		glVertex2f(1,5.5);
		glVertex2f(4,1);
		glVertex2f(19,1);
		glVertex2f(21.5,5.5);
	glEnd();
	glColor3ub(128, 0, 0);
	//glColor3ub(0, 255, 255);
	glBegin(GL_POLYGON);
		glVertex2f(4,5.5);
		glVertex2f(4,8);
		glVertex2f(5,8);
		glVertex2f(5,5.5);
	glEnd();
	glColor3ub(0, 255, 255);
	glBegin(GL_POLYGON);
		glVertex2f(7,7.5);
		glVertex2f(7,8);
		glVertex2f(10,8);
		glVertex2f(10,7.5);
	glEnd();
//	glColor3ub(0, 255, 255);
	glBegin(GL_POLYGON);
		glVertex2f(11.5,7.5);
		glVertex2f(11.5,8);
		glVertex2f(15,8);
		glVertex2f(15,7.5);
	glEnd();
	glBegin(GL_POLYGON);
		glVertex2f(16,7.5);
		glVertex2f(16,8);
		glVertex2f(19,8);
		glVertex2f(19,7.5);
	glEnd();
	glColor3ub(128, 0, 0);
	glBegin(GL_POLYGON);
		glVertex2f(4.5,8.5);
		glVertex2f(4.5,10);
		glVertex2f(18.5,10);
		glVertex2f(18.5,8.5);
	glEnd();
	glColor3ub(0, 0, 80);
	glBegin(GL_POLYGON);
		glVertex2f(5.5,10);
		glVertex2f(5.5,12.9);
		glVertex2f(7,12.9);
		glVertex2f(7,10);
	glEnd();
	//glColor3ub(255, 128, 0);
	glColor3ub(0, 255, 255);
	glBegin(GL_POLYGON);
		glVertex2f(5.5,12.9);
		glVertex2f(5.5,13.5);
		glVertex2f(7,13.5);
		glVertex2f(7,12.9);
	glEnd();
	glColor3ub(0, 0, 80);
	glBegin(GL_POLYGON);
		glVertex2f(8.5,10);
		glVertex2f(8.5,12.9);
		glVertex2f(10,12.9);
		glVertex2f(10,10);
	glEnd();
	//glColor3ub(255, 128, 0);
	glColor3ub(0, 255, 255);
	glBegin(GL_POLYGON);
		glVertex2f(8.5,12.9);
		glVertex2f(8.5,13.5);
		glVertex2f(10,13.5);
		glVertex2f(10,12.9);
	glEnd();
	glColor3ub(0, 0, 80);
	//glColor3ub(0, 255, 255);
	glBegin(GL_POLYGON);
		glVertex2f(11.5,10);
		glVertex2f(11.5,12.9);
		glVertex2f(13,12.9);
		glVertex2f(13,10);
	glEnd();
	//glColor3ub(255, 128, 0);
	glColor3ub(0, 255, 255);
	glBegin(GL_POLYGON);
		glVertex2f(11.5,12.9);
		glVertex2f(11.5,13.5);
		glVertex2f(13,13.5);
		glVertex2f(13,12.9);
	glEnd();
	glColor3ub(0, 0, 80);
	glBegin(GL_POLYGON);
		glVertex2f(14.5,10);
		glVertex2f(14.5,12.9);
		glVertex2f(16,12.9);
		glVertex2f(16,10);
	glEnd();
	//glColor3ub(255, 128, 0);
	glColor3ub(0, 255, 255);
	glBegin(GL_POLYGON);
		glVertex2f(14.5,12.9);
		glVertex2f(14.5,13.5);
		glVertex2f(16,13.5);
		glVertex2f(16,12.9);
	glEnd();
//glPopMatrix();
}

//Ship_Control_Keyboard
void keyboard(int key, int x, int y){
	if (key == GLUT_KEY_UP){

        if(ay<75){
	    ay+=20;
        by+=20;
        glutPostRedisplay();
	    }
		cout<<"KEYBOARD_UP | ";
	}
	if (key == GLUT_KEY_DOWN){
         if(ay<=700){
          ay-=20;
          by-=20;
        glutPostRedisplay();

	    }
        cout<<"KEYBOARD_DOWN | ";

	}
	if (key == GLUT_KEY_LEFT){
        if(ay<75){
      // if(ay<=1700){
	    a-=20;
        glutPostRedisplay();
	    }

    		cout<<"KEYBOARD_LEFT | ";
	}

	if (key == GLUT_KEY_RIGHT){
              if(ay<=700){
              //  if(ay<75){
	            a+=20;
	            glutPostRedisplay();

            }
		cout<<"KEYBOARD_RIGHT | ";
	}
}

/* TO DRAW ICEBERG */
void drawMultipleIce(){
    srand(time(NULL));
    int numOfIce = rand()%25;
    GLint ix=iceX,iy=iceY;

    drawOrdinaryPolygon(450,50,0.0,0.9,0.9,0.9,24,7,2,8,3,8,3,11,18,12,19,12,19,15,19,15,19,17,18,18,3,19,3,19,2);

    for(int i=1 ; i<=numOfIce ; i++){
        ix=rand()%1200;
        iy=rand()%700;

        if(iy>20)iy=-iy;
        glPushMatrix();
        printf("iy = %d\n",iy);
        printf("ix = %d\n",ix);
    	drawPolygon(ix,iy,0.0,5,8,0,0.9,0.9,0.9,24,7,2,8,3,8,3,11,18,12,19,12,19,15,19,15,19,17,18,18,3,19,3,19,2);
		glPopMatrix();
    }

}
void ice()
{
    drawMultipleIce();
}



//void myinit (void){glClearColor(0.0, 0.8, 1.0, 0.0);glPointSize(4.0);glMatrixMode(GL_PROJECTION);glLoadIdentity();gluOrtho2D(0.0, 640.0, 0.0, 480.0);}
void myinit()
{
	glClearColor(1.0f,1.0f,1.0f,1.0f);
	glColor3f(1.0,0.0,0.0);
	glPointSize(1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	//gluOrtho2D(0.0,999.0,0.0,799.0);
	gluOrtho2D(-40,1000,-800.0,470);
}

int main(int argc, char* argv[])
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    //glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	//glutInitWindowSize(1024.0,768.0);
	glutInitWindowSize(1350.0,720.0);
	glutInitWindowPosition(0,0);
	glutCreateWindow("titanic ship");
	glutSpecialFunc(keyboard);
	glutDisplayFunc(display);
	myinit();
	glutTimerFunc(100,update,0);
	glutMainLoop();
return 0;
}

