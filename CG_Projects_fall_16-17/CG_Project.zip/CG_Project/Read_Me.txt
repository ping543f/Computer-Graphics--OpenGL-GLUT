1.In ballon.h file line no 39
2.in loadBMP() have to paste the link of texture1.bmp by removing front slash into back slash.
