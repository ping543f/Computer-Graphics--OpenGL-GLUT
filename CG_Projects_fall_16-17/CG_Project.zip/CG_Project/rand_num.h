

#include<windows.h>
#include <iostream>
#include<GL/glut.h>
#include <time.h>
#include <stdlib.h>



using namespace std;


 class rand_num{

public:
    int max_num=0,min_num=0;


    int make_rand(int max_num, int min_num){

       srand(time(NULL));
    int r =(int) rand()%(max_num+1-min_num)+min_num;
        return r;
    }


};
