
#include<windows.h>
#include <iostream>
#include<GL/glut.h>
#include "cannon.h"
#include "ballon.h"

using namespace std;


cannon ob1;
ballon b2;
ballon b3;
ballon b1;

int level=1;
char title[20];










void myDisplay(void)
{
	glClear(GL_COLOR_BUFFER_BIT);




	ob1.drawcannon();

	if(level ==1){

        b1.drawScene();
       b1.coll(ob1.arrow_x2,ob1.arrow_y2,&ob1) ;







                                sprintf(title,"Level 1");
                                    glColor3ub(0,0,0);
                                    glRasterPos2d(100,750);
                                for(int i=0;i<7;i++){

                                    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,title[i]);

                                }

        if(b1.score()==100.0)
            level++;
	}

	if(level ==2){

        b3.drawScene();
        b3.coll(ob1.arrow_x2,ob1.arrow_y2,&ob1);

        b2.drawScene();
        b2.coll(ob1.arrow_x2,ob1.arrow_y2,&ob1);

                                    sprintf(title,"Level 2");
                                    glColor3ub(0,0,0);
                                    glRasterPos2d(100,750);
                                for(int i=0;i<7;i++){

                                    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,title[i]);

                                }

                                if(b1.score()==300){
                                    char over[20];
                                    sprintf(over,"||** Game Over **||");
                                    glColor3ub(255,0,0);
                                    glRasterPos2d(250,400);
                                for(int i=0;i<19;i++){

                                    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,over[i]);

                                }
                                }
	}

	glFlush();

	 glutPostRedisplay();
}






void myInit(void)
{
	//glClearColor(0, 191, 255, 0.0);
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glColor3f(0.0f, 0.0f, 0.0f);
	glPointSize(15.0);
	glLineWidth(4.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, 800, 0.0, 800);
	b1.ballonadd();
}




void keyboardown(int key, int x, int y)
{
	switch (key){

	case GLUT_KEY_RIGHT:
            ob1.moveright();

		break;

	case GLUT_KEY_LEFT:
             ob1.moveleft();

		break;

	default:
		break;


	}

}





void mouse(int button,int state,int x,int y)
{
        switch(button)
        {
            case GLUT_LEFT_BUTTON:
                if(state==GLUT_DOWN)
                    ob1.movearrow();
                break;


            case GLUT_MIDDLE_BUTTON:
                if(state==GLUT_DOWN)
                {

                }
                break;


            case GLUT_RIGHT_BUTTON:
                if(state==GLUT_DOWN){
                    ob1.disobj();
                    glutPostRedisplay();

                }

            break;


        default:
        break;

        }



}





int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(600, 600);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Ballon Game");

	b2.quad_x1+=200;
    b2.quad_x2+=200;
    b2.quad_x3+=200;
    b2.quad_x4+=200;

    b2.quad_y1+=200;
    b2.quad_y2+=200;
    b2.quad_y3+=200;
    b2.quad_y4+=200;

	myInit();
	glutDisplayFunc(myDisplay);
	glutSpecialFunc(keyboardown);
	glutMouseFunc(mouse);

	glutMainLoop();
}
