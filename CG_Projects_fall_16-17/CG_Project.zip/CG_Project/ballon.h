#include<windows.h>
#include <iostream>
#include<GL/glut.h>
#include<stdio.h>
#include<string.h>
#include<sstream>

#include "imageloader.h"
#include "rand_num.h"


GLuint _textureId;
GLuint _textureId2;
GLuint _textureId3;


    char result[20];


rand_num rn1;
using namespace std;
static float marks=0.0;

class ballon{

public:


    float quad_x1=400,quad_x2=400,quad_x3=500,quad_x4=500;
    float quad_y1=400,quad_y2=500,quad_y3=500,quad_y4=400;
    float speed=.1;
    bool flag=false;
    bool ballon_flag=true;


   void ballonadd(){

        //glPointSize(15.0);		//texts are linked below with backward slash//
        Image* image = loadBMP("D:/computer graphics/CG_Project/CG_Project/texture1.bmp");
        _textureId = loadTexture(image);
        delete image;

  /*      Image* image2 = loadBMP("D:/CG project/CG_Project/texture2.bmp");
        _textureId2 = loadTexture(image2);
        delete image;

        Image* image3 = loadBMP("D:/CG project/CG_Project/texture3.bmp");
        _textureId3 = loadTexture(image3);
        delete image;
*/

    }


    void drawScene() {
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
     //ballonadd();

    if(ballon_flag){
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();

            glPushMatrix();

            glEnable(GL_TEXTURE_2D);
            glBindTexture(GL_TEXTURE_2D, _textureId);


            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
            glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

            glColor3ub(255, 255, 255);
            glBegin(GL_QUADS);

	//glNormal3f(0.0f, 0.0f, 1.0f);

            glTexCoord2f(0.0, 0.0);
            glVertex2d(quad_x1, quad_y1);



            glTexCoord2f(0.0, 1.0);
            glVertex2d(quad_x2, quad_y2);

            glTexCoord2f(1.0,1.0);
            glVertex2d(quad_x3, quad_y3);

            glTexCoord2f(1.0, 0.0);
            glVertex2d(quad_x4, quad_y4);

	//glVertex3f(0.0, 1.0, 0.0);

            glEnd();

/*	glMatrixMode(GL_POSITION);
	glBegin(GL_POINTS);
	glColor3f(1.0, 0.0, 0.0);
	glVertex2i(5, 5);

	glEnd();


	glFlush();
*/
            glPopMatrix();

    }
	ballon_move();
    show_score();
	//glutPostRedisplay();
}


GLuint loadTexture(Image* image) {
	GLuint textureId;
	glGenTextures(1, &textureId); //Make room for our texture
	glBindTexture(GL_TEXTURE_2D, textureId); //Tell OpenGL which texture to edit
	//Map the image to the texture
	glTexImage2D(GL_TEXTURE_2D,                //Always GL_TEXTURE_2D
		0,                            //0 for now
		GL_RGB,                       //Format OpenGL uses for image
		image->width, image->height,  //Width and height
		0,                            //The border of the image
		GL_RGB, //GL_RGB, because pixels are stored in RGB format
		GL_UNSIGNED_BYTE, //GL_UNSIGNED_BYTE, because pixels are stored
		//as unsigned numbers
		image->pixels);               //The actual pixel data
	return textureId; //Returns the id of the texture
}


        void ballon_move(){

           // int r = rn1.make_rand(1,2);
    point:
        if(flag==false){

        if(quad_x3>=750 ){

            flag=true;
          //  cout<<"hello"<<endl;
          goto point;
        }

        if(quad_y3>750 ){

            flag=true;
          //  cout<<"hello"<<endl;
          goto point;
        }


        quad_x1+=speed;
        quad_x2+=speed;
        quad_x3+=speed;
        quad_x4+=speed;

    /*    if(r==1 ){
            quad_y1+=speed;
            quad_y2+=speed;
            quad_y3+=speed;
            quad_y4+=speed;
        }
    */


    }
        if(flag==true){

         if(quad_x1<=50){

            flag=false;
          //  cout<<"hello"<<endl;
          goto point;
        }

        if(quad_y1<=250 ){

            flag=false;
          //  cout<<"hello"<<endl;
          goto point;
        }


        quad_x1-=speed;
        quad_x2-=speed;
        quad_x3-=speed;
        quad_x4-=speed;

       /* if(r==2 ){

            quad_y1-=speed;
            quad_y2-=speed;
            quad_y3-=speed;
            quad_y4-=speed;
        } */




    }
       // cout<<quad_x1<<"\t"<<quad_y1<<"\t"<<quad_x3<<"\t"<<quad_y3<<"\t"<<endl;

        }


        void coll(float x1,float y1,cannon *oo3){




                    if(x1>=quad_x1 && x1<=quad_x4 && oo3->arrow_flag && ballon_flag){
                            if( y1 >= quad_y1 -50 && y1 <= quad_y2+50){
                                    marks +=100;


                                       this->ballon_flag=false;
                                        oo3->arrow_flag=false;

                            }

                    }







        }

        void show_score(){


                            sprintf(result,"%f",marks);
                                    glColor3ub(0,0,0);
                                    glRasterPos2d(600,750);
                                for(int i=0;i<7;i++){

                                    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,result[i]);

                                }



        }

        float score(){

            return marks;
        }

};
