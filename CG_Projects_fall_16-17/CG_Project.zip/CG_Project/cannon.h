
#include<windows.h>
#include <iostream>
#include<GL/glut.h>


using namespace std;


class cannon{

	public :

		float cannon_x1 = 400, cannon_x2 = 500, cannon_x3 = 500, cannon_x4 = 450, cannon_x5 = 400;
		float cannon_y1 = 0, cannon_y2 = 0, cannon_y3 = 50, cannon_y4 = 80,cannon_y5 = 50;

        float arrow_x1=cannon_x4,arrow_x2=cannon_x4,arrow_x3=cannon_x4-10,arrow_x4=cannon_x4+10;
        float arrow_y1=cannon_y4,arrow_y2=cannon_y4+50,arrow_y3=cannon_y4+40,arrow_y4=cannon_y4+40;


        float move_speed=3;

        bool arrow_flag=false;


    void disobj(){

        delete this;
    }


void drawarrow(){


        glBegin(GL_LINES);
        glColor3f(1.0, 0.0, 0.0);
        glVertex2i(arrow_x1,arrow_y1);
        glVertex2i(arrow_x2,arrow_y2);
        glEnd();







        glBegin(GL_TRIANGLES);
        glColor3f(1.0, 0.0, 0.0);
        glVertex2i(arrow_x2,(arrow_y2+10));
        glVertex2i(arrow_x3,arrow_y3);
        glVertex2i(arrow_x4,arrow_y4);
        glEnd();





	}






	void drawcannon(){

		glClear(GL_COLOR_BUFFER_BIT);

		glBegin(GL_POLYGON);

		glColor3f(1.0, 0.0, 0.0);
        glVertex2i(cannon_x1, cannon_y1);

        glColor3f(0.0, 1.0, 0.0);
		glVertex2i(cannon_x2, cannon_y2);

        glColor3f(0.0, 0.0, 1.0);
		glVertex2i(cannon_x3, cannon_y3);

        glColor3f(1.0, 1.0, 1.0);
		glVertex2i(cannon_x4, cannon_y4);

        glColor3f(0.0, 1.0, 1.0);
		glVertex2i(cannon_x5, cannon_y5);
        glEnd();



                if(arrow_flag && arrow_y2<= 780){

                    drawarrow();

                    arrow_y1+=1;
                    arrow_y2+=1;
                    arrow_y3+=1;
                    arrow_y4+=1;

                    if(arrow_y2>780)
                        arrow_flag= false;
                }




}









	void moveleft(){


             if(cannon_x1<=10){



            }

            else{

                cannon_x1-=move_speed;
                cannon_x2-=move_speed;
                cannon_x3-=move_speed;
                cannon_x4-=move_speed;
                cannon_x5-=move_speed;





            }



	}



	void moveright(){


        if(cannon_x2>=790){

                cannon_x3=790;

            }

            else{

                cannon_x1+=move_speed;
                cannon_x2+=move_speed;
                cannon_x3+=move_speed;
                cannon_x4+=move_speed;
                cannon_x5+=move_speed;



            }



	}


	void movearrow(){


        arrow_flag = true;

        arrow_x1=cannon_x4;
        arrow_x2=cannon_x4;
        arrow_x3=cannon_x4-10;
        arrow_x4=cannon_x4+10;


        arrow_y1=cannon_y4;
        arrow_y2=cannon_y4+50;
        arrow_y3=cannon_y4+40;
        arrow_y4=cannon_y4+40;


	}


    void delarrow(){


        arrow_flag = false;

        arrow_x1=cannon_x4;
        arrow_x2=cannon_x4;
        arrow_x3=cannon_x4-10;
        arrow_x4=cannon_x4+10;


        arrow_y1=cannon_y4;
        arrow_y2=cannon_y4+50;
        arrow_y3=cannon_y4+40;
        arrow_y4=cannon_y4+40;
	}

};
