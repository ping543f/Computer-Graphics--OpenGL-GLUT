#include<windows.h>
#include <iostream>
#include <stdlib.h>
#include<stdio.h>
#include<math.h>

#include <GL/freeglut.h>

#include "imageloader.h"

using namespace std;

float carX = 0;
float carY = 0;

float carX1 = 0;
float carY1 = 0;

int carStatus = 0;
int carStatus1 = 0;

float i = 0.0;    //movement of car
float m = 0.0;    //movement of students

int c = 1;
int w = 0;
int p =150;


GLuint _textureId;
GLuint _textureId1;



void drawScene() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

glPushMatrix();

	glTranslatef(0.0, -1.0, -5.0f);

	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(-3.0, -1.0, 0.0);

	glTexCoord2f(0.0, 6.0);
	glVertex3f(-3.0, 1.0, 0.0);

	glTexCoord2f(6.0, 6.0);
	glVertex3f(3.0, 1.0, 0.0);

	glTexCoord2f(6.0, 0.0);
	glVertex3f(3.0, -1.0, 0.0);

	glEnd();

 glPopMatrix();

glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, _textureId1);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTranslatef(0.0, 1.0, -5.0f);

	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(-1.0, -1.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(-1.0, 1.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(1.0, 1.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(1.0, -1.0, 0.0);

	glEnd();


glPopMatrix();

	glutSwapBuffers();
}

GLuint loadTexture(Image* image) {
	GLuint textureId;
	glGenTextures(1, &textureId); //Make room for our texture
	glBindTexture(GL_TEXTURE_2D, textureId); //Tell OpenGL which texture to edit
	//Map the image to the texture
	glTexImage2D(GL_TEXTURE_2D,                //Always GL_TEXTURE_2D
				 0,                            //0 for now
				 GL_RGB,                       //Format OpenGL uses for image
				 image->width, image->height,  //Width and height
				 0,                            //The border of the image
				 GL_RGB, //GL_RGB, because pixels are stored in RGB format
				 GL_UNSIGNED_BYTE, //GL_UNSIGNED_BYTE, because pixels are stored
				                   //as unsigned numbers
				 image->pixels);               //The actual pixel data
	return textureId; //Returns the id of the texture
}

void initialize() {

	glClearColor(1.0, 1.0, 1.0, 1.0);
	gluOrtho2D(0.0, 2000.0, 0.0, 1500.0);
	glLoadIdentity();
		glPointSize(0.0);
		glColor3f(1.0f, 1.0f, 1.0f);
	glMatrixMode(GL_PROJECTION);
	gluPerspective(45.0, 1.00, 1.0, 200.0);
	Image* image = loadBMP("G:/Series/text21/grass.bmp");
	Image* image1 = loadBMP("G:/Series/text21/tree.bmp");
	_textureId = loadTexture(image);
	_textureId1 = loadTexture(image1);
	delete image;


}

void lightSetting()
{

	GLfloat ambientIntensity[4] = {0.6, 0.6, 0.6, 1.0};

	GLfloat position[4] = {0.0, 1.0, 0.0, 0.0};

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_COLOR_MATERIAL);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);


	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientIntensity);

	glLightfv(GL_LIGHT0, GL_POSITION, position);


}



	void sky(){

	glBegin(GL_POLYGON); //Sky
	glColor3f(1.0, 1.0, 1.0);//white
	glVertex2i(0, 1500);
	glVertex2i(2000, 1500);
	glColor3f(0.529, .808, 0.980);//Light skyBlue
	glVertex2i(2000, 0);
	glVertex2i(0, 0);
	glEnd();

	}

float move,angle;



void DrawCircle(float cx, float cy, float r, int num_segments){

		 glBegin(GL_TRIANGLE_FAN);
		for (int i = 0; i < num_segments; i++)
		{
		float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);//get the current angle

		float x = r * cosf(theta);//calculate the x component
		float y = r * sinf(theta);//calculate the y component

		glVertex2f(x + cx, y + cy);//output vertex

		}
		glEnd();
	}

	void drawSun()
	{
		glColor3f(1.0, 0.843, 0.0); //Gold
		DrawCircle(1700, 1350, 85, 1000);
	}




	void road(){

	glBegin(GL_POLYGON); // road
	glColor3f(0.502, 0.502, 0.502);//Gray
	glVertex2i(0, 0);
	glVertex2i(2000, 0);
	glVertex2i(2000, 400);
	glVertex2i(0, 400);
	glEnd();



	glBegin(GL_POLYGON); // road
	glColor3f(1.0, 1.0, 1.0);//white middle
	glVertex2i(0, 185);
	glVertex2i(2000,185);
	glVertex2i(2000,215);
	glVertex2i(0,215);
	glEnd();
	}

	void movecar(int x)
	{
	glBegin(GL_POLYGON); //car body
	//glColor3f(0.0, 1.0, .498);//SpringGreen
	glColor3f(1.0, 1.0, 0.0);//SpringGreen
	glVertex2i(80,260);
	glVertex2i(260,260);
	glVertex2i(260,350);
	glVertex2i(80,350);

    glEnd();

    glBegin(GL_POLYGON); //car body color
	//glColor3f(1.0, 1.0, 1.0);//SpringGreen
	glColor3f(0.392, 0.584, 0.929);//cornlowerblue
	glVertex2i(80,335);
	glVertex2i(260,335);
	glVertex2i(260,340);
	glVertex2i(80,340);

    glEnd();


    glBegin(GL_POLYGON); //car door
	glColor3f(0.329,0.582,0.929);//cornlowerblue
	glVertex2i(200,290);
	glVertex2i(230,290);
	glVertex2i(230,330);
	glVertex2i(200,330);

    glEnd();

    glBegin(GL_POLYGON); //car window
	glColor3f(0.329,0.582,0.929);//cornlowerblue
	glVertex2i(150,305);
	glVertex2i(160,305);
	glVertex2i(160,315);
	glVertex2i(150,315);

    glEnd();

    glBegin(GL_POLYGON); //car window
	glColor3f(0.329,0.582,0.929);//cornlowerblue
	glVertex2i(130,305);
	glVertex2i(140,305);
	glVertex2i(140,315);
	glVertex2i(130,315);

    glEnd();

    glBegin(GL_POLYGON); //car window
	glColor3f(0.329,0.582,0.929);//cornlowerblue
	glVertex2i(110,305);
	glVertex2i(120,305);
	glVertex2i(120,315);
	glVertex2i(110,315);

    glEnd();

    glBegin(GL_POLYGON); //car chaka
	glColor3f(0.329,0.582,0.929);//cornlowerblue
	glVertex2i(120,260);
	glVertex2i(140,260);
	glVertex2i(140,280);
	glVertex2i(120,280);

    glEnd();


    glBegin(GL_POLYGON); //car chaka
	glColor3f(0.329,0.582,0.929);//cornlowerblue
	glVertex2i(170,260);
	glVertex2i(190,260);
	glVertex2i(190,280);
	glVertex2i(170,280);

    glEnd();






	}

	void movecar1(int x)
	{
	glBegin(GL_POLYGON); //car body
	//glColor3f(0.0, 0.0, 0.498);//SpringGreen
	glColor3f(0.000, 1.000, 0.498);//SpringGreen
	glVertex2i(1920,40);
	glVertex2i(1740,40);
	glVertex2i(1740,130);
	glVertex2i(1920,130);

    glEnd();

    glBegin(GL_POLYGON); //car body color
	//glColor3f(1.0, 1.0, 1.0);//SpringGreen
	glColor3f(0.000, 0.000, 0.502);//cornlowerblue
	glVertex2i(1920,115);
	glVertex2i(1740,115);
	glVertex2i(1740,120);
	glVertex2i(1920,120);

    glEnd();

    glBegin(GL_POLYGON); //car door
	glColor3f(0.000, 0.000, 0.502);//cornlowerblue
	glVertex2i(1800,70);
	glVertex2i(1770,70);
	glVertex2i(1770,110);
	glVertex2i(1800,110);

    glEnd();

    glBegin(GL_POLYGON); //car window
	glColor3f(0.000, 0.000, 0.502);//cornlowerblue
	glVertex2i(1850,85);
	glVertex2i(1860,85);
	glVertex2i(1860,95);
	glVertex2i(1850,95);

    glEnd();


    glBegin(GL_POLYGON); //car window
	glColor3f(0.000, 0.000, 0.502);//cornlowerblue
	glVertex2i(1870,85);
	glVertex2i(1880,85);
	glVertex2i(1880,95);
	glVertex2i(1870,95);

    glEnd();

    glBegin(GL_POLYGON); //car window
	glColor3f(0.000, 0.000, 0.502);//cornlowerblue
	glVertex2i(1890,85);
	glVertex2i(1900,85);
	glVertex2i(1900,95);
	glVertex2i(1890,95);

    glEnd();




	}




	void car()
	{
		if (carStatus == 1)
		{
			carX +=1;
		}
		if (carX>2000)
		{
			carX = -600;
		}
		glPushMatrix();
		glTranslatef(carX, carY, 0);
		movecar(1);
		glPopMatrix();
	}



	void car1()
{
    if (carStatus1 ==1)
    {
        if(carX1 == p  && p>0 && carX1>0)
        {
            carStatus1=0;
        }

        else
            carX1 -=1;
    }
    if (carX1<-1500)
    {
        carX1 = -1500;
        carStatus1=0;
    }

    printf("p: %d\n",p);
    printf("car: %d\n",carX1);
    glPushMatrix();
    glTranslatef(carX1, carY1, 0);
    movecar1(1);
    glPopMatrix();
}




void keyboard(unsigned char key,int x,int y)

	{

		if(key=='o'||key=='O')
	   {		               //car start
            carStatus = 1;
	        carStatus1 = 1;
	        printf("car: %d\n",carX1);

		}


		else if(key== 'f'||key=='F')     //car off
			//car stop
		{
			carStatus = 0;
            carStatus1 = 0;

		}

		else if(key=='x' || key =='X')
        {
            if (w > 650)
            {
                w = 0;
                p=0;
            }
            w +=10;
            p+=150;
        }


	}

	void draw_pixel(GLint cx, GLint cy)
{

	glBegin(GL_POINTS);
	glVertex2i(cx, cy);
	glEnd();
}

void drawTringle(int x, int y, int x1, int y1, int x2, int y2, float r, float g, float b) {
	glBegin(GL_TRIANGLES);
	glColor3f(r, g, b);
	glVertex2f(x, y);
	glVertex2f(x1, y1);
	glVertex2f(x2, y2);
	glEnd();


}
void drawBOX(int x, int x1, int y, int y1, float r, float g, float b) {
	glBegin(GL_POLYGON);
	glColor3f(r, g, b);
	glVertex2f(x, y);
	glVertex2f(x, y1);
	glVertex2f(x1, y1);
	glVertex2f(x1, y);
	glEnd();
}

void Human()
{
	drawBOX(150 + w, 170 + w, 180, 200, 1.000, 0.627, 0.478);
	drawBOX(158 + w, 162 + w, 170, 180, 0.804, 0.361, 0.361);
	drawBOX(140 + w, 180 + w, 110, 170, 0.545, 0.000, 0.000);

	if (w % 2 == 0) {


		drawTringle(150 + w, 140, 150 + w, 160, 200 + w, 130, 1.000, 0.000, 0.000);
		drawTringle(140 + w, 140, 140 + w, 160, 110 + w, 120, 0.698, 0.133, 0.133);
		drawTringle(140 + w, 110, 130 + w, 50, 180 + w, 110, 0.184, 0.310, 0.310);
		drawTringle(180 + w, 110, 180 + w, 50, 160 + w, 86, 0.412, 0.412, 0.412);

	}
	else {
		drawTringle(150 + w, 140, 150 + w, 160, 100 + w, 130, 1.000, 0.000, 0.000);
		drawTringle(180 + w, 140, 180 + w, 160, 210 + w, 120, 0.698, 0.133, 0.133);
		drawTringle(140 + w, 110, 190 + w, 50, 178 + w, 110, 0.184, 0.310, 0.310);
		drawTringle(140 + w, 110, 138 + w, 50, 160 + w, 86, 0.412, 0.412, 0.412);

	}

}

	/*void keyboard(unsigned char key,int x,int y)

	{

		if(key=='o'||key=='O')
	   {		               //car start
	    carStatus = 1;
	    carStatus1 = 1;

		}


		else if(key== 'f'||key=='F')     //car off
			//car stop
		{
			carStatus = 0;
            carStatus1 = 0;

		}
	}*/




void house(){


   glBegin(GL_POLYGON); //house base
	//glColor3f(0.196, .804, .196);//spring green
	glColor3f(0.000, 0.000, 0.502);
	glVertex2i(100,550);
	glVertex2i(770,550);
	glVertex2i(770,615);
	glVertex2i(100,615);

    glEnd();

     glBegin(GL_POLYGON); //house
	glColor3f(0.961, 0.871, 0.702);//spring green
	glVertex2i(150,615);
	glVertex2i(720,615);
	glVertex2i(720,1015);
	glVertex2i(150,1015);

    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3f(0,0,0);
    glVertex2i(150,1015);
    glVertex2i(720,1015);
    glVertex2i(415,1175);

    glEnd();

    glBegin(GL_TRIANGLES);
    glColor3f(1.0, 0.0, 0.0);//chad
    glVertex2i(170,1020);
    glVertex2i(700,1020);
    glVertex2i(415,1165);

    glEnd();

    glBegin(GL_POLYGON); //house black side
	glColor3f(0.0, 0.0, 0.0);//
	glVertex2i(150,615);
	glVertex2i(155,615);
	glVertex2i(155,1015);
	glVertex2i(150,1015);

    glEnd();

    glBegin(GL_POLYGON); //house black side
	glColor3f(0.0, 0.0, 0.0);//
	glVertex2i(715,615);
	glVertex2i(720,615);
	glVertex2i(720,1015);
	glVertex2i(715,1015);

    glEnd();

    glBegin(GL_POLYGON); //house door
	glColor3f(0.0, 0.0, 0.0);//
	glVertex2i(500,650);
	glVertex2i(650,650);
	glVertex2i(650,870);
	glVertex2i(500,870);

    glEnd();

    glBegin(GL_POLYGON); //house door
	glColor3f(0.502, 0.0, 0.0);//
	glVertex2i(510,660);
	glVertex2i(640,660);
	glVertex2i(640,860);
	glVertex2i(510,860);

    glEnd();

     glBegin(GL_POLYGON); //house window
	glColor3f(0.502, 0.0, 0.0);//
	glVertex2i(220,830);
	glVertex2i(400,830);
	glVertex2i(400,930);
	glVertex2i(220,930);

    glEnd();

    glBegin(GL_POLYGON); //house window window
	glColor3f(0.855, 0.647, 0.125);//
	glVertex2i(230,840);
	glVertex2i(390,840);
	glVertex2i(390,920);
	glVertex2i(230,920);

    glEnd();

    glBegin(GL_POLYGON); //solar stand
	glColor3f(	0.412, 0.412, 0.412);//
	glVertex2i(110,615);
	glVertex2i(140,615);
	glVertex2i(140,1150);
	glVertex2i(110,1150);

    glEnd();


     glBegin(GL_POLYGON); //solar
	glColor3f(0.098, 0.098, 0.439);//
	glVertex2i(50,1150);
	glVertex2i(220,1150);
	glVertex2i(220,1275);
	glVertex2i(50,1275);

    glEnd();

    glBegin(GL_POLYGON); //solar divider
	glColor3f(0.827, 0.827, 0.827);//
	glVertex2i(50,1212);
	glVertex2i(220,1212);
	glVertex2i(220,1222);
	glVertex2i(50,1222);

    glEnd();





}

void windmill(){


glBegin(GL_POLYGON); //wind millbase
	glColor3f(1.000, 0.271, 0.000);
	glVertex2i(1550,700);
	glVertex2i(1650,700);
	glVertex2i(1650,740);
	glVertex2i(1550,740);

    glEnd();




    glBegin(GL_POLYGON); //wind stand
	glColor3f(1.000, 0.271, 0.000);
	glVertex2i(1590,740);
	glVertex2i(1610,740);
	glVertex2i(1610,1000);
	glVertex2i(1590,1000);

	glEnd();




glBegin(GL_POLYGON); //wind middle
	glColor3f(1.000, 0.271, 0.000);
	glVertex2i(1580,950);
	glVertex2i(1620,950);
	glVertex2i(1620,1000);
	glVertex2i(1580,1000);

	glEnd();

	glBegin(GL_POLYGON); //windmill wing right
	glColor3f(1.000, 0.271, 0.000);
	glVertex2i(1620,970);
	glVertex2i(1820,970);
	glVertex2i(1820,980);
	glVertex2i(1620,980);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1.000, 0.271, 0.000);
	glVertex2i(1700,955);
	glVertex2i(1820,955);
	glVertex2i(1820,970);
	glVertex2i(1700,970);

	glEnd();



	glBegin(GL_POLYGON); //windmill wing top
	glColor3f(1.000, 0.271, 0.000);
	glVertex2i(1595,1000);
	glVertex2i(1605,1000);
	glVertex2i(1605,1200);
	glVertex2i(1595,1200);

	glEnd();

	glBegin(GL_POLYGON);
	glColor3f(1.000, 0.271, 0.000);
	glVertex2i(1605,1080);
	glVertex2i(1620,1080);
	glVertex2i(1620,1200);
	glVertex2i(1605,1200);

	glEnd();


glBegin(GL_POLYGON); //windmill wing left
	glColor3f(1.000, 0.271, 0.000);
	glVertex2i(1580,970);
	glVertex2i(1380,970);
	glVertex2i(1380,980);
	glVertex2i(1580,980);

	glEnd();


	glBegin(GL_POLYGON);
	glColor3f(1.000, 0.271, 0.000);
	glVertex2i(1500,980);
	glVertex2i(1500,995);
	glVertex2i(1380,995);
	glVertex2i(1380,980);

	glEnd();

}

void Grass(){

glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(300, 450);
	glVertex2i(295, 470);
	glVertex2i(275, 480);
	glVertex2i(295, 470);
	glVertex2i(285, 500);
	glVertex2i(295, 470);
	glVertex2i(300, 420);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(305, 480);
	glVertex2i(325, 500);
	glVertex2i(315, 470);
	glVertex2i(325, 480);
	glVertex2i(315, 470);
	glVertex2i(310, 450);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(400, 450);
	glVertex2i(395, 470);
	glVertex2i(375, 480);
	glVertex2i(395, 470);
	glVertex2i(385, 500);
	glVertex2i(395, 470);
	glVertex2i(400, 420);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(405, 480);
	glVertex2i(425, 500);
	glVertex2i(415, 470);
	glVertex2i(425, 480);
	glVertex2i(415, 470);
	glVertex2i(410, 450);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(500, 460);
	glVertex2i(495, 480);
	glVertex2i(475, 490);
	glVertex2i(495, 480);
	glVertex2i(485, 510);
	glVertex2i(495, 480);
	glVertex2i(500, 430);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(505, 490);
	glVertex2i(525, 510);
	glVertex2i(515, 480);
	glVertex2i(525, 490);
	glVertex2i(515, 480);
	glVertex2i(510, 460);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(900, 460);
	glVertex2i(895, 480);
	glVertex2i(875, 490);
	glVertex2i(895, 480);
	glVertex2i(885, 510);
	glVertex2i(895, 480);
	glVertex2i(900, 430);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(905, 490);
	glVertex2i(925, 510);
	glVertex2i(915, 480);
	glVertex2i(925, 490);
	glVertex2i(915, 480);
	glVertex2i(910, 460);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(800, 440);
	glVertex2i(795, 460);
	glVertex2i(775, 470);
	glVertex2i(795, 460);
	glVertex2i(785, 490);
	glVertex2i(795, 460);
	glVertex2i(800, 410);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(805, 470);
	glVertex2i(825, 490);
	glVertex2i(815, 460);
	glVertex2i(825, 470);
	glVertex2i(815, 460);
	glVertex2i(810, 440);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(200, 440);
	glVertex2i(195, 460);
	glVertex2i(175, 470);
	glVertex2i(195, 460);
	glVertex2i(185, 490);
	glVertex2i(195, 460);
	glVertex2i(200, 410);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(205, 470);
	glVertex2i(225, 490);
	glVertex2i(215, 460);
	glVertex2i(225, 470);
	glVertex2i(215, 460);
	glVertex2i(210, 440);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(600, 450);
	glVertex2i(595, 470);
	glVertex2i(575, 480);
	glVertex2i(595, 470);
	glVertex2i(585, 500);
	glVertex2i(595, 470);
	glVertex2i(600, 420);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(605, 480);
	glVertex2i(625, 500);
	glVertex2i(615, 470);
	glVertex2i(625, 480);
	glVertex2i(615, 470);
	glVertex2i(610, 450);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(750, 450);
	glVertex2i(745, 470);
	glVertex2i(725, 480);
	glVertex2i(745, 470);
	glVertex2i(735, 500);
	glVertex2i(745, 470);
	glVertex2i(750, 420);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(755, 480);
	glVertex2i(775, 500);
	glVertex2i(765, 470);
	glVertex2i(775, 480);
	glVertex2i(765, 470);
	glVertex2i(710, 450);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(700, 450);
	glVertex2i(695, 470);
	glVertex2i(675, 480);
	glVertex2i(695, 470);
	glVertex2i(685, 500);
	glVertex2i(695, 470);
	glVertex2i(700, 420);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(705, 480);
	glVertex2i(675, 500);
	glVertex2i(715, 470);
	glVertex2i(725, 480);
	glVertex2i(715, 470);
	glVertex2i(660, 450);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(950, 450);
	glVertex2i(945, 470);
	glVertex2i(925, 480);
	glVertex2i(945, 470);
	glVertex2i(935, 500);
	glVertex2i(945, 470);
	glVertex2i(950, 420);

	glVertex2i(955, 480);
	glVertex2i(925, 500);
	glVertex2i(965, 470);
	glVertex2i(975, 480);
	glVertex2i(965, 470);
	glVertex2i(910, 450);

    glEnd();

    glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(1000, 450);
	glVertex2i(995, 470);
	glVertex2i(975, 480);
	glVertex2i(995, 470);
	glVertex2i(985, 500);
	glVertex2i(995, 470);
	glVertex2i(1000, 420);

	glVertex2i(1005, 480);
	glVertex2i(975, 500);
	glVertex2i(1015, 470);
	glVertex2i(1025, 480);
	glVertex2i(1015, 470);
	glVertex2i(960, 450);

    glEnd();

    glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(1100, 450);
	glVertex2i(1095, 470);
	glVertex2i(1075, 480);
	glVertex2i(1095, 470);
	glVertex2i(1085, 500);
	glVertex2i(1095, 470);
	glVertex2i(1100, 420);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(1105, 480);
	glVertex2i(1075, 500);
	glVertex2i(1115, 470);
	glVertex2i(1125, 480);
	glVertex2i(1115, 470);
	glVertex2i(1060, 450);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(1200, 440);
	glVertex2i(1195, 460);
	glVertex2i(1175, 470);
	glVertex2i(1195, 460);
	glVertex2i(1185, 490);
	glVertex2i(1195, 460);
	glVertex2i(1200, 410);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(1205, 470);
	glVertex2i(1175, 490);
	glVertex2i(1215, 460);
	glVertex2i(1225, 470);
	glVertex2i(1215, 460);
	glVertex2i(1160, 440);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(1300, 440);
	glVertex2i(1295, 460);
	glVertex2i(1275, 470);
	glVertex2i(1295, 460);
	glVertex2i(1285, 490);
	glVertex2i(1295, 460);
	glVertex2i(1300, 410);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(1305, 470);
	glVertex2i(1275, 490);
	glVertex2i(1315, 460);
	glVertex2i(1325, 470);
	glVertex2i(1315, 460);
	glVertex2i(1260, 440);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(1400, 440);
	glVertex2i(1395, 460);
	glVertex2i(1375, 470);
	glVertex2i(1395, 460);
	glVertex2i(1385, 490);
	glVertex2i(1395, 460);
	glVertex2i(1400, 410);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(1405, 470);
	glVertex2i(1375, 490);
	glVertex2i(1415, 460);
	glVertex2i(1425, 470);
	glVertex2i(1415, 460);
	glVertex2i(1360, 440);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(1500, 440);
	glVertex2i(1495, 460);
	glVertex2i(1475, 470);
	glVertex2i(1495, 460);
	glVertex2i(1485, 490);
	glVertex2i(1495, 460);
	glVertex2i(1500, 410);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(1505, 470);
	glVertex2i(1475, 490);
	glVertex2i(1515, 460);
	glVertex2i(1525, 470);
	glVertex2i(1515, 460);
	glVertex2i(1460, 440);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(1600, 440);
	glVertex2i(1595, 460);
	glVertex2i(1575, 470);
	glVertex2i(1595, 460);
	glVertex2i(1585, 490);
	glVertex2i(1595, 460);
	glVertex2i(1600, 410);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(1605, 470);
	glVertex2i(1575, 490);
	glVertex2i(1615, 460);
	glVertex2i(1625, 470);
	glVertex2i(1615, 460);
	glVertex2i(1560, 440);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(1700, 440);
	glVertex2i(1695, 460);
	glVertex2i(1675, 470);
	glVertex2i(1695, 460);
	glVertex2i(1685, 490);
	glVertex2i(1695, 460);
	glVertex2i(1700, 410);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(1705, 470);
	glVertex2i(1675, 490);
	glVertex2i(1715, 460);
	glVertex2i(1725, 470);
	glVertex2i(1715, 460);
	glVertex2i(1660, 440);
	glEnd();

	glBegin(GL_POLYGON); //Grass
	glColor3f(0.000, 0.392, 0.000);
	glVertex2i(1800, 440);
	glVertex2i(1795, 460);
	glVertex2i(1775, 470);
	glVertex2i(1795, 460);
	glVertex2i(1785, 490);
	glVertex2i(1795, 460);
	glVertex2i(1800, 410);
	//glColor3f(0.000, 1.000, 0.000);
	glVertex2i(1805, 470);
	glVertex2i(1775, 490);
	glVertex2i(1815, 460);
	glVertex2i(1825, 470);
	glVertex2i(1815, 460);
	glVertex2i(1760, 440);
	glEnd();



}


	void myDisplay(void)
	{
			 sky();
			 drawSun();

			 road();
			 drawScene();
			 car();
			 car1();
			 house();
			 windmill();
			 Human();
			 Grass();
			// drawScene();
			 glFlush();
			 glutPostRedisplay();
			 glutSwapBuffers();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(2000,1500);
	glutInitWindowPosition(0, 0);


	glutCreateWindow("Green_city");
	initialize();
	lightSetting();
	glutDisplayFunc(myDisplay);
	glutKeyboardFunc(keyboard);
	//glutDisplayFunc(myDisplay);

	glutMainLoop();


	return 0;
}









