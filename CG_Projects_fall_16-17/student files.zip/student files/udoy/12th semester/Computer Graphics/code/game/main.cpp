/*
 * GLUT Shapes Demo
 *
 * Written by Nigel Stewart November 2003
 *
 * This program is test harness for the sphere, cone
 * and torus shapes in GLUT.
 *
 * Spinning wireframe and smooth shaded shapes are
 * displayed until the ESC or q key is pressed.  The
 * number of geometry stacks and slices can be adjusted
 * using the + and - keys.
 */
#include <windows.h>
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include <iostream>
#include <stdlib.h>
#include <cstdlib>
#include <stdio.h>
#include "imageloader.h"

using namespace std;

/* GLUT callback Handlers */
float baskx=0, chicx=0, egg1x=0, egg1y=1.0;
int chicd=1, egg1c=0, score=0, life=5, te=0, numberOfQuotes=0;
char quote[6][80];
//Called when a key is pressed
void handleKeypress(int key, int x, int y)
{
    if(key==27)
    {
            //Escape key
            exit(0);
    }
    else if(key==GLUT_KEY_LEFT && baskx>-2.6f)
    {
        baskx-=0.2f;
        glutPostRedisplay();
    }
    else if(key==GLUT_KEY_RIGHT && baskx<2.6f)
    {
        baskx+=0.2f;
        glutPostRedisplay();
    }
}

//Makes the image into a texture and returns the id of the texture
GLuint loadTexture(Image* image)
{
    GLuint textureId;
    glGenTextures(1, &textureId); //Make room for our texture
    glBindTexture(GL_TEXTURE_2D, textureId); //Tell OpenGL which texture to edit
    //Map the image to the texture
    glTexImage2D(GL_TEXTURE_2D,0,GL_RGB,image->width, image->height,0,GL_RGB,GL_UNSIGNED_BYTE,image->pixels);
    return textureId;
}

GLuint basket, background, chicken, egg, over;
//Initializes 3D rendering
void initRendering()
{
    //Makes 3D drawing work when something is in front of something else
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
    glEnable(GL_LIGHT1);
    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);

    Image* image = loadBMP("D:\\student files\\udoy\\12th semester\\Computer Graphics\\code\\game\\vtr.bmp");
    chicken = loadTexture(image);
    image = loadBMP("D:\\student files\\udoy\\12th semester\\Computer Graphics\\code\\game\\basket.bmp");
    basket = loadTexture(image);
    image = loadBMP("D:\\student files\\udoy\\12th semester\\Computer Graphics\\code\\game\\haystack.bmp");
    background = loadTexture(image);
    image = loadBMP("D:\\student files\\udoy\\12th semester\\Computer Graphics\\code\\game\\egg.bmp");
    egg = loadTexture(image);
    image = loadBMP("D:\\student files\\udoy\\12th semester\\Computer Graphics\\code\\game\\over.bmp");
    over = loadTexture(image);
    delete image;
}

static void resize(int width, int height)
{
    const float ar = (float) width / (float) height;

    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-ar, ar, -1.0, 1.0, 2.0, 100.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity() ;
}

int random()
{
    int number;
    number = (rand()%1000);
    return number;
}
float angle = 30.0f;

void drawHeart(float x)
{
    glPushMatrix();
    glTranslatef(x, 2.8f, 0.0f);
    glColor3f(1.0f, 0.0f, 0.0f);
    glBegin(GL_POLYGON);
    glVertex3f(0.0f, -0.04f, 0.0f);
    glVertex3f(0.03f, -0.01f, 0.0f);
    glVertex3f(0.05f, 0.0f, 0.0f);
    glVertex3f(0.09f, 0.0f, 0.0f);
    glVertex3f(0.11f, -0.01f, 0.0f);
    glVertex3f(0.13f, -0.03f, 0.0f);
    glVertex3f(0.14f, -0.05f, 0.0f);
    glVertex3f(0.14f, -0.09f, 0.0f);
    glVertex3f(0.13f, -0.11f, 0.0f);
    glVertex3f(0.05f, -0.19f, 0.0f);
    glVertex3f(0.0f, -0.22f, 0.0f);
    glEnd();
    glScalef(-1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON);
    glVertex3f(0.0f, -0.04f, 0.0f);
    glVertex3f(0.03f, -0.01f, 0.0f);
    glVertex3f(0.05f, 0.0f, 0.0f);
    glVertex3f(0.09f, 0.0f, 0.0f);
    glVertex3f(0.11f, -0.01f, 0.0f);
    glVertex3f(0.13f, -0.03f, 0.0f);
    glVertex3f(0.14f, -0.05f, 0.0f);
    glVertex3f(0.14f, -0.09f, 0.0f);
    glVertex3f(0.13f, -0.11f, 0.0f);
    glVertex3f(0.05f, -0.19f, 0.0f);
    glVertex3f(0.0f, -0.22f, 0.0f);
    glEnd();
    glPopMatrix();
}

void RenderToDisplay();

void drawScene()
{
    // Clear information from last draw
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW); //Switch to the drawing perspective
    glLoadIdentity(); //Reset the drawing perspective

    //Add ambient light
    GLfloat ambientColor[] = {0.2f, 0.2f, 0.2f, 1.0f};
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientColor);

    //Add positioned light
    GLfloat lightColor0[] = {1.0f, 1.0f, 1.0f, 1.0f};
    GLfloat lightPos0[] = {0.0f, 5.0f, 5.0f, 1.0f};
    glLightfv(GL_LIGHT0, GL_DIFFUSE, lightColor0);
    glLightfv(GL_LIGHT0, GL_POSITION, lightPos0);

    glTranslatef(0.0f, 0.0f, -6.0f);

    //Background
    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, background);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    glPushMatrix();
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-4.0f, -4.0f, -2.0f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(4.0f, -4.0f, -2.0f);
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(4.0f, 4.0f, -2.0f);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(-4.0f, 4.0f, -2.0f);
    glEnd();
    glPopMatrix();


    //Chicken
    glBindTexture(GL_TEXTURE_2D, chicken);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    /*glPushMatrix();
    glColor3f(1.0f, 1.0f, 1.0f);
    glTranslatef(chicx,1.7f, 0.0f);
    glScalef(0.1f, 0.1f, 1.0f);
    glScalef(-chicd, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glTexCoord2f(186.0/256, 53.0/256);
    glVertex3f(186.0-128, 128-53.0, 0.0f);
    glTexCoord2f(185.0/256, 39.0/256);
    glVertex3f(185.0-128, 128-39.0, 0.0f);
    glTexCoord2f(190.0/256, 31.0/256);
    glVertex3f(190.0-128, 128-31.f, 0.0f);
    glTexCoord2f(193.0/256, 31.0/256);
    glVertex3f(193.0-128, 128-31.0f, 0.0f);
    glEnd();
    glPopMatrix();*/

    glPushMatrix();
    glColor3f(1.0f, 1.0f, 1.0f);
    glTranslatef(chicx,1.7f, 0.0f);
    glScalef(0.7f, 0.7f, 0.7f);
    glScalef(-chicd, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, 0.0f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, 0.0f);
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, 0.0f);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, 0.0f);
    glEnd();
    glPopMatrix();


    //Egg
    glBindTexture(GL_TEXTURE_2D, egg);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);


    glPushMatrix();
    glColor3f(1.0f, 1.0f, 1.0f);
    glTranslatef(egg1x,egg1y, 0.0f);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-0.15f, -0.15f, 0.0f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(0.15f, -0.15f, 0.0f);
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(0.15f, 0.15f, 0.0f);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(-0.15f, 0.15f, 0.0f);
    glEnd();
    glPopMatrix();

    //Heart
    for(int i=1;i<=life;i++)
    {
        drawHeart(i*0.5f);
    }

    //Basket
    glBindTexture(GL_TEXTURE_2D, basket);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);

    glPushMatrix();
    glTranslatef(baskx, -2.0f, 0.0f);
    glScalef(0.2f, 0.2f, 0.2f);
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glNormal3f(-1.75f, -0.5f, 0.66144f);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(-2.0f, 0.0f, 0.0f);
    glTexCoord2f(0.125f, 1.0f);
    glVertex3f(-1.5f, 0.0f, 1.32288f);
    glTexCoord2f(0.125f, 0.5f);
    glVertex3f(-1.5f, -1.0f, 1.32288f);
    glTexCoord2f(0.0f, 0.5f);
    glVertex3f(-2.0f, -1.0f, 0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(-1.25f, -0.5f, 1.527f);
    glTexCoord2f(0.125f, 1.0f);
    glVertex3f(-1.5f, 0.0f, 1.32288f);
    glTexCoord2f(0.25f, 1.0f);
    glVertex3f(-1.0f, 0.0f, 1.732f);
    glTexCoord2f(0.25f, 0.5f);
    glVertex3f(-1.0f, -1.0f, 1.732f);
    glTexCoord2f(0.125f, 0.5f);
    glVertex3f(-1.5f, -1.0f, 1.32288f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(-0.75f, -0.5f, 1.834f);
    glTexCoord2f(0.25f, 1.0f);
    glVertex3f(-1.0f, 0.0f, 1.732f);
    glTexCoord2f(0.375f, 1.0f);
    glVertex3f(-0.5f, 0.0f, 1.9365f);
    glTexCoord2f(0.375f, 0.5f);
    glVertex3f(-0.5f, -1.0f, 1.9365f);
    glTexCoord2f(0.25f, 0.5f);
    glVertex3f(-1.0f, -1.0f, 1.732f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(-0.25f, -0.5f, 0.968f);
    glTexCoord2f(0.375f, 1.0f);
    glVertex3f(-0.5f, 0.0f, 1.9365f);
    glTexCoord2f(0.5f, 1.0f);
    glVertex3f(0.0f, 0.0f, 2.0f);
    glTexCoord2f(0.5f, 0.5f);
    glVertex3f(0.0f, -1.0f, 2.0f);
    glTexCoord2f(0.375f, 0.5f);
    glVertex3f(-0.5f, -1.0f, 1.9365f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(0.25f, -0.5f, 1.968f);
    glTexCoord2f(0.5f, 1.0f);
    glVertex3f(0.0f, 0.0f, 2.0f);
    glTexCoord2f(0.625f, 1.0f);
    glVertex3f(0.5f, 0.0f, 1.9365f);
    glTexCoord2f(0.625f, 0.5f);
    glVertex3f(0.5f, -1.0f, 1.9365f);
    glTexCoord2f(0.5f, 0.5f);
    glVertex3f(0.0f, -1.0f, 2.0f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(0.75f, -0.5f, 1.834f);
    glTexCoord2f(0.625f, 1.0f);
    glVertex3f(0.5f, 0.0f, 1.9365f);
    glTexCoord2f(0.75f, 1.0f);
    glVertex3f(1.0f, 0.0f, 1.732f);
    glTexCoord2f(0.75f, 0.5f);
    glVertex3f(1.0f, -1.0f, 1.732f);
    glTexCoord2f(0.625f, 0.5f);
    glVertex3f(0.5f, -1.0f, 1.9365f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(1.25f, -0.5f, 1.527f);
    glTexCoord2f(0.75f, 1.0f);
    glVertex3f(1.0f, 0.0f, 1.732f);
    glTexCoord2f(0.875f, 1.0f);
    glVertex3f(1.5f, 0.0f, 1.32288f);
    glTexCoord2f(0.875f, 0.5f);
    glVertex3f(1.5f, -1.0f, 1.32288f);
    glTexCoord2f(0.75f, 0.5f);
    glVertex3f(1.0f, -1.0f, 1.732f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(1.75f, -0.5f, 0.66144f);
    glTexCoord2f(0.875f, 1.0f);
    glVertex3f(1.5f, 0.0f, 1.32288f);
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(2.0f, 0.0f, 0.0f);
    glTexCoord2f(1.0f, 0.5f);
    glVertex3f(2.0f, -1.0f, 0.0f);
    glTexCoord2f(0.875f, 0.5f);
    glVertex3f(1.5f, -1.0f, 1.32288f);
    glEnd();

    glBegin(GL_TRIANGLES);
    glNormal3f(-1.75f, -1.5f, 0.66144f);
    glTexCoord2f(0.0f, 0.5f);
    glVertex3f(-2.0f, -1.0f, 0.0f);
    glTexCoord2f(0.125f, 0.5f);
    glVertex3f(-1.5f, -1.0f, 1.32288f);
    glTexCoord2f(0.125f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(-1.25f, -1.5f, 1.527f);
    glTexCoord2f(0.125f, 0.5f);
    glVertex3f(-1.5f, -1.0f, 1.32288f);
    glTexCoord2f(0.25f, 0.5f);
    glVertex3f(-1.0f, -1.0f, 1.732f);
    glTexCoord2f(0.25f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glTexCoord2f(0.125f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(-0.75f, -1.5f, 1.834f);
    glTexCoord2f(0.25f, 0.5f);
    glVertex3f(-1.0f, -1.0f, 1.732f);
    glTexCoord2f(0.375f, 0.5f);
    glVertex3f(-0.5f, -1.0f, 1.9365f);
    glTexCoord2f(0.375f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glTexCoord2f(0.25f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(-0.25f, -1.5f, 0.968f);
    glTexCoord2f(0.375f, 0.5f);
    glVertex3f(-0.5f, -1.0f, 1.9365f);
    glTexCoord2f(0.5f, 0.5f);
    glVertex3f(0.0f, -1.0f, 2.0f);
    glTexCoord2f(0.5f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glTexCoord2f(0.375f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(0.25f, -1.5f, 1.968f);
    glTexCoord2f(0.5f, 0.5f);
    glVertex3f(0.0f, -1.0f, 2.0f);
    glTexCoord2f(0.625f, 0.5f);
    glVertex3f(0.5f, -1.0f, 1.9365f);
    glTexCoord2f(0.625f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glTexCoord2f(0.5f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(0.75f, -1.5f, 1.834f);
    glTexCoord2f(0.625f, 0.5f);
    glVertex3f(0.5f, -1.0f, 1.9365f);
    glTexCoord2f(0.75f, 0.5f);
    glVertex3f(1.0f, -1.0f, 1.732f);
    glTexCoord2f(0.75f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glTexCoord2f(0.625f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(1.25f, -1.5f, 1.527f);
    glTexCoord2f(0.75f, 0.5f);
    glVertex3f(1.0f, -1.0f, 1.732f);
    glTexCoord2f(0.875f, 0.5f);
    glVertex3f(1.5f, -1.0f, 1.32288f);
    glTexCoord2f(0.875f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glTexCoord2f(0.75f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glEnd();

    glBegin(GL_QUADS);
    glNormal3f(1.75f, -1.5f, 0.66144f);
    glTexCoord2f(0.875f, 0.5f);
    glVertex3f(1.5f, -1.0f, 1.32288f);
    glTexCoord2f(1.0f, 0.5f);
    glVertex3f(2.0f, -1.0f, 0.0f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glTexCoord2f(0.875f, 0.0f);
    glVertex3f(0.0f, -2.0f, 0.0f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_POLYGON);
    glVertex3f(-2.0f, 0.0f, 0.0f);
    glVertex3f(-1.5f, 0.0f, 1.32288f);
    glVertex3f(-1.0f, 0.0f, 1.732f);
    glVertex3f(-0.5f, 0.0f, 1.9365f);
    glVertex3f(0.0f, 0.0f, 2.0f);
    glVertex3f(0.5f, 0.0f, 1.9365f);
    glVertex3f(1.0f, 0.0f, 1.732f);
    glVertex3f(1.5f, 0.0f, 1.32288f);
    glVertex3f(2.0f, 0.0f, 0.0f);
    glVertex3f(1.5f, 0.0f, -1.32288f);
    glVertex3f(1.0f, 0.0f, -1.732f);
    glVertex3f(0.5f, 0.0f, -1.9365f);
    glVertex3f(0.0f, 0.0f, -2.0f);
    glVertex3f(-0.5f, 0.0f, -1.9365f);
    glVertex3f(-1.0f, 0.0f, -1.732f);
    glVertex3f(-1.5f, 0.0f, -1.32288f);
    glEnd();
    glPopMatrix();

    //Score
    char a[5];
	itoa(score, a, 10);
	strcpy(quote[0], a);
	//strcpy(quote[3], &score);
	numberOfQuotes = 1;
	glPushMatrix();
	glTranslatef(0.0f, -1.5f, 20.0f);
	glScalef(0.1f, 0.1f, 1.0f);
	RenderToDisplay();
	glPopMatrix();

    glutSwapBuffers(); //Send the 3D scene to the screen
}

static void idle(void)
{
    glutPostRedisplay();
}

const GLfloat light_ambient[]  = { 0.0f, 0.0f, 0.0f, 1.0f };
const GLfloat light_diffuse[]  = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_position[] = { 2.0f, 5.0f, 5.0f, 0.0f };

const GLfloat mat_ambient[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
const GLfloat mat_diffuse[]    = { 0.8f, 0.8f, 0.8f, 1.0f };
const GLfloat mat_specular[]   = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat high_shininess[] = { 100.0f };

/* Program entry point */

bool collution()
{
    if(egg1x>=baskx-0.3f && egg1x<=baskx+0.3f)
    {
        score++;
        return 1;
    }
    return 0;
}


void RenderToDisplay()
{
	int l, lenghOfQuote, i;

	glTranslatef(0.0, 10.0, -20.0);
	//glRotatef(-20, 1.0, 0.0, 0.0);
	glScalef(0.1, 0.1, 0.1);



	for (l = 0; l<numberOfQuotes; l++)
	{
		lenghOfQuote = (int)strlen(quote[l]);
		glPushMatrix();
		glTranslatef(-(lenghOfQuote * 40), -(l * 150), 0.0);
		for (i = 0; i < lenghOfQuote; i++)
		{
			glColor3f(1.0f, 0.0f, 0.0f);
			glutStrokeCharacter(GLUT_STROKE_ROMAN, quote[l][i]);


		}
		glPopMatrix();
	}

}

void myDisplayFunction(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glLoadIdentity();
	gluLookAt(0.0, 0.0, 80.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
	RenderToDisplay();
	glutSwapBuffers();
}


int gameOver()
{

	strcpy(quote[0], "Game Over ");

	strcpy(quote[1], "Your Score Is");
	//	strcpy_s(quote[2], );
	char a[5];
	itoa(score, a, 10);
	strcpy(quote[2], a);
	//strcpy(quote[3], &score);
	numberOfQuotes = 3;

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	//glutInitWindowSize(1360, 750);
	glutCreateWindow("Game Result");
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glLineWidth(5);

	glutDisplayFunc(myDisplayFunction);
	glutReshapeFunc(resize);
	glutIdleFunc(idle);
	glutMainLoop();

	return 0;
}

void update(int value)
{
    if(random()>990){chicd*=-1;}
    if(chicd==1)
    {
        if(chicx>-2.6f){chicx-=0.1f;}
        else{chicd=-1;chicx+=0.1f;}
    }
    else
    {
        if(chicx<2.6f){chicx+=0.1f;}
        else{chicd=1;chicx-=0.1f;}
    }

    if(egg1y>-2.0){egg1y-=0.07f;}
    else
    {
        if(egg1c==0)
        {
            life--;
            if(life==0){gameOver();}
        }
        egg1y=1.0f;
        egg1x=chicx;
        egg1c=0.0f;
    }
    if(egg1y<-1.9 && egg1c==0){egg1c=collution();}
    glutPostRedisplay();
    glutTimerFunc(25, update, 0);
}
int main(int argc, char *argv[])
{
    //Initialize GLUT
    glutInit(&argc, argv);
    glutInitWindowSize(1366, 768);
    glutInitWindowPosition(10,10);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

    glutCreateWindow("GLUT Shapes");
    initRendering();

    glutReshapeFunc(resize);
    glLineWidth(8);
    glutDisplayFunc(drawScene);
    glutSpecialFunc(handleKeypress);
    glutIdleFunc(idle);

    glutTimerFunc(25, update, 0);
    glutMainLoop();

    return 0;
}
