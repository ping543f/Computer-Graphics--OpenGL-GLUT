
#include <iostream>
#include <Windows.h>
#include <string>
#include <stdlib.h>
#include <mmsystem.h>
#include <GL/glut.h>
#include <thread>

#pragma comment(lib,"Winmm.lib")

#include "imageloader.h"

using namespace std;

///// Hasan, Md Zahid
///// Chumky, Suraiya Siddiqua
///// Arefeen, R. H. M. Reeshul
///// Hoque,Md Mazharul




GLuint _textureApple1;												//
GLuint _textureApple2;												//
GLuint _textureApple3;												// Texture Apple
GLuint _textureApple4;												//	
GLuint _textureApple5;												//
GLuint _textureApple6;												//

GLuint _texturePineApple1;											//
GLuint _texturePineApple2;											//
GLuint _texturePineApple3;											//
GLuint _texturePineApple4;											// Texture Pine Apple
GLuint _texturePineApple5;											//
GLuint _texturePineApple6;											//

GLuint _textureB_PineApple1;										// Texture Bonus Pine Apple
GLuint _textureB_PineApple2;										//

GLuint _textureApplePen;											// Texture Apple Pen
GLuint _textureApplePen2;											//

GLuint _texturePineapplePen;										//	
GLuint _texturePineapplePen2;										// Texture Pine Apple Pen
GLuint _textureB_PineapplePen;										//

static int mood = 1;												// Display Texture on display
static int f_mood = 1;

GLuint _texturePen;													// Texture Pen

float xx1 = -1.5; float yy1 = 0.5;									// X, Y axis for Object
float xx2 = -1.0; float yy2 = 1.0;									//

float p_x1 = -0.1; float p_y1 = -1.5;								// X, Y axis for Pen
float p_x2 = 0.1; float p_y2 = -1.0;								//

float f_x1; float f_y1;												// X, Y axis for falling Object
float f_x2; float f_y2;												//

static int ObjectFlag = 1;											// Control object visibility

static int penFlag = 1;												// Control pen location
static int _penFlag = 1;
static int resetGameFlag = 1;										// Reset game

static int lifeFlag = 3;											// Reset life

static int f_appleFlag = 0;

float _speed = 0.050f;												// Speed Control

int _score = 0;														// Score

int stopPen = 1;													// Stop Pen

int stopObject = 1;													// Stop Object

int stopfApple = 0;

// Set Location of Object
void SetLocation_Object(float x_1, float x_2, float y_1, float y_2)
{
	xx1 = x_1;
	xx2 = x_2;
	yy1 = y_1;
	yy2 = y_2;
}
// Set Location of Pen
void SetLocation_Pen(float x_1, float x_2, float y_1, float y_2)
{
	p_x1 = x_1;
	p_x2 = x_2;
	p_y1 = y_1;
	p_y2 = y_2;
}

//
// Get Location of Pen
//
float GetP_X1()
{
	return p_x1;
}
float GetP_X2()
{
	return p_x2;
}
float GetP_Y1()
{
	return p_y1;
}
float GetP_Y2()
{
	return p_y2;
}
//
// Get Location of Object
//
float GetX1()
{
	return xx1;
}
float GetX2()
{
	return xx2;
}
float GetY1()
{
	return yy1;
}
float GetY2()
{
	return yy2;
}
//
// Texture Falling Object
//
void TextureApplePen(float x1, float y1, float x2, float y2)
{
	f_x1 = x1;
	f_x2 = x2;
	f_y1 = y1;
	f_y2 = y2;
	glBindTexture(GL_TEXTURE_2D, _textureApplePen);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(f_x1, f_y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(f_x1, f_y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(f_x2, f_y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(f_x2, f_y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TexturePineApplePen(float x1, float y1, float x2, float y2)
{
	f_x1 = x1;
	f_x2 = x2;
	f_y1 = y1;
	f_y2 = y2;
	glBindTexture(GL_TEXTURE_2D, _texturePineapplePen);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(f_x1, f_y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(f_x1, f_y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(f_x2, f_y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(f_x2, f_y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TextureApplePen2(float x1, float y1, float x2, float y2)
{
	f_x1 = x1;
	f_x2 = x2;
	f_y1 = y1;
	f_y2 = y2;
	glBindTexture(GL_TEXTURE_2D, _textureApplePen2);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(f_x1, f_y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(f_x1, f_y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(f_x2, f_y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(f_x2, f_y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TexturePineApplePen2(float x1, float y1, float x2, float y2)
{
	f_x1 = x1;
	f_x2 = x2;
	f_y1 = y1;
	f_y2 = y2;
	glBindTexture(GL_TEXTURE_2D, _texturePineapplePen2);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(f_x1, f_y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(f_x1, f_y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(f_x2, f_y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(f_x2, f_y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TextureB_PineApplePen(float x1, float y1, float x2, float y2)
{
	f_x1 = x1;
	f_x2 = x2;
	f_y1 = y1;
	f_y2 = y2;
	glBindTexture(GL_TEXTURE_2D, _textureB_PineapplePen);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(f_x1, f_y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(f_x1, f_y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(f_x2, f_y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(f_x2, f_y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
//
// Texture Apple
//
void TextureApple1(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _textureApple1);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TextureApple2(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _textureApple2);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TextureApple3(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _textureApple3);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TextureApple4(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _textureApple4);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TextureApple5(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _textureApple5);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TextureApple6(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _textureApple6);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
//
// Texture Pineapple
//
void TexturePineApple1(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _texturePineApple1);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TexturePineApple2(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _texturePineApple2);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TexturePineApple3(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _texturePineApple3);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TexturePineApple4(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _texturePineApple4);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TexturePineApple5(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _texturePineApple5);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TexturePineApple6(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _texturePineApple6);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TextureB_PineApple1(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _textureB_PineApple1);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
void TextureB_PineApple2(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _textureB_PineApple2);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
//
// Texture Pen
//
void TexturePen(float x1, float y1, float x2, float y2)
{
	glBindTexture(GL_TEXTURE_2D, _texturePen);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 0.0f);
	glBegin(GL_QUADS);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(x1, y1, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(x1, y2, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(x2, y2, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(x2, y1, 0.0);

	glEnd();
	//glutSwapBuffers();
}
//
// Bitmap String Text
//
void BitmapString_Score(float x, float y, string s) {

	glPushAttrib(GL_CURRENT_BIT);
	glColor3f(0.0, 0.0, 0.0);
	
	glRasterPos2i(x, y);
	
	for (int i = 0; i < s.size(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, s[i]);
		
	}
	glPopAttrib();
}
void BitmapString_GameOver(float x, float y, string s) {

	glPushAttrib(GL_CURRENT_BIT);
	glColor3f(0.0, 0.0, 0.0);

	glRasterPos2i(x, y);

	for (int i = 0; i < s.size(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, s[i]);

	}
	glPopAttrib();
}
void BitmapString_Life(float x, float y, string s) {

	glPushAttrib(GL_CURRENT_BIT);
	glColor3f(0.0, 0.0, 0.0);

	glRasterPos2i(x, y);

	for (int i = 0; i < s.size(); i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, s[i]);

	}
	glPopAttrib();
}
void BitmapTapToStartText(float x, float y, string s) {

	glPushAttrib(GL_CURRENT_BIT);
	glColor3f(1.0, 0.0, 0.0);

	glRasterPos2i(x, y);

	for (int i = 0; i < s.size(); i++)
	{
		glColor3f(1.0, 1.0, 1.0);
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, s[i]);
	}
	glPopAttrib();
}

void Play_PineapplePen()
{
	PlaySound(L"E:/Google Drive/DarkZGothiC/Codes/C++/Pine Apple Pen Game Resources/m_pineapple-pen.wav", NULL, SND_FILENAME | SND_SYNC);

}
void Play_ApplePen()
{
	PlaySound(L"E:/Google Drive/DarkZGothiC/Codes/C++/Pine Apple Pen Game Resources/m_apple-pen.wav", NULL, SND_FILENAME | SND_SYNC);

}
void Play_Shoot()
{
	PlaySound(L"E:/Google Drive/DarkZGothiC/Codes/C++/Pine Apple Pen Game Resources/m_shoot.wav", NULL, SND_FILENAME | SND_SYNC);

}
//
// Draw Scene
//
void drawScene() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(1.0, 0.87, 0.07, 0.0);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(0.0, 0.0, -6.0f);
	glEnable(GL_TEXTURE_2D);
	glNormal3f(0.0f, 0.0f, 1.0f);

	string s = " Score: " + to_string(_score);
	BitmapString_Score(1.5, 2.0, s);

	if (mood == 1)
	{
		yy1 = 0.2;
		yy2 = 0.7;
		TextureApple1(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TextureApplePen(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 2)
	{
		yy1 = -0.2;
		yy2 = 0.3;
		TextureApple2(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TextureApplePen(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 3)
	{
		TextureApple3(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TextureApplePen(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 4)
	{
		yy1 = 0.2;
		yy2 = 0.7;
		TextureApple4(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TextureApplePen(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 5)
	{
		yy1 = -0.2;
		yy2 = 0.3;
		TexturePineApple1(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TexturePineApplePen(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 6)
	{
		TexturePineApple2(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TexturePineApplePen(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 7)
	{
		yy1 = 0.2;
		yy2 = 0.7;
		TexturePineApple3(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TexturePineApplePen(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 8)
	{
		yy1 = -0.2;
		yy2 = 0.3;
		TexturePineApple4(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TexturePineApplePen(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 9)
	{
		TextureApple5(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TextureApplePen2(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 10)
	{
		yy1 = 0.2;
		yy2 = 0.7;
		TextureApple6(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TextureApplePen2(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 11)
	{
		yy1 = -0.2;
		yy2 = 0.3;
		TexturePineApple5(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TexturePineApplePen2(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 12)
	{
		TexturePineApple6(xx1, yy1, xx2, yy2);
		if (stopfApple > 0)
		{
			TexturePineApplePen2(f_x1, f_y1, f_x2, f_y2);
		}
	}
	if (mood == 13)
	{
		yy1 = 0.2;
		yy2 = 0.7;
		TextureB_PineApple1(xx1, yy1, xx2, yy2);
		/*if (stopfApple > 0)
		{
			TextureB_PineApplePen(f_x1, f_y1, f_x2, f_y2);
		}*/
	}
	if (mood == 14)
	{
		yy1 = -0.2;
		yy2 = 0.3;
		TextureB_PineApple2(xx1, yy1, xx2, yy2);
		if (stopfApple > 0)
		{
			TextureB_PineApplePen(f_x1, f_y1, f_x2, f_y2);
		}
	}

	if (f_mood == 1 || f_mood == 2 || f_mood == 3 || f_mood == 4)
	{
		if (stopfApple > 0)
		{
			TextureApplePen(f_x1, f_y1, f_x2, f_y2);
		}
	}
	if (f_mood == 5 || f_mood == 6 || f_mood == 7 || f_mood == 8)
	{
		if (stopfApple > 0)
		{
			TexturePineApplePen(f_x1, f_y1, f_x2, f_y2);
		}
	}
	if (f_mood == 9 || f_mood == 10)
	{
		if (stopfApple > 0)
		{
			TextureApplePen2(f_x1, f_y1, f_x2, f_y2);
		}
	}
	if (f_mood == 11 || f_mood == 12)
	{
		if (stopfApple > 0)
		{
			TexturePineApplePen2(f_x1, f_y1, f_x2, f_y2);
		}
	}
	if (f_mood == 13 || f_mood == 14)
	{
		if (stopfApple > 0)
		{
			TextureB_PineApplePen(f_x1, f_y1, f_x2, f_y2);
		}
	}

	if (resetGameFlag == 0)
	{
		BitmapString_GameOver(-1.05, -0.3, "       Game Over");
	}
	if (resetGameFlag == 1)
	{
		BitmapString_GameOver(-4.0, 4.0, "");
	}
	
	TexturePen(p_x1, p_y1, p_x2, p_y2);

	string life = "Life Left: " + to_string(lifeFlag);
	BitmapString_Life(-2.0, 2.0, life);

	if (lifeFlag == 0)
	{
		string newGame = "Press 'n' to play again";
		BitmapString_Life(-1.5, -2.5, newGame);
	}
	else
	{
		BitmapString_Life(-4.0, 4.0, "");
	}
	
	glutSwapBuffers();
}
//
// Update Object in 25 milliseconds
//
void updateObject(int value) {
	if (ObjectFlag)
	{
		xx1 += _speed;
		xx2 += _speed;

		if (xx1>1.5)
		{
			ObjectFlag = 0;
		}
	}
	if (!ObjectFlag)
	{
		xx1 -= _speed;
		xx2 -= _speed;
		if (xx1<-2.0)
		{
			ObjectFlag = 1;
		}
	}
	glutPostRedisplay(); //Tell GLUT that the display has changed
	if (stopObject > 0)
	{
		glutTimerFunc(25, updateObject, 0); //Tell GLUT to call update again in 25 milliseconds
	}
}
//
// Update Falling Object in 25 milliseconds
//
void FallingOfObject(int value)
{
	
	if (f_appleFlag)
	{
		f_y1 = f_y1 - 0.080f;
		f_y2 = f_y2 - 0.080f;

		if (f_y2 <= -2.5)
		{
			f_appleFlag = 0;
			stopfApple = 0;
		}
		glutPostRedisplay();
		if (f_appleFlag > 0)
		{
			glutTimerFunc(25, FallingOfObject, 0);
		}
	}
}
//
// Update Pen
//
void updatePen(int value) {
	
	if (penFlag==1)
	{
		p_y1 = p_y1 + 0.080f;
		p_y2 = p_y2 + 0.080f;
	
		float f2 = GetX2() - GetP_X1();
		float f3 = GetX1() - GetP_X2();
		float _f1; float _f2;
		if (mood == 1 || mood == 4 || mood == 7 || mood == 10 || mood == 13)
		{
			_f1 = 0.3;
			_f2 = 0.5;
			_speed = 0.050f;
		}
		if (mood == 2 || mood == 5 || mood == 8 || mood == 11 || mood == 14)
		{
			_f1 = -0.1;
			_f2 = 0.1;
			_speed = 0.030f;
		}
		if (mood == 3 || mood == 6 || mood == 9 || mood == 12)
		{
			_f1 = 0.6;
			_f2 =  0.8;
			_speed = 0.070f;
		}

		if (p_y2 > _f1 && p_y2 < _f2 )
		{
			if (f2 >= 0 && f2 <= 0.7 || f3 <= 0 && f3 >= -0.7)
			{
				f_mood = mood;
				_score++;
				SetLocation_Pen(-0.1, 0.1, -1.5, -1.0);
				penFlag = 0;
				stopPen = 0;
				stopfApple = 1;
				f_appleFlag = 1;
				f_x1 = GetX1(); f_y1 = GetY1();
				f_x2 = GetX2(); f_y2 = GetY2();
				FallingOfObject(0);
				
				
				srand((unsigned)time(0));
				int i;
				i = (rand() % 14) + 1;

				mood = i;

				if (mood == 1 || mood == 4 || mood == 7 || mood == 10 || mood == 13)
				{
					_speed = 0.050f;
				}
				if (mood == 2 || mood == 5 || mood == 8 || mood == 11 || mood == 14)
				{
					_speed = 0.030f;
				}
				if (mood == 3 || mood == 6 || mood ==9 || mood == 12)
				{
					_speed = 0.100f;
				}
			}
		}
		else
		{
			if (p_y2>2.5)
			{
				SetLocation_Pen(-0.1, 0.1, -1.5, -1.0);
				
				penFlag = 0;
				stopPen = 0;
				mood = 8;
				--lifeFlag;
				if (lifeFlag <= 0)
				{
					lifeFlag = 0;
					stopObject = 0;
					resetGameFlag = 0;
				}
			}
		}
	}
	glutPostRedisplay();
	
	if (stopPen > 0)
	{
		glutTimerFunc(25, updatePen, 0);
	}
}
void keyboard(unsigned char key, int x, int y)
{
	if (key == ' ' )
	{
		penFlag = 1;
		stopPen = 1;
		updatePen(0);
	}
	if (key == 'n')
	{
		stopObject = 1;
		_score = 0;
		resetGameFlag = 1;
		lifeFlag = 3;
		_penFlag = 1;
		glutTimerFunc(25, updateObject, 0); 
	}
}

GLuint loadTexture(Image* image) {
	GLuint textureId;
	glGenTextures(1, &textureId); //Make room for our texture
	glBindTexture(GL_TEXTURE_2D, textureId); //Tell OpenGL which texture to edit
											 //Map the image to the texture
	glTexImage2D(GL_TEXTURE_2D,                //Always GL_TEXTURE_2D
		0,                            //0 for now
		GL_RGB,                       //Format OpenGL uses for image
		image->width, image->height,  //Width and height
		0,                            //The border of the image
		GL_RGB, //GL_RGB, because pixels are stored in RGB format
		GL_UNSIGNED_BYTE, //GL_UNSIGNED_BYTE, because pixels are stored
						  //as unsigned numbers
		image->pixels);               //The actual pixel data
	return textureId; //Returns the id of the texture
}

void initialize() {

	//glClearColor(1.0, 1.0, 1.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	gluPerspective(45.0, 1.00, 1.0, 200.0);

	//    Apple Images
	Image* apple1 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/apple.bmp");
	Image* apple2 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/apple2.bmp");
	Image* apple3 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/apple3.bmp");
	Image* apple4 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/apple4.bmp");
	Image* apple5 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/apple5.bmp");
	Image* apple6 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/apple6.bmp");

	//    Pine Apple Images
	Image* pineapple1 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/pineapple1.bmp");
	Image* pineapple2 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/pineapple2.bmp");
	Image* pineapple3 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/pineapple3.bmp");
	Image* pineapple4 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/pineapple4.bmp");
	Image* pineapple5 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/pineapple5.bmp");
	Image* pineapple6 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/pineapple6.bmp");

	//    Bonus Pine Apple Images
	Image* b_pineapple1 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/b_pineapple.bmp");
	Image* b_pineapple2 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/b_pineapple2.bmp");

	//    Pen Images
	Image* image1 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/pen.bmp");

	//    Collision Images
	Image* applePen = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/apple-pen.bmp");
	Image* applePen2 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/apple-pen2.bmp");
	Image* pineapplePen = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/pineapple-pen.bmp");
	Image* pineapplePen2 = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/pineapple-pen2.bmp");
	Image* b_pineapplePen = loadBMP("C:/Users/DarkzGothic/Desktop/ConsoleApplication1/Resources/b_pineapple-pen.bmp");

	_textureApple1 = loadTexture(apple1);
	_textureApple2 = loadTexture(apple2);
	_textureApple3 = loadTexture(apple3);
	_textureApple4 = loadTexture(apple4);
	_textureApple5 = loadTexture(apple5);
	_textureApple6 = loadTexture(apple6);

	_texturePineApple1 = loadTexture(pineapple1);
	_texturePineApple2 = loadTexture(pineapple2);
	_texturePineApple3 = loadTexture(pineapple3);
	_texturePineApple4 = loadTexture(pineapple4);
	_texturePineApple5 = loadTexture(pineapple5);
	_texturePineApple6 = loadTexture(pineapple6);

	_textureB_PineApple1 = loadTexture(b_pineapple1);
	_textureB_PineApple2 = loadTexture(b_pineapple2);

	_texturePen = loadTexture(image1);

	_textureApplePen = loadTexture(applePen);
	_textureApplePen2 = loadTexture(applePen2);
	_texturePineapplePen = loadTexture(pineapplePen);
	_texturePineapplePen2 = loadTexture(pineapplePen2);
	_textureB_PineapplePen = loadTexture(b_pineapplePen);

}


void lightSetting()
{

	GLfloat ambientIntensity[4] = { 0.6, 0.6, 0.6, 1.0 };

	GLfloat position[4] = { 0.0, 1.0, 0.0, 0.0 };

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_COLOR_MATERIAL);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);


	glLightfv(GL_LIGHT0, GL_AMBIENT, ambientIntensity);

	glLightfv(GL_LIGHT0, GL_POSITION, position);
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500, 700);

	glutCreateWindow("Pine Apple Game");
	initialize();
	
	glutDisplayFunc(drawScene);
	glutKeyboardFunc(keyboard);
	glutTimerFunc(25, updateObject, 0);
	glutMainLoop();
	return 0;
}







