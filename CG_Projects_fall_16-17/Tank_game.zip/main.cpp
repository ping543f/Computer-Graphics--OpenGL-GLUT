#include<windows.h>
#include<gl/glut.h>
#include<stdio.h>
#include<iostream>
#include<time.h>
#include <ctime>
#include<stdlib.h>
#include <string>
using namespace std;

bool turn1=true;
bool turn2=false;
bool rungame=true;
static GLfloat spin = 0.0;
static GLfloat spin_speed = 3.0;
string winner="";
float spin_x = 0;
float spin_y = 0;
float spin_z = 1;
int m;
int p1s=0;
float translate_tank1_x = 0.0;
static int bokkor=0;
float translate_tank1w_x = 0.0;
float translate_tank1w_y = 0.0;
float translate_tank1w_xm = 0.0;
float translate_tank1w_ym = 0.0;
float translate_tank1_y = 0.0;
///
float translate_tank2w_x = 0.0;
float translate_tank2w_y = 0.0;
float translate_tank2w_xm = 0.0;
float translate_tank2w_ym = 0.0;
float translate_tank2_y = 0.0;
//
float translate_tank1s_x = 0.0;
float translate_tank1s_y = 0.0;
float translate_tank2_x = 0.0;
int p2s=0;
int wx=134;
int wy=92;
int wz=68;
int c1=244;
int c2=0;
int c3=0;
int t2m=0;
int t1m=0;
int y1=-25;
int y2=-21;
int x1=-43;
int x2=-36;
int y11=-25;
int y22=-21;
int x11=23;
int x22=16;
int smov1=0;
int smov2=0;
int w1x=-36;
int w1y=-21;
int w1xf=-36;
int w1yf=-21;
int w2x=16;
int w2y=-21;
int w2xf=16;
int w2yf=-21;
int tlp1=5;
int tlp2=5;
string text="player 1 turn";
float translate_z = -40.0;
int power1=62;
int power2=70;
int wwx1=-5;
int wwx2=0;
int wwx3=0;
int wwx4=-5;
int wwy1=-30;
int wwy2=-30;
int wwy3=-15;
int wwy4=-15;
bool movetank1 = false;
bool movetank2 = false;
bool Mweapon1=false;
bool Mweapon2=false;
bool p1hit=false;
bool p2hit=false;// assuming work-window width=50unit, height=25unit;
void init()
{
	glClearColor(1, 0, 0, 0);
	glLineWidth(5.0);
	glPointSize(5.0);
	glShadeModel(GL_SMOOTH); // Enable Smooth Shading
	glClearDepth(1.0f); // Depth Buffer Setup
	glEnable(GL_DEPTH_TEST); // Enables Depth Testing

}
void drawText(const char *text,int length , int x,int y)
{
	glMatrixMode(GL_PROJECTION);
	double *matrix = new double[16];
	glGetDoublev(GL_PROJECTION_MATRIX, matrix);
	glLoadIdentity();
	glOrtho(-50,50,-50,50,-5,5);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glPushMatrix();
	glLoadIdentity();
	glRasterPos2d(x,y);

	for (int i = 0; i < length; i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24,(int)text[i]);
		//GLUT_BITMAP_9_BY_15

	}
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glLoadMatrixd(matrix);
	glMatrixMode(GL_MODELVIEW);

}
//------- custom functions starts -------
void setSpin(float x, float y, float z)
{
	spin_x = x;
	spin_y = y;
	spin_z = z;
}
void reset()
{
	spin_x = 0;
	spin_y = 0;
	spin_z = 1;
	translate_tank1_x = 0.0;
	translate_tank1_y = 0.0;
	translate_tank2_x = 0.0;
	translate_tank2_y = 0.0;
	translate_z = -40.0;
}
//------- custom functions ends -------
void reshape(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(100.0f, (GLfloat)w / (GLfloat)h, 1.0f, 100.0f);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
void tank1attack()
{
    if((w1xf+translate_tank1w_x)<=27+translate_tank2_x&&(w1xf+translate_tank1w_x)>=23+translate_tank2_x)
    {
       if(w1yf+translate_tank1w_y<=-18&&w1yf+translate_tank1w_y>=-26)
       {

p1hit=true;


       }
    }
    else if((w1xf+translate_tank1w_x)<=30+translate_tank2_x&&(w1xf+translate_tank1w_x)>=20+translate_tank2_x)
    {
       if(w1yf+translate_tank1w_y<=-25&&w1yf+translate_tank1w_y>=-30)
       {

 p1hit=true;


       }
    }
}
void tank2attack()
{
    if((w2xf+translate_tank2w_x)<=-43+translate_tank1_x&&(w2xf+translate_tank2w_x)>=-47+translate_tank1_x)
    {
       if(w2yf+translate_tank2w_y<=-19&&w2yf+translate_tank2w_y>=-26)
       {

p2hit=true;


       }
    }
    else if((w2xf+translate_tank2w_x)<=-40+translate_tank1_x&&(w2xf+translate_tank2w_x)>=-50+translate_tank1_x)
    {
       if(w2yf+translate_tank2w_y<=-25&&w2yf+translate_tank2w_y>=-30)
       {

p2hit=true;


       }
    }
}


void Road() {
	glBegin(GL_QUADS);

	glColor3ub(14, 75, 32);
		glVertex2i(-70, -50);
	glVertex2i(70, -50);
	glVertex2i(70, -30);
	glVertex2i(-70, -30);


	glEnd();



	glFlush();
}
void tank1stick()
{
   glBegin(GL_LINES);

	glColor3ub(28, 9, 14);
		glVertex2i(x1, y1);
	glVertex2i(x2, y2);


	glEnd();
	glFlush();
}
void tank2stick()
{
   glBegin(GL_LINES);

	glColor3ub(28, 9, 14);
		glVertex2i(x11, y11);
	glVertex2i(x22, y22);


	glEnd();
	glFlush();
}
void tank1() {
	glBegin(GL_QUADS);

	glColor3ub(79, 221, 121);
		glVertex2i(-50, -30);
	glVertex2i(-40, -30);
	glVertex2i(-40, -25);
	glVertex2i(-50, -25);


	glEnd();
	glBegin(GL_QUADS);

	glColor3ub(99, 29, 50);
		glVertex2i(-47, -25);
	glVertex2i(-43, -25);
	glVertex2i(-43, -23);
	glVertex2i(-47, -23);


	glEnd();
	glFlush();


}
void sun()
{
glBegin(GL_QUADS);

	glColor3ub(236, 241, 41);
		glVertex2i(50, 30);
	glVertex2i(60, 30);
	glVertex2i(60, 40);
	glVertex2i(50, 40);


	glEnd();





	glFlush();
}
void sn()
{

glBegin(GL_QUADS);

	glColor3ub(230, 224, 15);
		glVertex2i(51, 38);
	glVertex2i(52, 38);
	glVertex2i(52, 39);
	glVertex2i(51, 39);


	glEnd();
	glFlush();
}
void wall();
void wallcolission1()
{   cout<<w1xf<<"  "<<w1yf<<"    "<<translate_tank1w_x<<"   "<<translate_tank1w_y<<endl;
    if((w1xf+translate_tank1w_x)<0&&(w1xf+translate_tank1w_x)>-5)
    {
       if(w1yf+translate_tank1w_y<-15)
       {




       }
    }
}
void Moveweapon1(void){
  //while(Mweapon1)
   {
       tank1attack();
        if(smov1==0)
    {

	if ((translate_tank1w_xm+translate_tank1w_ym) < (power1*2)/5){
		translate_tank1w_x+=1;

		translate_tank1w_xm+=1;
		tank1attack();
		translate_tank1w_x+=1;

		translate_tank1w_xm+=1;
		tank1attack();
		translate_tank1w_y+=1;
		translate_tank1w_ym+=1;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank1w_xm+translate_tank1w_ym) < (power1*3)/5){
		translate_tank1w_x+=1;
		translate_tank1w_xm+=1;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank1w_xm+translate_tank1w_ym) < power1||m>-30){
		translate_tank1w_x+=2;
		translate_tank1w_y-=1;
		translate_tank1w_xm+=2;
		translate_tank1w_ym+=1;
		c1=218;
		c2=202;
		c3=12;
        if((translate_tank1w_xm+translate_tank1w_ym) >= power1)

           {
                m--;
                cout<<m;
           }
	}
	else
	{


        c1=244;
		c2=0;
		c3=0;
		translate_tank1w_x = 0;
		translate_tank1w_y = 0;
		translate_tank1w_xm = 0;
		translate_tank1w_ym = 0;
		Mweapon1=false;
		w1x=x2+t2m+t1m;
        m=w1yf;
        if(p1hit)
          p1s+=20;

		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov1==1)
    {

	if ((translate_tank1w_xm+translate_tank1w_ym) < (power1*2)/5){
		translate_tank1w_x+=3;
		translate_tank1w_y+=1;
        translate_tank1w_xm+=3;
		translate_tank1w_ym+=1;
        //tank1attack();
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank1w_xm+translate_tank1w_ym)< (power1*3)/5){
		translate_tank1w_x+=1;
        translate_tank1w_xm+=1;
		c1=218;
		c2=202;
		c3=12;
		//tank1attack();


	}

	else if ((translate_tank1w_xm+translate_tank1w_ym) < power1||m>-30){
		translate_tank1w_x+=3;
		translate_tank1w_y-=1;
		translate_tank1w_x+=3;
		translate_tank1w_ym+=1;
		//tank1attack();
		c1=218;
		c2=202;
		c3=12;
		 if((translate_tank1w_xm+translate_tank1w_ym) >= power1)

           {
                m--;
                cout<<m;
           }


	}
	else
	{
        c1=244;
		c2=0;
		c3=0;
		translate_tank1w_x = 0;
		translate_tank1w_y = 0;
			translate_tank1w_xm = 0;
		translate_tank1w_ym = 0;
		Mweapon1=false;
		w1x=x2+t2m+t1m;
		 m=w1yf;
        if(p1hit)
          p1s+=20;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov1==2)
    {

	if ((translate_tank1w_xm+translate_tank1w_ym) < (power1*2)/5){
		translate_tank1w_x+=4;
		translate_tank1w_y+=1;
		translate_tank1w_xm+=4;
		translate_tank1w_ym+=1;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank1w_xm+translate_tank1w_ym) < (power1*11)/20){
		translate_tank1w_x+=5;
		translate_tank1w_xm+=1;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank1w_xm+translate_tank1w_ym) < power1||m>-30){
		translate_tank1w_x+=4;
		translate_tank1w_y-=1;
		translate_tank1w_xm+=4;
		translate_tank1w_ym+=1;
		c1=218;
		c2=202;
		c3=12;
		 if((translate_tank1w_xm+translate_tank1w_ym) >= power1)

           {
                m--;
                cout<<m;
           }


	}
	else
	{
        c1=244;
		c2=0;
		c3=0;
		translate_tank1w_x = 0;
		translate_tank1w_y = 0;
			translate_tank1w_xm = 0;
		translate_tank1w_ym = 0;
		Mweapon1=false;
		w1x=x2+t2m+t1m;
		 m=w1yf;
if(p1hit)
          p1s+=20;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov1==3)
    {

	if ((translate_tank1w_xm+translate_tank1w_ym) < (power1*2)/5){
		translate_tank1w_x+=5;
		translate_tank1w_y+=1;
		translate_tank1w_xm+=5;
		translate_tank1w_ym+=1;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank1w_xm+translate_tank1w_ym)< (power1*3)/5){
		translate_tank1w_x+=1;
		translate_tank1w_xm+=1;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank1w_xm+translate_tank1w_ym) < power1||m>-30){
		translate_tank1w_x+=5;
		translate_tank1w_y-=1;
		translate_tank1w_xm+=5;
		translate_tank1w_ym+=1;
		c1=218;
		c2=202;
		c3=12;
		 if((translate_tank1w_xm+translate_tank1w_ym) >= power1)

           {
                m--;
                cout<<m;
           }


	}
	else
	{
        c1=244;
		c2=0;
		c3=0;
		translate_tank1w_x = 0;
		translate_tank1w_y = 0;
			translate_tank1w_xm = 0;
		translate_tank1w_ym = 0;
		Mweapon1=false;
		w1x=x2+t2m+t1m;
		 m=w1yf;
if(p1hit)
          p1s+=20;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov1==4)
    {

	if ((translate_tank1w_xm+translate_tank1w_ym)< (power1*2)/5){
		translate_tank1w_x+=1;
		//translate_tank1w_y+=1;
		translate_tank1w_xm+=1;
		//translate_tank1w_ym+=1;
		c1=218;
		c2=202;
		c3=12;

        wallcolission1();


	}
	else if((translate_tank1w_xm+translate_tank1w_ym) < (power1*3)/5){
		translate_tank1w_x+=2;
		translate_tank1w_xm+=2;

		c1=218;
		c2=202;
		c3=12;
		 wallcolission1();


	}

	else if ((translate_tank1w_xm+translate_tank1w_ym) < power1||m>-30){
		translate_tank1w_x+=4;
		translate_tank1w_y-=1;
		translate_tank1w_xm+=4;
		translate_tank1w_ym+=1;
		c1=218;
		c2=202;
		c3=12;
		 wallcolission1();
 if((translate_tank1w_xm+translate_tank1w_ym) >= power1)

           {
                m--;
                cout<<m;
           }

	}
	else
	{
        c1=244;
		c2=0;
		c3=0;
		translate_tank1w_x = 0;
		translate_tank1w_y = 0;
			translate_tank1w_xm = 0;
		translate_tank1w_ym = 0;
		Mweapon1=false;
		w1x=x2+t2m+t1m;
		 m=w1yf;
if(p1hit)
          p1s+=20;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov1==-1)
    {

	if ((translate_tank1w_xm+translate_tank1w_ym) < (power1*2)/5){
		translate_tank1w_x+=1;
		translate_tank1w_y+=1;
		translate_tank1w_xm+=1;
		translate_tank1w_ym+=1;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank1w_xm+translate_tank1w_ym) < (power1*3)/5){
		translate_tank1w_x+=2;
		translate_tank1w_xm+=1;
		translate_tank1w_y+=2;
		translate_tank1w_ym+=1;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank1w_xm+translate_tank1w_ym) < power1||m>-30){
		translate_tank1w_x+=1;
		translate_tank1w_y-=1;
		translate_tank1w_xm+=1;
		translate_tank1w_ym+=1;
		c1=218;
		c2=202;
		c3=12;
 if((translate_tank1w_xm+translate_tank1w_ym) >= power1)

           {
                m--;
                cout<<m;
           }

	}
	else
	{
        c1=244;
		c2=0;
		c3=0;
		translate_tank1w_x = 0;
		translate_tank1w_y = 0;
			translate_tank1w_xm = 0;
		translate_tank1w_ym = 0;
		Mweapon1=false;
		w1x=x2+t2m+t1m;
		 m=w1yf;
if(p1hit)
          p1s+=20;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov1==-2)
    {

	if ((translate_tank1w_xm+translate_tank1w_ym) < (power1*2)/5){
		translate_tank1w_x+=2;
		translate_tank1w_y+=3;
		translate_tank1w_xm+=2;
		translate_tank1w_ym+=3;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank1w_xm+translate_tank1w_ym)< (power1*1)/2){
		translate_tank1w_x+=1;
		translate_tank1w_xm+=1;
		translate_tank1w_y+=1;
		translate_tank1w_ym+=1;

		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank1w_xm+translate_tank1w_ym)< (power1*3)/5){
		translate_tank1w_x+=2;
		translate_tank1w_xm+=2;


		c1=218;
		c2=202;
		c3=12;


	}


	else if ((translate_tank1w_xm+translate_tank1w_ym) < power1||m>-30){
		translate_tank1w_x+=2;
		translate_tank1w_y-=3;
		translate_tank1w_xm+=2;
		translate_tank1w_ym+=3;
		c1=218;
		c2=202;
		c3=12;
 if((translate_tank1w_xm+translate_tank1w_ym) >= power1)

           {
                m--;
                cout<<m;
           }

	}
	else
	{
        c1=244;
		c2=0;
		c3=0;
		translate_tank1w_x = 0;
		translate_tank1w_y = 0;
			translate_tank1w_xm = 0;
		translate_tank1w_ym = 0;
		Mweapon1=false;
		w1x=x2+t2m+t1m;
		 m=w1yf;
if(p1hit)
          p1s+=20;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov1==-3)
    {

	if ((translate_tank1w_xm+translate_tank1w_ym) < (power1*2)/5){
		translate_tank1w_x+=2;
		translate_tank1w_y+=5;
		translate_tank1w_xm+=2;
		translate_tank1w_ym+=5;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank1w_xm+translate_tank1w_ym)< (power1*3)/5){
		translate_tank1w_x+=2;
		translate_tank1w_xm+=2;
		translate_tank1w_y+=1;
		translate_tank1w_ym+=1;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank1w_xm+translate_tank1w_ym) < power1||m>-30){
		translate_tank1w_x+=2;
		translate_tank1w_y-=5;
		translate_tank1w_xm+=2;
		translate_tank1w_ym+=5;
		c1=218;
		c2=202;
		c3=12;
 if((translate_tank1w_xm+translate_tank1w_ym) >= power1)

           {
                m--;
                cout<<m;
           }

	}
	else
	{
        c1=244;
		c2=0;
		c3=0;
		translate_tank1w_x = 0;
		translate_tank1w_y = 0;
			translate_tank1w_xm = 0;
		translate_tank1w_ym = 0;
		Mweapon1=false;
		w1x=x2+t2m+t1m;
		 m=w1yf;
if(p1hit)
          p1s+=20;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov1==-4)
    {

	if ((translate_tank1w_xm+translate_tank1w_ym)< (power1*2)/5){
		translate_tank1w_x+=1;
		translate_tank1w_y+=5;
		translate_tank1w_xm+=1;
		translate_tank1w_ym+=5;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank1w_xm+translate_tank1w_ym) < (power1*3)/5){
		translate_tank1w_x+=1;
		translate_tank1w_xm+=1;
		translate_tank1w_y+=2;
		translate_tank1w_ym+=2;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank1w_xm+translate_tank1w_ym) < power1||m>-30){
		translate_tank1w_x+=1;
		translate_tank1w_y-=5;
			translate_tank1w_xm+=1;
		translate_tank1w_ym+=5;
		c1=218;
		c2=202;
		c3=12;
 if((translate_tank1w_xm+translate_tank1w_ym) >= power1)

           {
                m--;
                cout<<m;
           }

	}
	else
	{
        c1=244;
		c2=0;
		c3=0;
		translate_tank1w_x = 0;
		translate_tank1w_y = 0;
			translate_tank1w_xm = 0;
		translate_tank1w_ym = 0;
		Mweapon1=false;
		w1x=x2+t2m+t1m;
		 m=w1yf;

	if(p1hit)
          p1s+=20;	//t2m=0;
		//t1m=0;
	}
    }
    /////



		glutPostRedisplay();

   }
}

void wall()
{
    glBegin(GL_QUADS);

	glColor3ub(wx, wy, wz);
		glVertex2i(wwx1, wwy1);
	glVertex2i(wwx2, wwy2);
	glVertex2i(wwx3, wwy3);
	glVertex2i(wwx4, wwy4);


	glEnd();





	glFlush();

}
/////////////////weapon2
void Moveweapon2(void){
    tank2attack();
    if(smov2==0)
    {

	if ((translate_tank2w_xm+translate_tank2w_ym) < (power2*2)/5){
		translate_tank2w_x-=2;
		translate_tank2w_y+=1;
		translate_tank2w_xm+=2;
		translate_tank2w_ym+=1;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank2w_xm+translate_tank2w_ym) < (power2*3)/5){
		translate_tank2w_x-=1;
		translate_tank2w_xm+=1;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank2w_xm+translate_tank2w_ym) < power2||m>-30){
		translate_tank2w_x-=2;
		translate_tank2w_y-=1;
		translate_tank2w_xm+=2;
		translate_tank2w_ym+=1;
		c1=218;
		c2=202;
		c3=12;
        if((translate_tank2w_xm+translate_tank2w_ym) >= power2)

           {
                m--;
                cout<<m;
           }
	}
	else
	{


        c1=244;
		c2=0;
		c3=0;
		translate_tank2w_x = 0;
		translate_tank2w_y = 0;
		translate_tank2w_xm = 0;
		translate_tank2w_ym = 0;
		Mweapon2=false;
		w1x=x2+t2m+t1m;
        m=w1yf;
         if(p1s>p2s)
         winner="Winner player 1";
            else
            winner="Winner player 2";
		if(p2hit)
          p2s+=20;//t2m=0;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov2==1)
    {

	if ((translate_tank2w_xm+translate_tank2w_ym) < (power2*2)/5){
		translate_tank2w_x-=3;
		translate_tank2w_y+=1;
        translate_tank2w_xm+=3;
		translate_tank2w_ym+=1;

		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank2w_xm+translate_tank2w_ym)< (power2*3)/5){
		translate_tank2w_x-=1;
        translate_tank2w_xm+=1;
		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank2w_xm+translate_tank2w_ym) < power2||m>-30){

		translate_tank2w_x-=3;
		translate_tank2w_y-=1;
		translate_tank2w_xm+=3;
		translate_tank2w_ym+=1;
		c1=218;
		c2=202;
		c3=12;
		 if((translate_tank2w_xm+translate_tank2w_ym) >= power2)

           {
                m--;
                cout<<m;
           }


	}
	else
	{
       c1=244;
		c2=0;
		c3=0;
		translate_tank2w_x = 0;
		translate_tank2w_y = 0;
		translate_tank2w_xm = 0;
		translate_tank2w_ym = 0;
		Mweapon2=false;
		w1x=x2+t2m+t1m;
        m=w1yf;
        if(p1s>p2s)
         winner="Winner player 1";
            else
            winner="Winner player 2";
		//t2m=0;
		if(p2hit)
          p2s+=20;

		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov2==2)
    {

	if ((translate_tank2w_xm+translate_tank2w_ym) < (power2*2)/5){
		translate_tank2w_x-=4;
		translate_tank2w_y+=1;
		translate_tank2w_xm+=4;
		translate_tank2w_ym+=1;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank2w_xm+translate_tank2w_ym) < (power2*11)/20){
		translate_tank2w_x-=5;
		translate_tank2w_xm+=1;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank2w_xm+translate_tank2w_ym) < power2||m>-30){
		translate_tank2w_x-=4;
		translate_tank2w_y-=1;
		translate_tank2w_xm+=4;
		translate_tank2w_ym+=1;
		c1=218;
		c2=202;
		c3=12;
		 if((translate_tank2w_xm+translate_tank2w_ym) >= power2)

           {
                m--;
                cout<<m;
           }


	}
	else
	{
         c1=244;
		c2=0;
		c3=0;
		translate_tank2w_x = 0;
		translate_tank2w_y = 0;
		translate_tank2w_xm = 0;
		translate_tank2w_ym = 0;
		Mweapon2=false;
		w1x=x2+t2m+t1m;
        m=w1yf;
        if(p1s>p2s)
         winner="Winner player 1";
            else
            winner="Winner player 2";
            if(p2hit)
          p2s+=20;
		//t2m=0;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov2==3)
    {

	if ((translate_tank2w_xm+translate_tank2w_ym) < (power2*2)/5){
		translate_tank2w_x-=5;
		translate_tank2w_y+=1;
		translate_tank2w_xm+=5;
		translate_tank2w_ym+=1;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank2w_xm+translate_tank2w_ym)< (power2*3)/5){
		translate_tank2w_x-=1;
		translate_tank2w_xm+=1;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank2w_xm+translate_tank2w_ym) < power2||m>-30){
		translate_tank2w_x-=5;
		translate_tank2w_y-=1;
		translate_tank2w_xm+=5;
		translate_tank2w_ym+=1;
		c1=218;
		c2=202;
		c3=12;
		 if((translate_tank2w_xm+translate_tank2w_ym) >= power2)

           {
                m--;
                cout<<m;
           }


	}
	else
	{
         c1=244;
		c2=0;
		c3=0;
		translate_tank2w_x = 0;
		translate_tank2w_y = 0;
		translate_tank2w_xm = 0;
		translate_tank2w_ym = 0;
		Mweapon2=false;
		w1x=x2+t2m+t1m;
        m=w1yf;
        if(p1s>p2s)
         winner="Winner player 1";
            else
            winner="Winner player 2";
            if(p2hit)
          p2s+=20;
		//t2m=0;

		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov2==4)
    {

	if ((translate_tank2w_xm+translate_tank2w_ym)< (power2*2)/5){
		translate_tank2w_x+=4;
		//translate_tank1w_y+=1;
		translate_tank2w_xm+=4;
		//translate_tank1w_ym+=1;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank2w_xm+translate_tank2w_ym) < (power2*3)/5){
		translate_tank2w_x-=2;
		translate_tank2w_xm+=2;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank2w_xm+translate_tank2w_ym) < power2||m>-30){
		translate_tank2w_x-=4;
		//translate_tank1w_y-=1;
		translate_tank2w_x+=4;
		//translate_tank1w_y+=1;
		c1=218;
		c2=202;
		c3=12;
 if((translate_tank2w_xm+translate_tank2w_ym) >= power2)

           {
                m--;
                cout<<m;
           }

	}
	else
	{ c1=244;
		c2=0;
		c3=0;
		translate_tank2w_x = 0;
		translate_tank2w_y = 0;
		translate_tank2w_xm = 0;
		translate_tank2w_ym = 0;
		Mweapon2=false;
		w1x=x2+t2m+t1m;
        m=w1yf;
        if(p1s>p2s)
         winner="Winner player 1";
            else
            winner="Winner player 2";
            if(p2hit)
          p2s+=20;
		//t2m=0;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov2==-1)
    {

	if ((translate_tank2w_xm+translate_tank2w_ym) < (power2*2)/5){
		translate_tank2w_x-=1;
		translate_tank2w_y+=1;
		translate_tank2w_xm+=1;
		translate_tank2w_ym+=1;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank2w_xm+translate_tank2w_ym) < (power2*3)/5){
		translate_tank2w_x-=2;
		translate_tank2w_xm+=1;
		translate_tank2w_y+=2;
		translate_tank2w_ym+=1;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank2w_xm+translate_tank2w_ym) < power2||m>-30){
		translate_tank2w_x-=1;
		translate_tank2w_y-=1;
		translate_tank2w_xm+=1;
		translate_tank2w_ym+=1;
		c1=218;
		c2=202;
		c3=12;
 if((translate_tank2w_xm+translate_tank2w_ym) >= power2)

           {
                m--;
                cout<<m;
           }

	}
	else
	{
         c1=244;
		c2=0;
		c3=0;
		translate_tank2w_x = 0;
		translate_tank2w_y = 0;
		translate_tank2w_xm = 0;
		translate_tank2w_ym = 0;
		Mweapon2=false;
		w1x=x2+t2m+t1m;
        m=w1yf;
        if(p1s>p2s)
         winner="Winner player 1";
            else
            winner="Winner player 2";
		//t2m=0;
		if(p2hit)
          p2s+=20;

		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov2==-2)
    {

	if ((translate_tank2w_xm+translate_tank2w_ym) < (power2*2)/5){
		translate_tank2w_x-=2;
		translate_tank2w_y+=3;
		translate_tank2w_xm+=2;
		translate_tank2w_ym+=3;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank2w_xm+translate_tank2w_ym)< (power2*1)/2){
		translate_tank2w_x-=1;
		translate_tank2w_xm+=1;
		translate_tank2w_y+=1;
		translate_tank2w_ym+=1;

		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank2w_xm+translate_tank2w_ym)< (power2*3)/5){
		translate_tank2w_x-=2;
		translate_tank2w_xm+=2;


		c1=218;
		c2=202;
		c3=12;


	}


	else if ((translate_tank2w_xm+translate_tank2w_ym) < power2||m>-30){
		translate_tank2w_x-=2;
		translate_tank2w_y-=3;
		translate_tank2w_xm+=2;
		translate_tank2w_ym+=3;
		c1=218;
		c2=202;
		c3=12;
 if((translate_tank2w_xm+translate_tank2w_ym) >= power2)

           {
                m--;
                cout<<m;
           }

	}
	else
	{
         c1=244;
		c2=0;
		c3=0;
		translate_tank2w_x = 0;
		translate_tank2w_y = 0;
		translate_tank2w_xm = 0;
		translate_tank2w_ym = 0;
		Mweapon2=false;
		w1x=x2+t2m+t1m;
        m=w1yf;
        if(p1s>p2s)
         winner="Winner player 1";
            else
            winner="Winner player 2";
		//t2m=0;
if(p2hit)
          p2s+=20;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov2==-3)
    {

	if ((translate_tank2w_xm+translate_tank2w_ym) < (power2*2)/5){
		translate_tank2w_x-=2;
		translate_tank2w_y+=5;
		translate_tank2w_xm+=2;
		translate_tank2w_ym+=5;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank2w_xm+translate_tank2w_ym)< (power2*3)/5){
		translate_tank2w_x-=2;
		translate_tank2w_xm+=2;
		translate_tank2w_y+=1;
		translate_tank2w_ym+=1;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank2w_xm+translate_tank2w_ym) < power2||m>-30){
		translate_tank2w_x-=2;
		translate_tank2w_y-=5;
		translate_tank2w_xm+=2;
		translate_tank2w_ym+=5;
		c1=218;
		c2=202;
		c3=12;
 if((translate_tank2w_xm+translate_tank2w_ym) >= power2)

           {
                m--;
                cout<<m;
           }

	}
	else
	{
       c1=244;
		c2=0;
		c3=0;
		translate_tank2w_x = 0;
		translate_tank2w_y = 0;
		translate_tank2w_xm = 0;
		translate_tank2w_ym = 0;
		Mweapon2=false;
		w1x=x2+t2m+t1m;
        m=w1yf;
        if(p1s>p2s)
         winner="Winner player 1";
            else
            winner="Winner player 2";
		//t2m=0;
		if(p2hit)
          p2s+=20;
		//t2m=0;
		//t1m=0;
	}
    }
    /////
    else if(smov2==-4)
    {

	if ((translate_tank2w_xm+translate_tank2w_ym)< (power2*2)/5){
		translate_tank2w_x-=1;
		translate_tank2w_y+=5;
		translate_tank2w_xm+=1;
		translate_tank2w_ym+=5;
		c1=218;
		c2=202;
		c3=12;


	}
	else if((translate_tank2w_xm+translate_tank2w_ym) < (power2*3)/5){
		translate_tank2w_x-=1;
		translate_tank2w_xm+=1;
		translate_tank2w_y+=2;
		translate_tank2w_ym+=2;

		c1=218;
		c2=202;
		c3=12;


	}

	else if ((translate_tank2w_xm+translate_tank2w_ym) < power2||m>-30){
		translate_tank2w_x-=1;
		translate_tank2w_y-=5;
			translate_tank2w_xm+=1;
		translate_tank2w_ym+=5;
		c1=218;
		c2=202;
		c3=12;
 if((translate_tank2w_xm+translate_tank2w_ym) >= power2)

           {
                m--;
                cout<<m;
           }

	}
	else
	{
        c1=244;
		c2=0;
		c3=0;
		translate_tank2w_x = 0;
		translate_tank2w_y = 0;
		translate_tank2w_xm = 0;
		translate_tank2w_ym = 0;
		Mweapon2=false;
		w1x=x2+t2m+t1m;
        m=w1yf;
        if(p1s>p2s)
            winner="Winner player 1";
            else
            winner="Winner player 2";
            if(p2hit)
          p2s+=20;
		//t2m=0;
		//t1m=0;
	}
    }
    /////



		glutPostRedisplay();

}

void Movetank1(void){


	if (translate_tank1_x < 35){
		translate_tank1_x++;


	}
	else
	{
		translate_tank1_x = 0;
	}
		glutPostRedisplay();

}
void weapon1()
{  w1x=w1xf;
w1y=w1yf;
    glBegin(GL_POINTS);

	glColor3ub(c1, c2, c3);
		glVertex2i(w1x, w1y);



	glEnd();
	glFlush();

}
void weapon2()
{  w2x=w2xf;
   w2y=w2yf;
    glBegin(GL_POINTS);

	glColor3ub(c1, c2, c3);
		glVertex2i(w2x, w2y);



	glEnd();
	glFlush();

}

void tank2() {
	glBegin(GL_QUADS);

	glColor3ub(99, 29, 50);
		glVertex2i(20, -30);
	glVertex2i(30, -30);
	glVertex2i(30, -25);
	glVertex2i(20, -25);


	glEnd();
	glBegin(GL_QUADS);

	glColor3ub(79, 221, 121);
		glVertex2i(23, -25);
	glVertex2i(27, -25);
	glVertex2i(27, -23);
	glVertex2i(23, -23);


	glEnd();
	glFlush();
	tank2stick();

}
void Movetank2(void){

	if (translate_tank2_x > -35){
		translate_tank2_x--;
	}
	else
		{
			translate_tank2_x = 0;
	}
		glutPostRedisplay();

}
string ints(int x)
{
    if(x==1)
        return "1";
        else  if(x==2)
        return "2";
          else  if(x==3)
        return "3";
          else  if(x==4)
        return "4";
          else  if(x==5)
        return "5";
          else  if(x==6)
        return "6";
          else  if(x==7)
        return "7";
          else  if(x==8)
        return "8";
          else  if(x==9)
        return "9";
          else  if(x==0)
        return "0";
}
void myDisplay()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	//while(rungame==true)
	{
	    glColor3ub(50,100,100);
	drawText(text.data(),text.length(),-5,15);
	glLoadIdentity();
	if(tlp2==0)
	{
	    glColor3ub(150,100,100);
	drawText(winner.data(),winner.length(),-10,25);
	glLoadIdentity();
	rungame=false;
	}
	string te1="Power up w";
	glColor3ub(50,100,100);
	drawText(te1.data(),te1.length(),-5,10);
	glLoadIdentity();
	string te2="Power down s";
	glColor3ub(50,100,100);
	drawText(te2.data(),te2.length(),-5,5);
	glLoadIdentity();
	string te25="Fire d";
	glColor3ub(50,100,100);
	drawText(te25.data(),te25.length(),-5,0);
	glLoadIdentity();
	  string tex="Player 1";
	glColor3ub(50,100,100);
	drawText(tex.data(),tex.length(),-40,40);
	glLoadIdentity();
	string tex1="turn left";

	glColor3ub(50,100,100);
	drawText(tex1.data(),tex1.length(),-40,35);
	glLoadIdentity();
	string tex2=ints(tlp1);
	//int n=5;
	glColor3ub(50,100,100);
	drawText(tex2.data(),tex2.length(),-30,35);
	glLoadIdentity();
	string tex3="power";

	glColor3ub(50,100,100);
	drawText(tex3.data(),tex3.length(),-40,30);
	glLoadIdentity();
	string tex4=ints(power1%10);
	//int n=5;

	glColor3ub(50,100,100);
	drawText(tex4.data(),tex4.length(),-30,30);
	glLoadIdentity();
	string tex5=ints(power1/10);
	//int n=5;

	glColor3ub(50,100,100);
	drawText(tex5.data(),tex5.length(),-32,30);
	glLoadIdentity();
	string tex6="Score";

	glColor3ub(50,100,100);
	drawText(tex6.data(),tex6.length(),-40,25);
	glLoadIdentity();
	string tex7=ints(p1s%10);
	//int n=5;

	glColor3ub(50,100,100);
	drawText(tex7.data(),tex7.length(),-30,25);
	glLoadIdentity();
	string tex8=ints(p1s/10);
	//int n=5;

	glColor3ub(50,100,100);
	drawText(tex8.data(),tex8.length(),-32,25);
	glLoadIdentity();

////////
string texx="Player 2";
	glColor3ub(50,100,100);
	drawText(texx.data(),texx.length(),30,40);
	glLoadIdentity();
	string tex11="turn left";

	glColor3ub(50,100,100);
	drawText(tex11.data(),tex11.length(),30,35);
	glLoadIdentity();
	string tex22=ints(tlp2);
	//int n=5;
	glColor3ub(50,100,100);
	drawText(tex22.data(),tex22.length(),40,35);
	glLoadIdentity();
	string tex33="power";

	glColor3ub(50,100,100);
	drawText(tex33.data(),tex33.length(),30,30);
	glLoadIdentity();
	string tex44=ints(power2%10);
	//int n=5;

	glColor3ub(50,100,100);
	drawText(tex44.data(),tex44.length(),40,30);
	glLoadIdentity();
	string tex55=ints(power2/10);
	//int n=5;

	glColor3ub(50,100,100);
	drawText(tex55.data(),tex55.length(),38,30);
	glLoadIdentity();
	string tex66="Score";

	glColor3ub(50,100,100);
	drawText(tex66.data(),tex66.length(),30,25);
	glLoadIdentity();
	string tex77=ints(p2s%10);
	//int n=5;

	glColor3ub(50,100,100);
	drawText(tex77.data(),tex77.length(),40,25);
	glLoadIdentity();
	string tex88=ints(p2s/10);
	//int n=5;

	glColor3ub(50,100,100);
	drawText(tex88.data(),tex88.length(),38,25);
	glLoadIdentity();
	//******************************************//
	//------- custom code starts -------
/////


////
	glTranslatef(0, 0, translate_z);
	Road();
   // sun();
   // sn();
   //wall();
	glTranslatef(translate_tank1_x, translate_tank1_y, 0);
	tank1();
    tank1stick();
glTranslatef(-translate_tank1_x, translate_tank1_y, 0);

	//glTranslatef(-translate_tank1_x, translate_tank1_y, 0);
	//weapon1();
	glTranslatef(translate_tank2_x, translate_tank1_y, 0);
	tank2();
	glTranslatef(translate_tank1w_x, translate_tank1w_y, 0);
    weapon1();
    glTranslatef(-translate_tank1w_x, -translate_tank1w_y, 0);
    glTranslatef(translate_tank2w_x, translate_tank2w_y, 0);
    weapon2();
    if(Mweapon2)
		Moveweapon2();
        Sleep(80);
	if (movetank1)
		Movetank1();
	Sleep(40);
	if (movetank2)
		Movetank2();
		Sleep(80);
		if(Mweapon1)
		Moveweapon1();


	//------- custom code ends -------
	//******************************************//
	if(bokkor==0)
	{
	    translate_tank2_x+=15;
	    w1xf-=15;
	    w1x-=15;
	    bokkor+=10;
	}

	}

	glutPostRedisplay();
	glutSwapBuffers();

}

void mouse(int button, int state, int x, int y)
{
	switch (button)
	{
	case GLUT_LEFT_BUTTON:
		if (state == GLUT_DOWN)
		if(t1m<4)
		{
		    {
			if (translate_tank1_x < 35){
				translate_tank1_x++;
				w1xf++;
				t1m++;
				w1x=w1xf;
				break;
			}
			else{
				translate_tank1_x = 0;
			}
		}
		}
		break;
	case GLUT_MIDDLE_BUTTON:
		if (state == GLUT_DOWN)
		{
			glutIdleFunc(NULL);
		}
		break;
	case GLUT_RIGHT_BUTTON:
		if (state == GLUT_DOWN){
if(t2m<4)
			if (translate_tank2_x > -35){
				translate_tank2_x--;
				w1xf++;
				t2m++;
				break;
			}
			else{
				translate_tank2_x = 0;
			}
		}
		break;
	default:
		break;
	}
}

void keyboard(unsigned char key, int x, int y)
{
	//-------- translate --------
	if (key == 'd')
	{
	    p1hit=false;
	    p2hit=false;
if(turn1 &&tlp1>0)
{

		Mweapon1=true;

       text="player 2 turn";
       tlp1--;
       turn1=false;
       turn2=true;
}
else if(turn2&&tlp2>0)
{
    Mweapon2=true;
		text="player 1 turn";

		tlp2--;
       turn2=false;
       turn1=true;
}

	}

	else if (key == 'w')
	{
       if(turn1)
		power1++;
		else
		power2++;

	}
	else if (key == 'a')
	{
		movetank2 = true;
	}
	//-------- translate --------
	//-------- zoom --------
	else if (key == 'i')
	{
		translate_z++;
		glutPostRedisplay();
	}
	else if (key == 'o')
	{
		translate_z--;
		glutPostRedisplay();
	}
	else if (key == '4')
	{  if(smov1>-4)
	    {
	        smov1--;
	          w1xf--;
	    w1yf++;
	    y2++;
        x2--;
	glutPostRedisplay();
	    }
		//glutPostRedisplay();
	}
	else if (key == '9')
	{  if(smov2>-4)
	    {
	        smov2--;
	          w2xf++;
	    w2yf++;
	    y22++;
        x22++;
	glutPostRedisplay();
	    }
		//glutPostRedisplay();
	}
	else if (key == '6')
	{if(smov1<3)
	{
	    smov1++;
	    w1xf++;
	    w1yf--;
	    y2--;
	x2++;
	glutPostRedisplay();
	}
	}
	else if (key == '7')
	{if(smov2<3)
	{
	    smov2++;
	    w2xf--;
	    w2yf--;
	    y22--;
	x22--;
	glutPostRedisplay();
	}
	}


		//glutPostRedisplay();

	//-------- zoom --------
	//-------- reset -------
	else if (key == 's')
	{
		if(turn1)
		 power1--;
		 else
		 power2--;

		glutPostRedisplay();
	}
	//-------- reset -------
}



int main(int argc, char** argv)
{  m=w1yf;
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(1024, 768);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Tank War");
	init();

	glutDisplayFunc(myDisplay);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);
	glutMouseFunc(mouse);

	glutMainLoop();
	return 0;
}
