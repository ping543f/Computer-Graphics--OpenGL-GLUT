#include<GL/glut.h>
#include<stdio.h>
#include <iostream>
#include<math.h>
#include<string>
#include "imageloader.h"
using namespace std;

GLuint grassId,sky;
void DrawCircle(float cx, float cy, float r, int num_segments);
char z = 'A';
float rangeX[10]= {0,0,0,0,0,0,0,0,0,0};
float st=55;
int counter=0;
int score=0;
int a[10]= {0,0,0,0,0,0,0,0,0,0};
int ch[10]= {0,0,0,0,0,0,0,0,0,0};
int colorR[10] = {0,0,0,0,0,0,0,0,0,0};
int colorG[10] = {0,0,0,0,0,0,0,0,0,0};
int colorB[10] = {0,0,0,0,0,0,0,0,0,0};

int n=1000;

int health=0;

GLuint loadTexture(Image* image) {
	GLuint textureId;
	glGenTextures(1, &textureId); //Make room for our texture
	glBindTexture(GL_TEXTURE_2D, textureId); //Tell OpenGL which texture to edit
	//Map the image to the texture
	glTexImage2D(GL_TEXTURE_2D,                //Always GL_TEXTURE_2D
				 0,                            //0 for now
				 GL_RGB,                       //Format OpenGL uses for image
				 image->width, image->height,  //Width and height
				 0,                            //The border of the image
				 GL_RGB, //GL_RGB, because pixels are stored in RGB format
				 GL_UNSIGNED_BYTE, //GL_UNSIGNED_BYTE, because pixels are stored
				                   //as unsigned numbers
				 image->pixels);               //The actual pixel data
	return textureId; //Returns the id of the texture
}

void init()
{
    glClearColor(0,0,0,0);
    glShadeModel(GL_SMOOTH);
    glClearDepth(1.0f);
    glEnable(GL_DEPTH_TEST);
    /////////////////////////////////////////////////
    Image* image2 = loadBMP("\/home\/gg\/Music\/game\/skyTexture.bmp");

	grassId = loadTexture(image2);

	delete image2;


	Image* image3 = loadBMP("\/home\/gg\/Music\/game\/skyTexture.bmp");

	sky = loadTexture(image3);

	delete image3;
}

void reset()
{
    for (int l=0; l<10; l++)
    {
        a[l] = 0;
        rangeX[l] = 0;
        ch[l] = 0;
        colorR[l] = 0;
        colorG[l] = 0;
        colorB[l] = 0;
    }
}

void update(int value)
{
    glutPostRedisplay();
    glutTimerFunc(n, update, 0);
}

void reshape(int w,int h)
{
    glViewport(0,0, (GLsizei)w,(GLsizei)h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(100.0f, (GLfloat)w/(GLfloat)h, 1.0f, 100.0f);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void Game()
{

    counter++;
    char c;
    int circleC;

    if (counter%3==0)
    {
        circleC=rand()%10;
    }

    for (int i=0; i<10; i++)
    {
        if (i==circleC)
        {
            a[i]=1;
            ch[i]=rand()%26;
            colorR[i]= rand()%255+2;
            colorG[i]= rand()%255+2;
            colorB[i]= rand()%255+2;
        }
    }

    if (a[0]==1)
    {
        if (rangeX[0]<50)
        {
            rangeX[0]+=5;
        }
        else
        {
            rangeX[0]=0;
            a[0]=0;
            ch[0]=0;
            if (health<8)
            {
                health++;
            }
        }

        //Draw +1st Circle
        //glColor3ub(255, 255, 0);
        glColor3ub(colorR[0], colorG[0], colorB[0]);

        DrawCircle(st-rangeX[0], 30, 5, 200);

        //Draw +1stCharacter on Circle
        glColor3ub(0, 255, 255);

        glRasterPos2i(st-rangeX[0]-1.0, 30);



        c='A';


        c=c+(char)ch[0];

        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, c);
    }

    if (a[1]==1)
    {
        if (rangeX[1]<50)
        {
            rangeX[1]+=5;
        }
        else
        {
            rangeX[1]=0;
            a[1]=0;
            ch[1]=0;
            if (health<8)
            {
                health++;
            }
        }
        //Draw -1st Circle
        glColor3ub(255, 0, 0);

        DrawCircle(-st+rangeX[1], 30, 5, 200);

        //Draw -1stCharacter on Circle
        //glColor3ub(0, 255, 0);
        glColor3ub(colorR[1], colorG[1], colorB[1]);
        glRasterPos2i(-st+rangeX[1]-1.0, 30);

        c='A';

        c=c+(char)ch[1];

        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, c);
    }

    if (a[2]==1)
    {
        if (rangeX[2]<50)
        {
            rangeX[2]+=5;
        }
        else
        {
            rangeX[2]=0;
            a[2]=0;
            ch[2]=0;
            if (health<8)
            {
                health++;
            }
        }
        //Draw +2st Circle
        //glColor3ub(255, 255, 0);
        glColor3ub(colorR[3], colorG[3], colorB[3]);
        DrawCircle(st-rangeX[2], 15, 5, 200);

        //Draw +2stCharacter on Circle
        glColor3ub(0, 255, 255);

        glRasterPos2i(st-rangeX[2]-1.0, 15);

        c='A';

        c=c+(char)ch[2];

        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, c);
    }

    if (a[3]==1)
    {
        if (rangeX[3]<50)
        {
            rangeX[3]+=5;
        }
        else
        {
            rangeX[3]=0;
            a[3]=0;
            ch[3]=0;
            if (health<8)
            {
                health++;
            }
        }
        //Draw -2st Circle
        //glColor3ub(255, 0, 0);
        glColor3ub(colorR[4], colorG[4], colorB[4]);
        DrawCircle(-st+rangeX[3], 15, 5, 200);

        //Draw -2stCharacter on Circle
        glColor3ub(0, 255, 0);

        glRasterPos2i(-st+rangeX[3]-1.0, 15);

        c='A';

        c=c+(char)ch[3];

        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, c);
    }

    if (a[4]==1)
    {
        if (rangeX[4]<50)
        {
            rangeX[4]+=5;
        }
        else
        {
            rangeX[4]=0;
            a[4]=0;
            ch[4]=0;
            if (health<8)
            {
                health++;
            }
        }
        //Draw +3st Circle
        //glColor3ub(255, 0, 0);
        glColor3ub(colorR[4], colorG[4], colorB[4]);
        DrawCircle(st-rangeX[4], 0, 5, 200);

        //Draw +3stCharacter on Circle
        glColor3ub(0, 255, 0);

        glRasterPos2i(st-rangeX[4]-1.0, 0);

        c='A';

        c=c+(char)ch[4];

        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, c);
    }

    if (a[5]==1)
    {
        if (rangeX[5]<50)
        {
            rangeX[5]+=5;
        }
        else
        {
            rangeX[5]=0;
            a[5]=0;
            ch[5]=0;
            if (health<8)
            {
                health++;
            }
        }
        //Draw -3st Circle
        //glColor3ub(255, 0, 0);
        glColor3ub(colorR[5], colorG[5], colorB[5]);
        DrawCircle(-st+rangeX[5], 0, 5, 200);

        //Draw -3stCharacter on Circle
        glColor3ub(0, 255, 0);

        glRasterPos2i(-st+rangeX[5]-1.0, 0);

        c='A';

        c=c+(char)ch[5];

        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, c);
    }

    if (a[6]==1)
    {
        if (rangeX[6]<50)
        {
            rangeX[6]+=5;
        }
        else
        {
            rangeX[6]=0;
            a[6]=0;
            ch[6]=0;
            if (health<8)
            {
                health++;
            }
        }
        //Draw +4st Circle
        //glColor3ub(255, 255, 0);
        glColor3ub(colorR[6], colorG[6], colorB[6]);
        DrawCircle(st-rangeX[6], -15, 5, 200);

        //Draw +4stCharacter on Circle
        glColor3ub(0, 255, 255);

        glRasterPos2i(st-rangeX[6]-1.0, -15);

        c='A';

        c=c+(char)ch[6];

        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, c);
    }

    if (a[7]==1)
    {
        if (rangeX[7]<50)
        {
            rangeX[7]+=5;
        }
        else
        {
            rangeX[7]=0;
            a[7]=0;
            ch[7]=0;
            if (health<8)
            {
                health++;
            }
        }
        //Draw -4st Circle
        //glColor3ub(255, 0, 0);
        glColor3ub(colorR[7], colorG[7], colorB[7]);
        DrawCircle(-st+rangeX[7], -15, 5, 200);

        //Draw -4stCharacter on Circle
        glColor3ub(0, 255, 0);

        glRasterPos2i(-st+rangeX[7]-1.0, -15);

        c='A';

        c=c+(char)ch[7];

        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, c);
    }

    if (a[8]==1)
    {
        if (rangeX[8]<50)
        {
            rangeX[8]+=5;
        }
        else
        {
            rangeX[8]=0;
            a[8]=0;
            ch[8]=0;
            if (health<8)
            {
                health++;
            }
        }
        //Draw +5st Circle
        //glColor3ub(255, 255, 0);
        glColor3ub(colorR[8], colorG[8], colorB[8]);
        DrawCircle(st-rangeX[8], -30, 5, 200);

        //Draw +5stCharacter on Circle
        glColor3ub(0, 255, 255);

        glRasterPos2i(st-rangeX[8]-1.0, -30);

        c='A';

        c=c+(char)ch[8];

        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, c);
    }

    if (a[9]==1)
    {
        if (rangeX[9]<50)
        {
            rangeX[9]+=5;
        }
        else
        {
            rangeX[9]=0;
            a[9]=0;
            ch[9]=0;
            if (health<8)
            {
                health++;
            }
        }
        //Draw -5st Circle
        //glColor3ub(255, 0, 0);
        glColor3ub(colorR[9], colorG[9], colorB[9]);
        DrawCircle(-st+rangeX[9], -30, 5, 200);

        //Draw -5stCharacter on Circle
        glColor3ub(0, 255, 0);

        glRasterPos2i(-st+rangeX[9]-1.0, -30);

        c='A';

        c=c+(char)ch[9];

        glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, c);
    }

    //Draw Middle Rectangle
    glColor3ub(1, 1, 1);
    glBegin(GL_QUADS);

    glVertex2i(-2, -35);
    glVertex2i(2, -35);
    glVertex2i(2, 35);
    glVertex2i(-2, 35);
    glEnd();



    //Health Bar
    glColor3ub(255, 255, 255);
    glBegin(GL_QUADS);

    glVertex2i(-2, -35);
    glVertex2i(2, -35);
    glVertex2i(2, -35+(9*health));
    glVertex2i(-2, -35+(9*health));
    glEnd();
    if(health>=8)
    {
        glColor3ub(0, 0, 0);
    glBegin(GL_QUADS);

    glVertex2i(-55, -50);
    glVertex2i(55, -50);
    glVertex2i(55, 50);
    glVertex2i(-55, 50);
    glEnd();
            //Score display

            glColor3ub(0, 255, 255);

            glRasterPos2i(-10, 0);

            string w;

            w="Score: ";

            for (int u=0; u<w.length(); u++)
            {
                glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, w[u]);
            }
            //

            glColor3ub(0, 255, 255);

            glRasterPos2i(0, 0);

            string s;

            s=to_string(score);

            for (int u=0; u<s.length(); u++)
            {
                glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, s[u]);
            }

        cout<<"Score: "<<score<<endl;
        //exit(0);
    }

    glFlush();
}

void DrawCircle(float cx, float cy, float r, int num_segments)
{

//    glBegin(GL_TRIANGLE_FAN);
//    for (int i = 0; i < num_segments; i++)
//    {
//        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);
//
//        float circX = r * cosf(theta);
//        float circY = r * sinf(theta);
//        glVertex2f(circX + cx, circY + cy);
//
//    }
//    glEnd();

    glBegin(GL_TRIANGLE_FAN);
    for (int i = 0; i < num_segments; i++)
    {
        float theta = 2.0f * 3.1415926f * float(i) / float(num_segments);

        float circX = r * cosf(theta);
        float circY = r * sinf(theta);
        /////////
       // glVertex2f(circX + cx, circY + cy);

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(0, 0, 0, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

	glPushMatrix();


///////////////////////////////////////////////////////////////
    glTranslatef(0, 0, -30);
    	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, sky);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);



	glNormal3f(0.0f, 0.0f, 1.0f);

	//glTexCoord2f(cx, cy);
	glVertex3f(circX + cx, circY + cy, 0.0);
    glTexCoord2f(cx, cy);
    glTexCoord2f(cx+r, cy);

    glTexCoord2f(cx+r, cy+r);
    glTexCoord2f(cx, cy+r);
	/*
	glVertex3f(-55.0, 35.0, 0.0);


	glVertex3f(55.0, 35.0, 0.0);


	glVertex3f(55.0, -35.0, 0.0);
*/




    }

    glEnd();
   //glPopMatrix();

    //glutSwapBuffers();
}

void myDisplay()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearColor(0, 0, 0, 1);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

	glPushMatrix();


///////////////////////////////////////////////////////////////
    glTranslatef(0, 0, -30);
    	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, grassId);


	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);

	glNormal3f(0.0f, 0.0f, 1.0f);

	glTexCoord2f(0.0, 0.0);
	glVertex3f(-55.0, -35.0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3f(-55.0, 35.0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3f(55.0, 35.0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3f(55.0, -35.0, 0.0);

	glEnd();





	//////////////////////////////////////////////////////////////////////////////////

    Game();
    glPopMatrix();

    glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y)
{
    char t='a';
    for (int i=0; i<10; i++)
    {
        if (key==(t+(char)ch[i]))
        {
            a[i]=0;
            ch[i]=0;
            rangeX[i]=0;
            score+=10;
            if (n>150)
            {
                n-=50;
                //cout<<"Speed: "<<n<<endl;
            }
            glutPostRedisplay();
        }
    }
    /*
    if(key=='x')
    {
        glutPostRedisplay();
    }
    else if(key=='r')
    {
        reset();
        glutPostRedisplay();
    }
    */
}

void timer_func(int n)
{
    // Update the object positions, etc.

    glutTimerFunc(n, timer_func, n); // recursively call timer_func
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB | GLUT_ALPHA);
    glutInitWindowSize (900, 700);
    glutInitWindowPosition (0, 0);
    glutCreateWindow ("Typing Test Game");
    init ();
    glutTimerFunc(1000, update, 0); // timer
    timer_func(1000);
    glutDisplayFunc(myDisplay);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
