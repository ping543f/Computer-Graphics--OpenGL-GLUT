/*
 Md.Abu Talha (13-24649-2)
Minhazul Islam Arnob(13-24361-2)
oon gazi sabiha tahsin (13-24403-2)
*/
#include<windows.h>
#include<stdio.h>
#include <stdlib.h>
#include<gl/glut.h>
#include <iostream>
#define SPEED 30.0      //speed of traffic

#define SPEED 30.0



#define SPEED 30.0


float m = 0.0;   //megh
int i=0;
int boat=0;
int l;
int t=0;
int z=1;
int b=0;
int megh=1;
double front=600;
double back=690;
int c_w=615;

double carfront=630;
double carback=670;

double fronttraingle=550;

double front2=600;
double back2=690;
int day=1;
int tree;

int bus=1;


void draw_pixel(GLint cx, GLint cy)
{

	glBegin(GL_POINTS);
	glVertex2i(cx, cy);
	glEnd();
}

void plotpixels(GLint h, GLint k, GLint x, GLint y)
{
	draw_pixel(x + h, y + k);
	draw_pixel(-x + h, y + k);
	draw_pixel(x + h, -y + k);
	draw_pixel(-x + h, -y + k);
	draw_pixel(y + h, x + k);
	draw_pixel(-y + h, x + k);
	draw_pixel(y + h, -x + k);
	draw_pixel(-y + h, -x + k);
}

void draw_circle(GLint h, GLint k, GLint r)
{
	GLint d = 1 - r, x = 0, y = r;
	while (y>x)
	{
		plotpixels(h, k, x, y);
		if (d<0) d += 2 * x + 3;
		else
		{
			d += 2 * (x - y) + 5;
			--y;
		}
		++x;
	}
	plotpixels(h, k, x, y);
}


void draw_object()
{
	int l;

	if (day == 1)
	{
		//sky

	    glColor3f(.2,.6,.8);
		glBegin(GL_POLYGON);
		glVertex2f(0, 450);
		glVertex2f(0, 700);
		glVertex2f(1100, 700);
		glVertex2f(1100, 450);
		glEnd();

		if(m<300)
		{
	//cloud 1
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(160 + m, 625, l);

		}


		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(200 + m, 625, l);
			draw_circle(225 + m, 625, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(265 + m, 625, l);
		}


		//cloud2
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(370 + m, 615, l);
		}

		for (l = 0; l <= 35; l++)
		{

			glColor3f(1.0, 1.0, 1.0);
			draw_circle(410 + m, 615, l);
			draw_circle(435 + m, 615, l);
			draw_circle(470 + m, 615, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(500 + m, 615, l);
		}
		if(megh==1)
		{
		m++;

		}
		}

		else
		{
			m=0;
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(160 + m, 625, l);

		}


		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(200 + m, 625, l);
			draw_circle(225 + m, 625, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(265 + m, 625, l);
		}


		//cloud2
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(370 + m, 615, l);
		}

		for (l = 0; l <= 35; l++)
		{

			glColor3f(1.0, 1.0, 1.0);
			draw_circle(410 + m, 615, l);
			draw_circle(435 + m, 615, l);
			draw_circle(470 + m, 615, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(500 + m, 615, l);
		}
		glEnd();

		if(megh==1)
		{
		m++;
		}
		}


		//sun
		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 0.9, 0.0);
			draw_circle(700,600 , l);
		}



		//mountain cicrle 1
		for (l = 0; l <= 100; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(210 , 370, l);

		}

		///mountain circle 2
		for (l = 0; l <= 100; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(260 , 380, l);

		}
		///mountaincircle 2
		for (l = 0; l <= 100; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(280 , 400, l);

		}
		///mountain circle 3
		for (l = 0; l <= 180; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(380 , 280, l);

		}


		//grass
		glColor3f(.5, 1.0, 0.2);
		glBegin(GL_POLYGON);
		glVertex2f(0, 100);
		glVertex2f(0, 450);
		glVertex2f(1100, 450);
		glVertex2f(1100, 100);
		glEnd();









		//river
		glColor3f(0.0, 0.4, 1.0);
		glBegin(GL_POLYGON);
		glVertex2f(1100, 0);
		glVertex2f(0, 0);
		glVertex2f(0, 160);
		glVertex2f(1100, 160);
		glEnd();

		//river curve

		glColor3f(0.0, 0.4, 1.0);
		glBegin(GL_POLYGON);
		glVertex2f(0, 0);
		glVertex2f(0, 200);
		glVertex2f(200, 160);
		glVertex2f(0, 100);
		glEnd();


		//river circle
		for (l = 0; l <= 150; l++)
		{
			glColor3f(0.0, 0.4, 1.0);
			draw_circle(100 , 30, l);

		}

		if(boat<500)
		{
		//boat bigger part
		glColor3f(0.2, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(647-boat, 66);
		glVertex2f(811-boat, 66);
		glVertex2f(830-boat, 102);
		glVertex2f(588-boat, 102);
		glEnd();
        //boat small part
		glColor3f(0.2, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(815-boat, 102);
		glVertex2f(815-boat, 114);
		glVertex2f(772-boat, 114);
		glVertex2f(772-boat, 102);
		glEnd();

		if(b==0)
		{
		boat=boat+3;
		}
		}
		else
		{
			boat=0;

			//boat bigger part
		glColor3f(0.2, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(647-boat, 66);
		glVertex2f(811-boat, 66);
		glVertex2f(830-boat, 102);
		glVertex2f(588-boat, 102);
		glEnd();
        //boat small part
		glColor3f(0.2, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(815-boat, 102);
		glVertex2f(815-boat, 114);
		glVertex2f(772-boat, 114);
		glVertex2f(772-boat, 102);
		glEnd();

		boat=boat+8;

		}


		//tree body
		glColor3f(0.2, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(387, 199);
		glVertex2f(387, 300);
		glVertex2f(410, 300);
		glVertex2f(411, 200);
		glEnd();



		//tree leaf first quad
		glColor3f(0.13, 0.55, 0.13);
		glBegin(GL_QUADS);
		glVertex2f(336, 285);
		glVertex2f(362, 313);
		glVertex2f(443, 313);
		glVertex2f(466, 285);
		glEnd();


		//tree leaf second quad
		glColor3f(0.13, 0.55, 0.13);
		glBegin(GL_QUADS);
		glVertex2f(342, 313);
		glVertex2f(363, 340);
		glVertex2f(438, 340);
		glVertex2f(458, 313);
		glEnd();


		//tree leaf top triangle
		glColor3f(0.13, 0.55, 0.13);
		glBegin(GL_TRIANGLES);
		glVertex2f(351, 340);
		glVertex2f(400, 410);
		glVertex2f(448, 340);
		glEnd();



		//home front side
		glColor3f(1.0, .7, .5);
		glBegin(GL_POLYGON);
		glVertex2f(780, 360);
		glVertex2f(776, 400);
		glVertex2f(855, 390);
		glVertex2f(860, 340);
		glEnd();

		//tree2 body
		glColor3f(0.2, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(220, 199);
		glVertex2f(220, 300);
		glVertex2f(243, 300);
		glVertex2f(243, 200);
		glEnd();



		//tree2 leaf first quad
		glColor3f(0.13, 0.55, 0.13);
		glBegin(GL_QUADS);
		glVertex2f(169, 285);
		glVertex2f(195, 313);
		glVertex2f(276, 313);
		glVertex2f(299, 285);
		glEnd();


		//tree2 leaf second quad
		glColor3f(0.13, 0.55, 0.13);
		glBegin(GL_QUADS);
		glVertex2f(175, 313);
		glVertex2f(196, 340);
		glVertex2f(271, 340);
		glVertex2f(291, 313);
		glEnd();


		//tree2 leaf top triangle
		glColor3f(0.13, 0.55, 0.13);
		glBegin(GL_TRIANGLES);
		glVertex2f(184, 340);
		glVertex2f(233, 410);
		glVertex2f(281, 340);
		glEnd();



		//home front side
		glColor3f(1.0, .7, .5);
		glBegin(GL_POLYGON);
		glVertex2f(780, 360);
		glVertex2f(776, 400);
		glVertex2f(855, 390);
		glVertex2f(860, 340);
		glEnd();




		//home top

		glColor3f(1.0, 1.0, .2);
		glBegin(GL_POLYGON);
		glVertex2f(767, 400);
		glVertex2f(781, 435);
		glVertex2f(874, 435);
		glVertex2f(852, 384);
		glEnd();


		//home right
		glColor3f(1.0, .7, .5);
		glBegin(GL_POLYGON);
		glVertex2f(860, 340);
		glVertex2f(855, 390);
		glVertex2f(874, 435);
		glVertex2f(896, 404);
		glVertex2f(896, 350);
		glEnd();


		//left window
		glColor3f(1.0, 0.0, .2);
		glBegin(GL_POLYGON);
		glVertex2f(788, 370);
		glVertex2f(787, 380);
		glVertex2f(798, 379);
		glVertex2f(798, 370);
		glEnd();


		//door
		glColor3f(1.0, 0.0, .2);
		glBegin(GL_POLYGON);
		glVertex2f(808, 352);
		glVertex2f(807, 380);
		glVertex2f(820, 378);
		glVertex2f(817, 352);
		glEnd();


		//right window
		glColor3f(1.0, 0.0, .2);
		glBegin(GL_POLYGON);
		glVertex2f(834, 365);
		glVertex2f(833, 375);
		glVertex2f(844, 374);
		glVertex2f(844, 365);
		glEnd();


		//most right window
		//left window
		glColor3f(1.0, 0.0, .2);
		glBegin(GL_POLYGON);
		glVertex2f(873, 370);
		glVertex2f(873, 383);
		glVertex2f(887, 386);
		glVertex2f(887, 372);
		glEnd();

		glutPostRedisplay();









		if(fronttraingle >360)
		{
			for (l = 0; l <= 10; l++)
		{
			glColor3f(1.0, 0.0, 0.0);
			draw_circle(carfront,190 , l);
		}

		   for (l = 0; l <= 10; l++)
		{
			glColor3f(1.0, 0.0, 0.0);
			draw_circle(carback,190 , l);
		}


		glBegin(GL_TRIANGLES);
		glVertex2f(front, 190);
		glVertex2f(fronttraingle, 190);
		glVertex2f(front, 200);
		glEnd();
		glBegin(GL_POLYGON);
		glVertex2f(back, 190);
		glVertex2f(front, 190);
		glVertex2f(front, 240);
		glVertex2f(back, 240);
		glEnd();







		if(z==1)
		{
	    front=front-1;
		back=back-1;
		carfront=carfront-1;
		carback=carback-1;
		fronttraingle=fronttraingle-1;




		}


		}
		else
		{
			  //sky




			{

	    glColor3f(.2,.6,.8);
		glBegin(GL_POLYGON);
		glVertex2f(0, 450);
		glVertex2f(0, 700);
		glVertex2f(1100, 700);
		glVertex2f(1100, 450);
		glEnd();





		//sun
		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 0.0, 0.0);
			draw_circle(700, 625, l);
		}

		if(m<300)
		{
	//cloud 1
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(160 + m, 625, l);

		}


		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(200 + m, 625, l);
			draw_circle(225 + m, 625, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(265 + m, 625, l);
		}


		//cloud2
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(370 + m, 615, l);
		}

		for (l = 0; l <= 35; l++)
		{

			glColor3f(1.0, 1.0, 1.0);
			draw_circle(410 + m, 615, l);
			draw_circle(435 + m, 615, l);
			draw_circle(470 + m, 615, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(500 + m, 615, l);
		}
		if(megh==1)
		{
		m++;
		}
		}
		else
		{
			m=0;
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(160 + m, 625, l);

		}


		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(200 + m, 625, l);
			draw_circle(225 + m, 625, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(265 + m, 625, l);
		}


		//cloud2
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(370 + m, 615, l);
		}

		for (l = 0; l <= 35; l++)
		{

			glColor3f(1.0, 1.0, 1.0);
			draw_circle(410 + m, 615, l);
			draw_circle(435 + m, 615, l);
			draw_circle(470 + m, 615, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(500 + m, 615, l);
		}
		if(megh==1)
		{
		m++;
		}
		}





		//mountain cicrle 1
		for (l = 0; l <= 100; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(210 , 370, l);

		}

		///mountain circle 2
		for (l = 0; l <= 100; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(260 , 380, l);

		}
		///mountaincircle 2
		for (l = 0; l <= 100; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(280 , 400, l);

		}
		///mountain circle 3
		for (l = 0; l <= 180; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(380 , 280, l);

		}


		//grass
		glColor3f(.1, .3, 0.2);
		glBegin(GL_POLYGON);
		glVertex2f(0, 100);
		glVertex2f(0, 450);
		glVertex2f(1100, 450);
		glVertex2f(1100, 100);
		glEnd();

		if(fronttraingle>=500)
		{

		glColor3f(.5, .25, .12);
		glBegin(GL_POLYGON);
		glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();


		}




		//pond
		glColor3f(0.0, 0.4, 1.0);
		glBegin(GL_POLYGON);
		glVertex2f(1100, 0);
		glVertex2f(0, 0);
		glVertex2f(0, 160);
		glVertex2f(1100, 160);
		glEnd();

		//river curve

		glColor3f(0.0, 0.4, 1.0);
		glBegin(GL_POLYGON);
		glVertex2f(0, 0);
		glVertex2f(0, 200);
		glVertex2f(200, 160);
		glVertex2f(0, 100);
		glEnd();


		//river circle
		for (l = 0; l <= 150; l++)
		{
			glColor3f(0.0, 0.4, 1.0);
			draw_circle(100 , 30, l);

		}


		if(boat<450)
		{
		//boat bigger part
		glColor3f(0.2, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(647-boat, 66);
		glVertex2f(811-boat, 66);
		glVertex2f(830-boat, 102);
		glVertex2f(588-boat, 102);
		glEnd();
        //boat small part
		glColor3f(0.2, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(815-boat, 102);
		glVertex2f(815-boat, 114);
		glVertex2f(772-boat, 114);
		glVertex2f(772-boat, 102);
		glEnd();

		boat=boat+5;
		}
		else  /////////////////////////////////////////////////////1 tree
		{


		boat=0;

			//boat bigger part
		glColor3f(0.2, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(647-boat, 66);
		glVertex2f(811-boat, 66);
		glVertex2f(830-boat, 102);
		glVertex2f(588-boat, 102);
		glEnd();
        //boat small part
		glColor3f(0.2, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(815-boat, 102);
		glVertex2f(815-boat, 114);
		glVertex2f(772-boat, 114);
		glVertex2f(772-boat, 102);
		glEnd();

		boat=boat+5;

		}


		//tree2 body
		glColor3f(0.2, 0.0, 0.0);
		glBegin(GL_POLYGON);
		glVertex2f(220, 199);
		glVertex2f(220, 300);
		glVertex2f(243, 300);
		glVertex2f(243, 200);
		glEnd();



		//tree2 leaf first quad
		glColor3f(0.13, 0.55, 0.13);
		glBegin(GL_QUADS);
		glVertex2f(169, 285);
		glVertex2f(195, 313);
		glVertex2f(276, 313);
		glVertex2f(299, 285);
		glEnd();


		//tree2 leaf second quad
		glColor3f(0.13, 0.55, 0.13);
		glBegin(GL_QUADS);
		glVertex2f(175, 313);
		glVertex2f(196, 340);
		glVertex2f(271, 340);
		glVertex2f(291, 313);
		glEnd();


		//tree2 leaf top triangle
		glColor3f(0.13, 0.55, 0.13);
		glBegin(GL_TRIANGLES);
		glVertex2f(184, 340);
		glVertex2f(233, 410);
		glVertex2f(281, 340);
		glEnd();




		//home front side
		glColor3f(1.0, .7, .5);
		glBegin(GL_POLYGON);
		glVertex2f(780, 360);
		glVertex2f(776, 400);
		glVertex2f(855, 390);
		glVertex2f(860, 340);
		glEnd();



		//home top

		glColor3f(1.0, 1.0, .2);
		glBegin(GL_POLYGON);
		glVertex2f(767, 400);
		glVertex2f(781, 435);
		glVertex2f(874, 435);
		glVertex2f(852, 384);
		glEnd();


		//home right
		glColor3f(1.0, .7, .5);
		glBegin(GL_POLYGON);
		glVertex2f(860, 340);
		glVertex2f(855, 390);
		glVertex2f(874, 435);
		glVertex2f(896, 404);
		glVertex2f(896, 350);
		glEnd();


		//left window
		glColor3f(1.0, 0.0, .2);
		glBegin(GL_POLYGON);
		glVertex2f(788, 370);
		glVertex2f(787, 380);
		glVertex2f(798, 379);
		glVertex2f(798, 370);
		glEnd();


		//door
		glColor3f(1.0, 0.0, .2);
		glBegin(GL_POLYGON);
		glVertex2f(808, 352);
		glVertex2f(807, 380);
		glVertex2f(820, 378);
		glVertex2f(817, 352);
		glEnd();


		//right window
		glColor3f(1.0, 0.0, .2);
		glBegin(GL_POLYGON);
		glVertex2f(834, 365);
		glVertex2f(833, 375);
		glVertex2f(844, 374);
		glVertex2f(844, 365);
		glEnd();

		 ///building2 Brown
		if(fronttraingle>=350)
		{
		glColor3f(.5, .25, .12);
		glBegin(GL_POLYGON);
		glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();
		fronttraingle--;
		}

		else if(fronttraingle>=340)
		{
		glColor3f(.5, .25, .12);
		glBegin(GL_POLYGON);
		glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);
		glEnd();
		fronttraingle--;

		}

		else if(fronttraingle>=330)
		{
		glColor3f(.5, .25, .12);
		glBegin(GL_POLYGON);
		glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);

        glVertex2f(650, 400);
		glVertex2f(670, 530);

		glVertex2f(650, 400);
		glVertex2f(700, 448);//ok

		glVertex2f(700, 448);
		glVertex2f(670, 500);

		glVertex2f(665, 500);
        glVertex2f(690, 530);

        glVertex2f(700,400);
        glVertex2f(660,450);

        glVertex2f(660,450);
        glVertex2f(690,500);

        glVertex2f(690,500);
        glVertex2f(670,525);



        glEnd();
		fronttraingle--;

		}
		else if(fronttraingle>=320)
		{
		glColor3f(.5, .25, .12);
		glBegin(GL_POLYGON);
		glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);

        glVertex2f(650, 400);
		glVertex2f(670, 530);

		glVertex2f(650, 400);
		glVertex2f(700, 448);//ok

		glVertex2f(700, 448);
		glVertex2f(670, 500);

		glVertex2f(665, 500);
        glVertex2f(690, 530);

        glVertex2f(700,400);
        glVertex2f(660,450);

        glVertex2f(660,450);
        glVertex2f(690,500);

        glVertex2f(690,500);
        glVertex2f(670,525);



        glEnd();
		fronttraingle--;

		}

		else if(fronttraingle>=310)
		{
		glColor3f(.5, .25, .12);
		glBegin(GL_POLYGON);
		glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);

        glVertex2f(650, 400);
		glVertex2f(670, 530);

		glVertex2f(650, 400);
		glVertex2f(700, 448);//ok

		glVertex2f(700, 448);
		glVertex2f(670, 500);

		glVertex2f(665, 500);
        glVertex2f(690, 530);

        glVertex2f(700,400);
        glVertex2f(660,450);

        glVertex2f(660,450);
        glVertex2f(690,500);

        glVertex2f(690,500);
        glVertex2f(670,525);



        glEnd();

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
		glEnd();

		glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
        glEnd();

		///Door cicrle
		for (l = 0; l <= 32; l++)
		{
			glColor3f(.87, .80, .2);
			draw_circle(668 ,234, l);

		}

		///Windows Middle

		///1

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

		fronttraingle--;

		}

		else if(fronttraingle>=280)
		{
		glColor3f(.5, .25, .12);
		glBegin(GL_POLYGON);
		glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);

        glVertex2f(650, 400);
		glVertex2f(670, 530);

		glVertex2f(650, 400);
		glVertex2f(700, 448);//ok

		glVertex2f(700, 448);
		glVertex2f(670, 500);

		glVertex2f(665, 500);
        glVertex2f(690, 530);

        glVertex2f(700,400);
        glVertex2f(660,450);

        glVertex2f(660,450);
        glVertex2f(690,500);

        glVertex2f(690,500);
        glVertex2f(670,525);



        glEnd();

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
		glEnd();

		glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
        glEnd();

		///Door cicrle
		for (l = 0; l <= 32; l++)
		{
			glColor3f(.87, .80, .2);
			draw_circle(668 ,234, l);

		}

		///Windows Middle

		///1

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

		fronttraingle--;

		}

		else if(fronttraingle>=270)
		{
		glColor3f(.5, .25, .12);
		glBegin(GL_POLYGON);
		glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);

        glVertex2f(650, 400);
		glVertex2f(670, 530);

		glVertex2f(650, 400);
		glVertex2f(700, 448);//ok

		glVertex2f(700, 448);
		glVertex2f(670, 500);

		glVertex2f(665, 500);
        glVertex2f(690, 530);

        glVertex2f(700,400);
        glVertex2f(660,450);

        glVertex2f(660,450);
        glVertex2f(690,500);

        glVertex2f(690,500);
        glVertex2f(670,525);



        glEnd();

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
		glEnd();

		glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
        glEnd();

		///Door cicrle
		for (l = 0; l <= 32; l++)
		{
			glColor3f(.87, .80, .2);
			draw_circle(668 ,234, l);

		}

		///Windows Middle

		///1

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

		///2

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,330 );
		glVertex2f(680,330 );
		glVertex2f(680,350 );
		glVertex2f(650,350 );
		glEnd();

		glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,330 );
		glVertex2f(680,330 );
		glVertex2f(680,350 );
		glVertex2f(650,350 );
		glEnd();

		///3
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,370 );
		glVertex2f(680,370 );
		glVertex2f(680,390 );
		glVertex2f(650,390 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,370 );
		glVertex2f(680,370 );
		glVertex2f(680,390 );
		glVertex2f(650,390 );
		glEnd();


		///WINDOWS Left Near
		//1

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,230 );
		glVertex2f(580,230 );
		glVertex2f(580,250 );
		glVertex2f(610,250 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(610,230 );
		glVertex2f(580,230 );
		glVertex2f(580,250 );
		glVertex2f(610,250 );
		glEnd();

		//2
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,270 );
		glVertex2f(580,270 );
		glVertex2f(580,290 );
		glVertex2f(610,290 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(610,270 );
		glVertex2f(580,270 );
		glVertex2f(580,290 );
		glVertex2f(610,290 );
		glEnd();

		fronttraingle--;

		}

		else if(fronttraingle>=250)
		{
		glColor3f(.5, .25, .12);
		glBegin(GL_POLYGON);
		glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);

        glVertex2f(650, 400);
		glVertex2f(670, 530);

		glVertex2f(650, 400);
		glVertex2f(700, 448);//ok

		glVertex2f(700, 448);
		glVertex2f(670, 500);

		glVertex2f(665, 500);
        glVertex2f(690, 530);

        glVertex2f(700,400);
        glVertex2f(660,450);

        glVertex2f(660,450);
        glVertex2f(690,500);

        glVertex2f(690,500);
        glVertex2f(670,525);



        glEnd();

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
		glEnd();

		glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
        glEnd();

		///Door cicrle
		for (l = 0; l <= 32; l++)
		{
			glColor3f(.87, .80, .2);
			draw_circle(668 ,234, l);

		}

		///Windows Middle

		///1

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

		///2

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,330 );
		glVertex2f(680,330 );
		glVertex2f(680,350 );
		glVertex2f(650,350 );
		glEnd();

		glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,330 );
		glVertex2f(680,330 );
		glVertex2f(680,350 );
		glVertex2f(650,350 );
		glEnd();

		///3
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,370 );
		glVertex2f(680,370 );
		glVertex2f(680,390 );
		glVertex2f(650,390 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,370 );
		glVertex2f(680,370 );
		glVertex2f(680,390 );
		glVertex2f(650,390 );
		glEnd();


		///WINDOWS Left Near
		//1

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,230 );
		glVertex2f(580,230 );
		glVertex2f(580,250 );
		glVertex2f(610,250 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(610,230 );
		glVertex2f(580,230 );
		glVertex2f(580,250 );
		glVertex2f(610,250 );
		glEnd();

		//2
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,270 );
		glVertex2f(580,270 );
		glVertex2f(580,290 );
		glVertex2f(610,290 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(610,270 );
		glVertex2f(580,270 );
		glVertex2f(580,290 );
		glVertex2f(610,290 );
		glEnd();

		 //3
        glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,310 );
		glVertex2f(580,310 );
		glVertex2f(580,330 );
		glVertex2f(610,330 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(610,310 );
		glVertex2f(580,310 );
		glVertex2f(580,330 );
		glVertex2f(610,330 );
		glEnd();

		//4
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,350 );
		glVertex2f(580,350 );
		glVertex2f(580,370 );
		glVertex2f(610,370 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(610,350 );
		glVertex2f(580,350 );
		glVertex2f(580,370 );
		glVertex2f(610,370 );
		glEnd();

		///WINDOWS Right Near

		///1
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,230 );
		glVertex2f(730,230 );
		glVertex2f(730,250 );
		glVertex2f(760,250 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(760,230 );
		glVertex2f(730,230 );
		glVertex2f(730,250 );
		glVertex2f(760,250 );
		glEnd();
		///2
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,270);
		glVertex2f(730,270);
		glVertex2f(730,290);
		glVertex2f(760,290);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(760,270);
		glVertex2f(730,270);
		glVertex2f(730,290);
		glVertex2f(760,290);
		glEnd();
		///3
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,310);
		glVertex2f(730,310);
		glVertex2f(730,330);
		glVertex2f(760,330);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(760,310);
		glVertex2f(730,310);
		glVertex2f(730,330);
		glVertex2f(760,330);
		glEnd();
		///4
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,350);
		glVertex2f(730,350);
		glVertex2f(730,370);
		glVertex2f(760,370);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(760,350);
		glVertex2f(730,350);
		glVertex2f(730,370);
		glVertex2f(760,370);
		glEnd();



		//most right window
		//left window
		glColor3f(1.0, 0.0, .2);
		glBegin(GL_POLYGON);
		glVertex2f(873, 370);
		glVertex2f(873, 383);
		glVertex2f(887, 386);
		glVertex2f(887, 372);
		glEnd();

		fronttraingle--;

		}

		else if(fronttraingle>=191)
		{
		glColor3f(.5, .25, .12);
		glBegin(GL_POLYGON);
		glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);
		glEnd();

		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);

        glVertex2f(650, 400);
		glVertex2f(670, 530);

		glVertex2f(650, 400);
		glVertex2f(700, 448);//ok

		glVertex2f(700, 448);
		glVertex2f(670, 500);

		glVertex2f(665, 500);
        glVertex2f(690, 530);

        glVertex2f(700,400);
        glVertex2f(660,450);

        glVertex2f(660,450);
        glVertex2f(690,500);

        glVertex2f(690,500);
        glVertex2f(670,525);



        glEnd();

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
		glEnd();

		glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
        glEnd();

		///Door cicrle
		for (l = 0; l <= 32; l++)
		{
			glColor3f(.87, .80, .2);
			draw_circle(668 ,234, l);

		}

		///Windows Middle

		///1

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

		///2

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,330 );
		glVertex2f(680,330 );
		glVertex2f(680,350 );
		glVertex2f(650,350 );
		glEnd();

		glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,330 );
		glVertex2f(680,330 );
		glVertex2f(680,350 );
		glVertex2f(650,350 );
		glEnd();

		///3
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,370 );
		glVertex2f(680,370 );
		glVertex2f(680,390 );
		glVertex2f(650,390 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,370 );
		glVertex2f(680,370 );
		glVertex2f(680,390 );
		glVertex2f(650,390 );
		glEnd();


		///WINDOWS Left Near
		//1

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,230 );
		glVertex2f(580,230 );
		glVertex2f(580,250 );
		glVertex2f(610,250 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(610,230 );
		glVertex2f(580,230 );
		glVertex2f(580,250 );
		glVertex2f(610,250 );
		glEnd();

		//2
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,270 );
		glVertex2f(580,270 );
		glVertex2f(580,290 );
		glVertex2f(610,290 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(610,270 );
		glVertex2f(580,270 );
		glVertex2f(580,290 );
		glVertex2f(610,290 );
		glEnd();

		 //3
        glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,310 );
		glVertex2f(580,310 );
		glVertex2f(580,330 );
		glVertex2f(610,330 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(610,310 );
		glVertex2f(580,310 );
		glVertex2f(580,330 );
		glVertex2f(610,330 );
		glEnd();

		//4
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,350 );
		glVertex2f(580,350 );
		glVertex2f(580,370 );
		glVertex2f(610,370 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(610,350 );
		glVertex2f(580,350 );
		glVertex2f(580,370 );
		glVertex2f(610,370 );
		glEnd();

		///WINDOWS Right Near

		///1
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,230 );
		glVertex2f(730,230 );
		glVertex2f(730,250 );
		glVertex2f(760,250 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(760,230 );
		glVertex2f(730,230 );
		glVertex2f(730,250 );
		glVertex2f(760,250 );
		glEnd();
		///2
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,270);
		glVertex2f(730,270);
		glVertex2f(730,290);
		glVertex2f(760,290);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(760,270);
		glVertex2f(730,270);
		glVertex2f(730,290);
		glVertex2f(760,290);
		glEnd();
		///3
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,310);
		glVertex2f(730,310);
		glVertex2f(730,330);
		glVertex2f(760,330);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(760,310);
		glVertex2f(730,310);
		glVertex2f(730,330);
		glVertex2f(760,330);
		glEnd();
		///4
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,350);
		glVertex2f(730,350);
		glVertex2f(730,370);
		glVertex2f(760,370);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(760,350);
		glVertex2f(730,350);
		glVertex2f(730,370);
		glVertex2f(760,370);
		glEnd();



		//most right window
		//left window
		glColor3f(1.0, 0.0, .2);
		glBegin(GL_POLYGON);
		glVertex2f(873, 370);
		glVertex2f(873, 383);
		glVertex2f(887, 386);
		glVertex2f(887, 372);
		glEnd();

		//fronttraingle--;

		}





		///TOWER
		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);

        glVertex2f(650, 400);
		glVertex2f(670, 530);

		glVertex2f(650, 400);
		glVertex2f(700, 448);//ok

		glVertex2f(700, 448);
		glVertex2f(670, 500);

		glVertex2f(665, 500);
        glVertex2f(690, 530);

        glVertex2f(700,400);
        glVertex2f(660,450);

        glVertex2f(660,450);
        glVertex2f(690,500);

        glVertex2f(690,500);
        glVertex2f(670,525);





        glEnd();






		//car
			for (l = 0; l <= 10; l++)
		{
			glColor3f(1.0, 0.0, 0.0);
			draw_circle(carfront,190 , l);
		}

		   for (l = 0; l <= 10; l++)
		{
			glColor3f(1.0, 0.0, 0.0);
			draw_circle(carback,190 , l);
		}



       	if(fronttraingle >191)
		{
		for (l = 0; l <= 10; l++)
		{

			glColor3f(1.0, 0.0, 0.0);
			draw_circle(carfront,190 , l);

		}

		   for (l = 0; l <= 10; l++)
		{
			glColor3f(1.0, 0.0, 0.0);
			draw_circle(carback,190 , l);
		}


		glBegin(GL_TRIANGLES);
		glVertex2f(front, 190);
		glVertex2f(fronttraingle, 190);
		glVertex2f(front, 200);
		glEnd();
		glBegin(GL_POLYGON);
		glVertex2f(back, 190);
		glVertex2f(front, 190);
		glVertex2f(front, 240);
		glVertex2f(back, 240);

	    front=front-4;
		back=back-4;
		carfront=carfront-4;
		carback=carback-4;
		fronttraingle=fronttraingle-4;

		glEnd();

		glutPostRedisplay();
		glFlush();



		}


		else       //////////////////////////////////no tree
		{
			//sky
		glColor3f(.85,.85,.85);
		glBegin(GL_POLYGON);
		glVertex2f(0, 450);
		glVertex2f(0, 700);
		glVertex2f(1100, 700);
		glVertex2f(1100, 450);
		glEnd();


		//sun
		for (l = 0; l <= 35; l++)
		{
			glColor3f(.970, 0.3, .2);
			draw_circle(700, 625, l);
		}

		if(m<300)
		{
	//cloud 1
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(160 + m, 625, l);

		}


		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(200 + m, 625, l);
			draw_circle(225 + m, 625, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(265 + m, 625, l);
		}


		//cloud2
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(370 + m, 615, l);
		}

		for (l = 0; l <= 35; l++)
		{

			glColor3f(1.0, 1.0, 1.0);
			draw_circle(410 + m, 615, l);
			draw_circle(435 + m, 615, l);
			draw_circle(470 + m, 615, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(500 + m, 615, l);
		}
		m++;
		}
		else
		{
			m=0;
				//cloud 1
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(160 + m, 625, l);

		}


		for (l = 0; l <= 35; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(200 + m, 625, l);
			draw_circle(225 + m, 625, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(265 + m, 625, l);
		}


		//cloud2
		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(370 + m, 615, l);
		}

		for (l = 0; l <= 35; l++)
		{

			glColor3f(1.0, 1.0, 1.0);
			draw_circle(410 + m, 615, l);
			draw_circle(435 + m, 615, l);
			draw_circle(470 + m, 615, l);
		}

		for (l = 0; l <= 20; l++)
		{
			glColor3f(1.0, 1.0, 1.0);
			draw_circle(500 + m, 615, l);
		}
		m++;
		}
		//grass
		glColor3f(.45, .45, 0.45);
		glBegin(GL_POLYGON);
		glVertex2f(0, 140);
		glVertex2f(0, 450);
		glVertex2f(1100, 450);
		glVertex2f(1100, 140);
		glEnd();


		//mountain cicrle 1
		for (l = 0; l <= 100; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(210 , 370, l);

		}

		///mountain circle 2
		for (l = 0; l <= 100; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(260 , 380, l);

		}
		///mountaincircle 2
		for (l = 0; l <= 100; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(280 , 400, l);

		}
		///mountain circle 3
		for (l = 0; l <= 180; l++)
		{
			glColor3f(0.6, 0.2, 0.0);
			draw_circle(380 , 280, l);

		}


		///grass
		glColor3f(.45, .45, 0.45);
		glBegin(GL_POLYGON);
		glVertex2f(0, 100);
		glVertex2f(0, 450);
		glVertex2f(1100, 450);
		glVertex2f(1100, 100);
		glEnd();




		///ROAD
		glColor3f(0.20, 0.20, .20);
		glBegin(GL_POLYGON);
		glVertex2f(1100, 0);
		glVertex2f(0, 0);
		glVertex2f(0, 160);
		glVertex2f(1100, 160);
		glEnd();

        ///devider
        glColor3f(1,1,1);
		glBegin(GL_POLYGON);
		glVertex2f(950, 40);
		glVertex2f(730, 40);
		glVertex2f(730, 60);
		glVertex2f(950, 60);
		glEnd();

        glColor3f(1,1,1);
		glBegin(GL_POLYGON);
		glVertex2f(580, 40);
		glVertex2f(340, 40);
		glVertex2f(340, 60);
		glVertex2f(580, 60);
		glEnd();

       glColor3f(1,1,1);
		glBegin(GL_POLYGON);
		glVertex2f(210, 40);
		glVertex2f(40, 40);
		glVertex2f(40, 60);
		glVertex2f(210, 60);
		glEnd();





        ///building1 Dark_pink


		glColor3f(.48, .16, .20);
		glBegin(GL_POLYGON);
		glVertex2f(1000, 200);
		glVertex2f(800, 200);
		glVertex2f(800, 500);
		glVertex2f(1000, 500);
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(1000, 200);
		glVertex2f(800, 200);
		glVertex2f(800, 500);
		glVertex2f(1000, 500);
		glEnd();

		///Antena
		glLineWidth(2);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(865, 500);
		glVertex2f(865, 600);
        glEnd();
        glBegin(GL_LINES);
        glVertex2f(850, 530.33);
		glVertex2f(880, 530.33);
        glEnd();
        glBegin(GL_LINES);
        glVertex2f(853, 545.33);
		glVertex2f(877, 545.33);
        glEnd();
        glBegin(GL_LINES);
        glVertex2f(856, 560.33);
		glVertex2f(874, 560.33);
        glEnd();
        glBegin(GL_LINES);
        glVertex2f(859, 575.33);
		glVertex2f(871, 575.33);
        glEnd();


		///Door

		glColor3f(1.0, 1.0, .0);
		glBegin(GL_POLYGON);
		glVertex2f(983, 200);
		glVertex2f(963, 200);
		glVertex2f(963, 242);
		glVertex2f(983, 242);
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(983, 200);
		glVertex2f(963, 200);
		glVertex2f(963, 242);
		glVertex2f(983, 242);
		glEnd();


		///windows Right
		//1
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(983, 262);
		glVertex2f(963, 262);
		glVertex2f(963, 282);
		glVertex2f(983, 282);
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(983, 262);
		glVertex2f(963, 262);
		glVertex2f(963, 282);
		glVertex2f(983, 282);
		glEnd();


		//2
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(983, 302);
		glVertex2f(963, 302);
		glVertex2f(963, 322);
		glVertex2f(983, 322);
		glEnd();


		//3
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(983, 342);
		glVertex2f(963, 342);
		glVertex2f(963, 362);
		glVertex2f(983, 362);
		glEnd();

		//4
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(983, 382);
		glVertex2f(963, 382);
		glVertex2f(963, 402);
		glVertex2f(983, 402);
		glEnd();


		//5
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(983, 422);
		glVertex2f(963, 422);
		glVertex2f(963, 442);
		glVertex2f(983, 442);
		glEnd();

		///windows Middle

		//1
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(940,222);
		glVertex2f(900,222 );
		glVertex2f(900,242 );
		glVertex2f(940,242 );
		glEnd();

		//2
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(940,262 );
		glVertex2f(900,262 );
		glVertex2f(900,282 );
		glVertex2f(940,282 );
		glEnd();

		//3
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(940,302 );
		glVertex2f(900,302 );
		glVertex2f(900,322 );
		glVertex2f(940,322 );
		glEnd();

		//4
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(940,342 );
		glVertex2f(900,342 );
		glVertex2f(900,362 );
		glVertex2f(940,362 );
		glEnd();


		//5
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(940,382 );
		glVertex2f(900,382 );
		glVertex2f(900,402 );
		glVertex2f(940,402 );
		glEnd();

        //5
        glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(940,422 );
		glVertex2f(900,422 );
		glVertex2f(900,442 );
		glVertex2f(940,442 );
		glEnd();

        ///window Left

        //1
        glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(870,222 );
		glVertex2f(830,222 );
		glVertex2f(830,242 );
		glVertex2f(870,242 );
		glEnd();

		//2
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(870,262 );
		glVertex2f(830,262 );
		glVertex2f(830,282 );
		glVertex2f(870,282 );
		glEnd();

		//3
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(870,302 );
		glVertex2f(830,302 );
		glVertex2f(830,322 );
		glVertex2f(870,322 );
		glEnd();

		//4
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(870,342 );
		glVertex2f(830,342 );
		glVertex2f(830,362 );
		glVertex2f(870,362 );
		glEnd();

		//5
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(870,382 );
		glVertex2f(830,382 );
		glVertex2f(830,402 );
		glVertex2f(870,402 );
		glEnd();

		//6
		glColor3f(1.0, 1., .0);
		glBegin(GL_POLYGON);
		glVertex2f(870,422 );
		glVertex2f(830,422 );
		glVertex2f(830,442 );
		glVertex2f(870,442 );
		glEnd();


		 ///building2 Brown

        glColor3f(.5, .25, .12);
		glBegin(GL_POLYGON);
		glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(830,200 );
		glVertex2f(510,200 );
		glVertex2f(510,400 );
		glVertex2f(830,400 );
		glEnd();

		///TOWER
		glLineWidth(3.5);
		glColor3f(.1, .1, .1);
		glBegin(GL_LINES);
        glVertex2f(700, 400);
		glVertex2f(690, 530);

        glVertex2f(650, 400);
		glVertex2f(670, 530);

		glVertex2f(650, 400);
		glVertex2f(700, 448);//ok

		glVertex2f(700, 448);
		glVertex2f(670, 500);

		glVertex2f(665, 500);
        glVertex2f(690, 530);

        glVertex2f(700,400);
        glVertex2f(660,450);

        glVertex2f(660,450);
        glVertex2f(690,500);

        glVertex2f(690,500);
        glVertex2f(670,525);



        glEnd();

		///DOOR
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(702,200 );
		glVertex2f(635,200 );
		glVertex2f(635,240 );
		glVertex2f(702,240 );
        glEnd();

        ///Door cicrle
		for (l = 0; l <= 32; l++)
		{
			glColor3f(.87, .80, .2);
			draw_circle(668 ,234, l);

		}

		///Windows Middle

		///1

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,290 );
		glVertex2f(680,290 );
		glVertex2f(680,310 );
		glVertex2f(650,310 );
		glEnd();

		///2

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,330 );
		glVertex2f(680,330 );
		glVertex2f(680,350 );
		glVertex2f(650,350 );
		glEnd();

		glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,330 );
		glVertex2f(680,330 );
		glVertex2f(680,350 );
		glVertex2f(650,350 );
		glEnd();

		///3
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(650,370 );
		glVertex2f(680,370 );
		glVertex2f(680,390 );
		glVertex2f(650,390 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(650,370 );
		glVertex2f(680,370 );
		glVertex2f(680,390 );
		glVertex2f(650,390 );
		glEnd();


		///WINDOWS Left Near
		//1

		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,230 );
		glVertex2f(580,230 );
		glVertex2f(580,250 );
		glVertex2f(610,250 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(610,230 );
		glVertex2f(580,230 );
		glVertex2f(580,250 );
		glVertex2f(610,250 );
		glEnd();

		//2
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,270 );
		glVertex2f(580,270 );
		glVertex2f(580,290 );
		glVertex2f(610,290 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(610,270 );
		glVertex2f(580,270 );
		glVertex2f(580,290 );
		glVertex2f(610,290 );
		glEnd();

        //3
        glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,310 );
		glVertex2f(580,310 );
		glVertex2f(580,330 );
		glVertex2f(610,330 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(610,310 );
		glVertex2f(580,310 );
		glVertex2f(580,330 );
		glVertex2f(610,330 );
		glEnd();

		//4
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(610,350 );
		glVertex2f(580,350 );
		glVertex2f(580,370 );
		glVertex2f(610,370 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(610,350 );
		glVertex2f(580,350 );
		glVertex2f(580,370 );
		glVertex2f(610,370 );
		glEnd();

		///WINDOWS Right Near

		///1
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,230 );
		glVertex2f(730,230 );
		glVertex2f(730,250 );
		glVertex2f(760,250 );
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(760,230 );
		glVertex2f(730,230 );
		glVertex2f(730,250 );
		glVertex2f(760,250 );
		glEnd();
		///2
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,270);
		glVertex2f(730,270);
		glVertex2f(730,290);
		glVertex2f(760,290);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(760,270);
		glVertex2f(730,270);
		glVertex2f(730,290);
		glVertex2f(760,290);
		glEnd();
		///3
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,310);
		glVertex2f(730,310);
		glVertex2f(730,330);
		glVertex2f(760,330);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(760,310);
		glVertex2f(730,310);
		glVertex2f(730,330);
		glVertex2f(760,330);
		glEnd();
		///4
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(760,350);
		glVertex2f(730,350);
		glVertex2f(730,370);
		glVertex2f(760,370);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(760,350);
		glVertex2f(730,350);
		glVertex2f(730,370);
		glVertex2f(760,370);
		glEnd();


		///Building3 skyblue
		glColor3f(.8, .8, 1.0);
		glBegin(GL_POLYGON);
		glVertex2f(510,200);
		glVertex2f(460,200);
		glVertex2f(460,530);
		glVertex2f(510,530);
		glEnd();

        glColor3f(.8, .8, 1.0);
		glBegin(GL_POLYGON);
		glVertex2f(580,400);
		glVertex2f(510,400);
		glVertex2f(510,530);
		glVertex2f(580,530);
		glEnd();


        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(510,200);
		glVertex2f(460,200);
		glVertex2f(460,530);
		glVertex2f(580,530);
		glVertex2f(580,400);
		glVertex2f(510,400);
		glEnd();

		///DOOR
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,200);
		glVertex2f(480,200);
		glVertex2f(480,240);
		glVertex2f(490,240);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,200);
		glVertex2f(480,200);
		glVertex2f(480,240);
		glVertex2f(490,240);
		glEnd();

		///Windows
		//1
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,250);
		glVertex2f(480,250);
		glVertex2f(480,260);
		glVertex2f(490,260);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,250);
		glVertex2f(480,250);
		glVertex2f(480,260);
		glVertex2f(490,260);
		glEnd();
		///2
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,280);
		glVertex2f(480,280);
		glVertex2f(480,290);
		glVertex2f(490,290);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,280);
		glVertex2f(480,280);
		glVertex2f(480,290);
		glVertex2f(490,290);
		glEnd();
		///3
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,300);
		glVertex2f(480,300);
		glVertex2f(480,310);
		glVertex2f(490,310);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,300);
		glVertex2f(480,300);
		glVertex2f(480,310);
		glVertex2f(490,310);
		glEnd();
		///4
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,320);
		glVertex2f(480,320);
		glVertex2f(480,330);
		glVertex2f(490,330);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,320);
		glVertex2f(480,320);
		glVertex2f(480,330);
		glVertex2f(490,330);
		glEnd();
		///5
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,340);
		glVertex2f(480,340);
		glVertex2f(480,350);
		glVertex2f(490,350);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,340);
		glVertex2f(480,340);
		glVertex2f(480,350);
		glVertex2f(490,350);
		glEnd();
		///6
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,360);
		glVertex2f(480,360);
		glVertex2f(480,370);
		glVertex2f(490,370);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,360);
		glVertex2f(480,360);
		glVertex2f(480,370);
		glVertex2f(490,370);
		glEnd();
		///7
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,380);
		glVertex2f(480,380);
		glVertex2f(480,390);
		glVertex2f(490,390);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,380);
		glVertex2f(480,380);
		glVertex2f(480,390);
		glVertex2f(490,390);
		glEnd();
		///8
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,400);
		glVertex2f(480,400);
		glVertex2f(480,410);
		glVertex2f(490,410);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,400);
		glVertex2f(480,400);
		glVertex2f(480,410);
		glVertex2f(490,410);
		glEnd();
		///9
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,420);
		glVertex2f(480,420);
		glVertex2f(480,430);
		glVertex2f(490,430);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,420);
		glVertex2f(480,420);
		glVertex2f(480,430);
		glVertex2f(490,430);
		glEnd();
		///10
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,440);
		glVertex2f(480,440);
		glVertex2f(480,450);
		glVertex2f(490,450);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,440);
		glVertex2f(480,440);
		glVertex2f(480,450);
		glVertex2f(490,450);
		glEnd();
        ///11
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,460);
		glVertex2f(480,460);
		glVertex2f(480,470);
		glVertex2f(490,470);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,460);
		glVertex2f(480,460);
		glVertex2f(480,470);
		glVertex2f(490,470);
		glEnd();
		///12
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,480);
		glVertex2f(480,480);
		glVertex2f(480,490);
		glVertex2f(490,490);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,480);
		glVertex2f(480,480);
		glVertex2f(480,490);
		glVertex2f(490,490);
		glEnd();
		///13
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(490,500);
		glVertex2f(480,500);
		glVertex2f(480,510);
		glVertex2f(490,510);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(490,500);
		glVertex2f(480,500);
		glVertex2f(480,510);
		glVertex2f(490,510);
		glEnd();

		///Windows Middle
		///1
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(550,410);
		glVertex2f(530,410);
		glVertex2f(530,430);
		glVertex2f(550,430);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(550,410);
		glVertex2f(530,410);
		glVertex2f(530,430);
		glVertex2f(550,430);
		glEnd();
		///2
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(550,450);
		glVertex2f(530,450);
		glVertex2f(530,470);
		glVertex2f(550,470);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(550,450);
		glVertex2f(530,450);
		glVertex2f(530,470);
		glVertex2f(550,470);
		glEnd();
		///3
		glColor3f(.87, .80, .2);
		glBegin(GL_POLYGON);
		glVertex2f(550,490);
		glVertex2f(530,490);
		glVertex2f(530,510);
		glVertex2f(550,510);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(550,490);
		glVertex2f(530,490);
		glVertex2f(530,510);
		glVertex2f(550,510);
		glEnd();

		///Building4
		glColor3f(.67, .97, .50);
		glBegin(GL_POLYGON);
		glVertex2f(450,200);
		glVertex2f(330,200);
		glVertex2f(330,400);
		glVertex2f(450,400);
		glEnd();

       glLineWidth(2);
       glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(450,200);
		glVertex2f(330,200);
		glVertex2f(330,400);
		glVertex2f(450,400);
		glEnd();

		///DOOr
		glColor3f(.67, .67, .0);
		glBegin(GL_POLYGON);
		glVertex2f(440,200);
		glVertex2f(420,200);
		glVertex2f(420,250);
		glVertex2f(440,250);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(440,200);
		glVertex2f(420,200);
		glVertex2f(420,250);
		glVertex2f(440,250);
		glEnd();

		///windows
		glColor3f(.67, .67, .0);
		glBegin(GL_POLYGON);
		glVertex2f(440,270);
		glVertex2f(400,270);
		glVertex2f(400,285);
		glVertex2f(440,285);
		glEnd();

        glLineWidth(2);
        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(440,270);
		glVertex2f(400,270);
		glVertex2f(400,285);
		glVertex2f(440,285);
		glEnd();

		///2
		glColor3f(.67, .67, .0);
		glBegin(GL_POLYGON);
		glVertex2f(440,305);
		glVertex2f(400,305);
		glVertex2f(400,320);
		glVertex2f(440,320);
		glEnd();

        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(440,305);
		glVertex2f(400,305);
		glVertex2f(400,320);
		glVertex2f(440,320);
		glEnd();
		///3
		glColor3f(.67, .67, .0);
		glBegin(GL_POLYGON);
		glVertex2f(440,340);
		glVertex2f(400,340);
		glVertex2f(400,355);
		glVertex2f(440,355);
		glEnd();

        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(440,340);
		glVertex2f(400,340);
		glVertex2f(400,355);
		glVertex2f(440,355);
		glEnd();
		///4
		glColor3f(.67, .67, .0);
		glBegin(GL_POLYGON);
		glVertex2f(440,375);
		glVertex2f(400,375);
		glVertex2f(400,390);
		glVertex2f(440,390);
		glEnd();

        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(440,375);
		glVertex2f(400,375);
		glVertex2f(400,390);
		glVertex2f(440,390);
		glEnd();

		///Windows left
		///1
		glColor3f(.67, .67, .0);
		glBegin(GL_POLYGON);
		glVertex2f(350,235);
		glVertex2f(370,235);
		glVertex2f(370,250);
		glVertex2f(350,250);
		glEnd();

        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(350,235);
		glVertex2f(370,235);
		glVertex2f(370,250);
		glVertex2f(350,250);
		glEnd();
		///2
		glColor3f(.67, .67, .0);
		glBegin(GL_POLYGON);
		glVertex2f(350,270);
		glVertex2f(370,270);
		glVertex2f(370,285);
		glVertex2f(350,285);
		glEnd();

        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(350,270);
		glVertex2f(370,270);
		glVertex2f(370,285);
		glVertex2f(350,285);
		glEnd();
		///3
		glColor3f(.67, .67, .0);
		glBegin(GL_POLYGON);
		glVertex2f(350,305);
		glVertex2f(370,305);
		glVertex2f(370,320);
		glVertex2f(350,320);
		glEnd();

        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(350,305);
		glVertex2f(370,305);
		glVertex2f(370,320);
		glVertex2f(350,320);
		glEnd();
		///4
		glColor3f(.67, .67, .0);
		glBegin(GL_POLYGON);
		glVertex2f(350,340);
		glVertex2f(370,340);
		glVertex2f(370,355);
		glVertex2f(350,355);
		glEnd();

        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
		glVertex2f(350,340);
		glVertex2f(370,340);
		glVertex2f(370,355);
		glVertex2f(350,355);
		glEnd();
		///5
		glColor3f(.67, .67, .0);
		glBegin(GL_POLYGON);
		glVertex2f(350,375);
		glVertex2f(370,375);
		glVertex2f(370,390);
		glVertex2f(350,390);
		glEnd();

        glColor3f(.1, .1, .1);
        glBegin(GL_LINE_LOOP);
        glVertex2f(350,375);
		glVertex2f(370,375);
		glVertex2f(370,390);
		glVertex2f(350,390);
		glEnd();



		 if(i<750)
	{

    //bus

	glColor3f(0.7, 0.0, 0.9);
	glBegin(GL_POLYGON);
	glVertex2f(350 + i, 50);
	glVertex2f(350 + i, 210);
	glVertex2f(722 + i, 210);
	glVertex2f(750 + i, 150);
	glVertex2f(750 + i, 50);
	glEnd();



	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_POLYGON);
	glVertex2f(650 + i, 150);
	glVertex2f(650 + i, 200);
	glVertex2f(720 + i, 200);
	glVertex2f(745 + i, 150);
	glEnd();



	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_POLYGON);
	glVertex2f(550 + i, 150);
	glVertex2f(550 + i, 200);
	glVertex2f(625 + i, 200);
	glVertex2f(625 + i, 150);
	glEnd();


	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_POLYGON);
	glVertex2f(450 + i, 150);
	glVertex2f(450 + i, 200);
	glVertex2f(525 + i, 200);
	glVertex2f(525 + i, 150);
	glEnd();


	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_POLYGON);
	glVertex2f(375 + i, 150);
	glVertex2f(375 + i, 200);
	glVertex2f(425 + i, 200);
	glVertex2f(425 + i, 150);
	glEnd();

	for (l = 0; l<30; l++)
	{
		glColor3f(0.0, 0.0, 0.0);
		draw_circle(450 + i, 50, l);
		draw_circle(625 + i, 50, l);
	}

	if(bus==1)
	{
		i=i+16;
	}

	}
	else
	{
		i=-400;

		glColor3f(0.7, 0.0, 0.9);
	glBegin(GL_POLYGON);
	glVertex2f(350 + i, 50);
	glVertex2f(350 + i, 275);
	glVertex2f(722 + i, 275);
	glVertex2f(750 + i, 175);
	glVertex2f(750 + i, 50);
	glEnd();



	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_POLYGON);
	glVertex2f(650 + i, 175);
	glVertex2f(650 + i, 260);
	glVertex2f(720 + i, 260);
	glVertex2f(745 + i, 175);
	glEnd();



	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_POLYGON);
	glVertex2f(550 + i, 175);
	glVertex2f(550 + i, 260);
	glVertex2f(625 + i, 260);
	glVertex2f(625 + i, 175);
	glEnd();


	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_POLYGON);
	glVertex2f(450 + i, 175);
	glVertex2f(450 + i, 260);
	glVertex2f(525 + i, 260);
	glVertex2f(525 + i, 175);
	glEnd();


	glColor3f(1.0, 1.0, 1.0);
	glBegin(GL_POLYGON);
	glVertex2f(375 + i, 175);
	glVertex2f(375 + i, 260);
	glVertex2f(425 + i, 260);
	glVertex2f(425 + i, 175);
	glEnd();

	for (l = 0; l<30; l++)
	{
		glColor3f(0.0, 0.0, 0.0);
		draw_circle(450 + i, 50, l);
		draw_circle(625 + i, 50, l);
	}
	if(bus==1)
	{
		i=i+16;
	}

	}


















		glutPostRedisplay();








		glFlush();
		}



}

}

		}
























    }







void mouse(int btn, int state, int x, int y)
{
	if (btn == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
		exit(0);
	else if (btn == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
	{
		bus=1;
	}
	else if (btn == GLUT_MIDDLE_BUTTON && state == GLUT_DOWN)
	{
		megh=1;
	}

}

void keyboardFunc(unsigned char key, int x, int y)
{



	if(key=='a')
    {
     day=1;
     glutPostRedisplay();
    }
	else if(key=='s')
	{
		day=2;
		glutPostRedisplay();
	}
	else if(key=='d')
	{
		day=3;
		glutPostRedisplay();
	}

	else if(key=='f')
	{
		day=4;
		glutPostRedisplay();
	}

	else if(key=='m')
	{
		t=1;
		glutPostRedisplay();
	}

	else if(key=='z')
	{
		z=1;
		glutPostRedisplay();
	}
	else if(key=='x')
	{
		b=1;
		glutPostRedisplay();
	}





		glutPostRedisplay();



}



void myinit()
{
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glColor3f(0.0, 0.0, 1.0);
	glPointSize(2.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, 1100.0, 0.0, 700.0);
}

void display()
{
	glClearColor(1, 1, 1, 1);
	glClear(GL_COLOR_BUFFER_BIT);
	draw_object();
	glFlush();
}


int main(int argc, char** argv)
{

	 glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_ALPHA | GLUT_DEPTH);
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(1100.0, 700.0);
	glutInitWindowPosition(0, 0);

	glutCreateWindow("Deforesation");
	//glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_BLEND);
	glutDisplayFunc(display);
	glutKeyboardFunc(keyboardFunc);
	glutMouseFunc(mouse);
	myinit();




	glutMainLoop();
	return 0;
}
