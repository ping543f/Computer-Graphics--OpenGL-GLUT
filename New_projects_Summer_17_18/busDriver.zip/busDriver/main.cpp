/*
Bus Driving Game
Summer 2016-17
Computer Graphics[B]

SIDDIQUE, MEHEDEE AHMED 14-27119-2
SHADMAN MD TANJIM 14-27378-2
Fatema,Laila Kaniz 13-25007-3
SADIA AKTIA 13-25029-3
*/




#include<windows.h>
#include <GL/glut.h>
#include <stdlib.h>
#include<sstream>
#include<string>
#include<time.h>
using namespace std;
int lanetransform=0;
int running=1;
int busX=932;
int busY=550;
int carX=432;
int carY=-60;
int car1X=587;
int car1Y=-310;
int carTrans=0;
int carTransp=700;
int car2X=732;
int car2Y=750;
int car3X=882;
int car3Y=1100;
int stationX=982;
int stationY=-1500;
int hflag=1;
int score=0;
int scoreflag=1;
void stationed();
void keyboardAction(int key, int x, int y)
{
    switch(key)
    {
        case GLUT_KEY_RIGHT:
            busX+=20;
            glutPostRedisplay();
            break;
        case GLUT_KEY_LEFT:
            busX-=20;
            glutPostRedisplay();
            break;
        case GLUT_KEY_UP:
            busY-=20;
            glutPostRedisplay();
            break;
        case GLUT_KEY_DOWN:
            busY+=20;
            glutPostRedisplay();
            break;
        case GLUT_KEY_END:
            if(running!=2){
                running=2;
            }
            else{
                running=1;
            }
        default:
            break;
    }
}
void human()
{
    int x=1050;
    int y=stationY+20;
    glColor3f(0.824, 0.706, 0.549);
    //glColor3f(0.690, 0.769, 0.871);
    for(int i=0;i<5;i++)
    {
        glBegin(GL_QUADS);
        glVertex2d(x,y);
        glVertex2d(x+10,y);
        glVertex2d(x+10,y+10);
        glVertex2d(x,y+10);
        glEnd();
        y+=20;
    }
}
void station()
{
    glColor3f(0.690, 0.769, 0.871);
    glBegin(GL_POLYGON);
    glVertex2d(stationX,stationY);
    glVertex2d(stationX+100,stationY);
    glVertex2d(stationX+100,stationY+400);
    glVertex2d(stationX,stationY+400);
    glEnd();
    if(running!=0 && running!=2)
    {
        stationY+=10;
    }
    if(stationY>1000)
    {
        hflag=1;
        stationY=-1500;
        if(scoreflag==0)
        {
            scoreflag=1;
        }
    }
    if(hflag==1)
    {
        human();
    }
}
void bus()
{
    if(running==0)
    {
        glColor3f(1, 0.000, 0);
    }
    else if(running==2)
    {
        glColor3f(1,1,0);
    }
    else
    {
        glColor3f(0.580, 0.000, 0.827);
    }
    glBegin(GL_POLYGON);
    glVertex2d(busX,busY);
    glVertex2d(busX+40,busY);
    glVertex2d(busX+40,busY+80);
    glVertex2d(busX,busY+80);
    glEnd();
    glColor3f(0,0,0);
    glBegin(GL_TRIANGLES);
    glVertex2d(busX,busY);
    glVertex2d(busX+40,busY);
    glVertex2d(busX+20,busY-40);
    glVertex2d(busX,busY-40);
    glEnd();
}
///cars in left lane
void car()
{
    glColor3f(0.098, 0.098, 0.439);
    glBegin(GL_POLYGON);
    glVertex2d(carX,carY);
    glVertex2d(carX+40,carY);
    glVertex2d(carX+40,carY+80);
    glVertex2d(carX,carY+80);
    glEnd();
    glColor3f(1,1,1);
    glBegin(GL_TRIANGLES);
    glVertex2d(carX,carY+40);
    glVertex2d(carX+40,carY+40);
    glVertex2d(carX+20,carY+80);
    glVertex2d(carX,carY+80);
    glEnd();
    carY+=10;
    if(carY>1000)
        carY=-60;
}
void car1()
{
    glColor3f(0.000, 0.502, 0.502);
    glBegin(GL_POLYGON);
    glVertex2d(car1X,car1Y);
    glVertex2d(car1X+40,car1Y);
    glVertex2d(car1X+40,car1Y+80);
    glVertex2d(car1X,car1Y+80);
    glEnd();
    glColor3f(0,0,0);
    glBegin(GL_TRIANGLES);
    glVertex2d(car1X,car1Y+40);
    glVertex2d(car1X+40,car1Y+40);
    glVertex2d(car1X+20,car1Y+80);
    glVertex2d(car1X,car1Y+80);
    glEnd();
    car1Y+=18;
    if(car1Y>1000)
        car1Y=-310;

}
///cars in right lane
void car2()
{
    glColor3f(0.863, 0.078, 0.235);
    glBegin(GL_POLYGON);
    glVertex2d(car2X,car2Y);
    glVertex2d(car2X+40,car2Y);
    glVertex2d(car2X+40,car2Y-80);
    glVertex2d(car2X,car2Y-80);
    glEnd();
    glColor3f(0,0,0);
    glBegin(GL_TRIANGLES);
    glVertex2d(car2X,car2Y-40);
    glVertex2d(car2X+40,car2Y-40);
    glVertex2d(car2X+20,car2Y-80);
    glVertex2d(car2X,car2Y-80);
    glEnd();
    car2Y-=20;
    if(car2Y<-900)
        car2Y=700;
}
void car3()
{
    glColor3f(0.098, 0.098, 0.439);
    glBegin(GL_POLYGON);
    glVertex2d(car3X,car3Y);
    glVertex2d(car3X+40,car3Y);
    glVertex2d(car3X+40,car3Y-80);
    glVertex2d(car3X,car3Y-80);
    glEnd();
    glColor3f(1,1,1);
    glBegin(GL_TRIANGLES);
    glVertex2d(car3X,car3Y-40);
    glVertex2d(car3X+40,car3Y-40);
    glVertex2d(car3X+20,car3Y-80);
    glVertex2d(car3X,car3Y-80);
    glEnd();
    car3Y-=25;
    if(car3Y<-900)
        car3Y=700;
}
void laneMove(int running)
{
    if(running==1)
    {
        lanetransform+=20;
        if(lanetransform>100)
            lanetransform=0;
    }
}
void lane()
{
    glColor3f(1,1,1);
    glTranslatef(382,lanetransform,0);
    glBegin(GL_POLYGON);
    glVertex2d(296,-140);
    glVertex2d(304,-140);
    glVertex2d(304,-40);
    glVertex2d(296,-40);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex2d(296,-20);
    glVertex2d(304,-20);
    glVertex2d(304,80);
    glVertex2d(296,80);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex2d(296,100);
    glVertex2d(304,100);
    glVertex2d(304,200);
    glVertex2d(296,200);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex2d(296,120);
    glVertex2d(304,120);
    glVertex2d(304,220);
    glVertex2d(296,220);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex2d(296,240);
    glVertex2d(304,240);
    glVertex2d(304,340);
    glVertex2d(296,340);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex2d(296,360);
    glVertex2d(304,360);
    glVertex2d(304,460);
    glVertex2d(296,460);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex2d(296,480);
    glVertex2d(304,480);
    glVertex2d(304,580);
    glVertex2d(296,580);
    glEnd();
    glBegin(GL_POLYGON);
    glVertex2d(296,600);
    glVertex2d(304,600);
    glVertex2d(304,700);
    glVertex2d(296,700);
    glEnd();
    laneMove(running);
}
void road()
{
    glColor3f(0.184, 0.310, 0.310);
    glBegin(GL_POLYGON);
    glVertex2d(382,0);
    glVertex2d(982,0);
    glVertex2d(982,696);
    glVertex2d(382,696);
    glEnd();
}
void drawGameOver(void * font, char *s, float x, float y){ //score word
     glRasterPos2f(x, y);
	 glColor3f(255, 0, 0);
     for (int i = 0; i < strlen (s); i++)
          glutBitmapCharacter (font, s[i]);
}
void endGame()
{
        running=0;
        glColor3f(1,0,0);
        drawGameOver(GLUT_BITMAP_TIMES_ROMAN_24,"Game OVER!!!",200,100);
}
void stationed()
{
    if(busX>=stationX  && busX<=stationX+100 && busY<=stationY && busY>=stationY-400 && running==2)
    {
        if(scoreflag==1)
        {
            hflag=0;
            score+=20;
            scoreflag=0;
        }
    }
    else if(busX+40>=stationX  && busX+40<=stationX+100 && busY-80<=stationY && busY-80>=stationY-400 && running==2)
    {
        if(scoreflag==1)
        {
            hflag=0;
            score+=20;
            scoreflag=0;
        }
    }
}
bool collision()
{
    if(busX>=car2X  && busX<=car2X+40 && busY<=car2Y && busY>=car2Y-80)
    {
        return true;
    }
    else if(busX+40>=car2X  && busX+40<=car2X+40 && busY-80<=car2Y && busY-80>=car2Y-80)
    {
        return true;
    }
    else if(busX>=carX  && busX<=carX+40 && busY<=carY && busY>=carY-80)
    {
        return true;
    }
    else if(busX+40>=carX  && busX+40<=carX+40 && busY-80<=carY && busY-80>=carY-80)
    {
        return true;
    }
    else if(busX>=car1X  && busX<=car1X+40 && busY<=car1Y && busY>=car1Y-80)
    {
        return true;
    }
    else if(busX+40>=car1X  && busX+40<=car1X+40 && busY-80<=car1Y && busY-80>=car1Y-80)
    {
        return true;
    }
    else if(busX>=car3X  && busX<=car3X+40 && busY<=car3Y && busY>=car3Y-80)
    {
        return true;
    }
    else if(busX+40>=car3X  && busX+40<=car3X+40 && busY-80<=car3Y && busY-80>=car3Y-80)
    {
        return true;
    }
    else if(busX+40>982 && running!=2)
    {
        return true;
    }
     else if(busX<382)
    {
        return true;
    }
    else if(busX<682)
    {
        return true;
    }
    else
    {
        return false;
    }
}
void redraw(int value)
{
    glutPostRedisplay();
    glutTimerFunc(65,redraw,0);
}
void scorec(int value)
{
    if(running!=0)
    {
        score++;
        glutTimerFunc(1000,scorec,0);
    }
}
void myInit(void)
{
    glClearColor(0.486, 0.988, 0.000,0);
	glPointSize(4.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, 1365, 694, 0.0);
}
void drawScoreValue (void * font, int s,int spc, float x, float y)
{ //scoreFunction
     glRasterPos2f(x, y);
	 glColor3f(255, 0, 0);
     int k=0,j=0;
     while(s>9)
        {
            k=s%10;
            glRasterPos2f((x-(j*spc)), y);
            glutBitmapCharacter (font, 48+k);
            j++;
            s=s/10;
        }
        glRasterPos2f((x-(j*spc)), y);
        glutBitmapCharacter (font, 48+s);
}
void drawScore (void * font, char *s, float x, float y){ //score word
     glRasterPos2f(x, y);
	 glColor3f(255, 0, 0);
     for (int i = 0; i < strlen (s); i++)
          glutBitmapCharacter (font, s[i]);
}
void myDisplay(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glPushMatrix();
	road();
	station();
	lane();
	glPopMatrix();
	if(collision())
    {
        score-=2;
	}
	if(score<0)
    {
        endGame();
    }
    if(running==2)
    {
        stationed();
    }
	car();
	car1();
	bus();
	car2();
	car3();
    glRasterPos2i(100, 120);
    glColor3f(1.0f, 1.0f, 1.0f);
	drawScoreValue(GLUT_BITMAP_TIMES_ROMAN_24,score,10,1280,101);
	drawScore(GLUT_BITMAP_TIMES_ROMAN_24,"Score:",1200,100);
	glFlush();
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(1366, 695);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("Bus Driver");
	glutDisplayFunc(myDisplay);
	myInit();
	glutTimerFunc(65,redraw,0);
	glutTimerFunc(1000,scorec,0);
	glutSpecialFunc(keyboardAction);
	//hflag=1;
	glutMainLoop();
	return 0;
}
