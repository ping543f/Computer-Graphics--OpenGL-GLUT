// 15-29982-2	Utshaw, Rafin Akther
// 15-29731-2   Lisa, Tahrifa Tarannum
// 15-30005-2   Rafi, Md.Hasibul Islam
// 15-30035-2    Ahmed, Faisal Bin



#include <iostream>
#include <stdlib.h>


#include <GL/glut.h>


#include "imageloader.h"

using namespace std;

const float BOX_SIZE = 10.0f;
float _angle = 0;            
GLuint _textureId,height,width;
float  scale_x=1,scale_y=1,alightx=1,alighty=1,alightz=1;         

void mouse(int button,int state,int x,int y)
{
	if(state==GLUT_DOWN)
	{
		cout<<"X : "<<x<<"Y : "<<600-y<<endl;
		glPointSize(4.0);
		glBegin(GL_POINTS);
    glColor3f(0.0,0.0,0.0);
    glVertex2i(1,1);
	glEnd();
	//glutPostRedisplay();
	}
}

void handleKeypress(unsigned char key, int x, int y) {
	switch (key) {
		case 27: //Escape key
			exit(0);
	}
}
GLuint sel=0;

void options(int item)
{
	sel=item;
}



GLuint loadTexture(Image* image) {
	GLuint textureId;
	glGenTextures(1, &textureId);
	glBindTexture(GL_TEXTURE_2D, textureId);
	glTexImage2D(GL_TEXTURE_2D,
				 0,
				 GL_RGB,
				 image->width, image->height,
				 0,
				 GL_RGB,
				 GL_UNSIGNED_BYTE,
				 image->pixels);
	width=image->width;
	height=image->height;


	return textureId;
}

void initRendering() {
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);
	glClearColor(1,1,1,1);
	Image* image = loadBMP("bag.bmp");
	
	_textureId = loadTexture(image);
	
	delete image;
}

void handleResize(int w, int h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, (float)w / (float)h, 1.0, 200.0);
}

void drawScene() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	glTranslatef(0.0f, 0.0f, -20.0f);
	
	GLfloat ambientLight[] = {alightx, alighty, alightz, 1.0f};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
	
	glRotatef(-_angle, 0.0f, 0.0f, 1.0f);
	 glScalef(scale_x, scale_y, 1.0f);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, _textureId);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glColor3f(1.0f, 1.0f, 1.0f);
	
	glPushMatrix();
//	glTranslatef(2.0f,0.0f,0.0f);
	glBegin(GL_QUADS);
	
	//Front face
	glNormal3f(0.0, 0.0f, -1.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-BOX_SIZE / 2, -BOX_SIZE / 2, 0);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(BOX_SIZE / 2, -BOX_SIZE / 2,0);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(BOX_SIZE / 2, BOX_SIZE / 2,0);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-BOX_SIZE / 2, BOX_SIZE / 2, 0);
	
	glEnd();
	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
	//glMatrixMode(GL_PROJECTION);
	/*glPushMatrix();
	glBegin(GL_QUADS);
	{
		//glPointSize(4.0);
		glColor3f(.5,.5,.5);
		glVertex2i(0,0);
		glVertex2i(5,0);
		glVertex2i(5,5);
		glVertex2i(0,5);
	}
	glEnd();
	glPopMatrix();*/
	
	glutSwapBuffers();
}

//Called every 25 milliseconds
void update(int value) {
	/*_angle += 1.0f;
	if (_angle > 360) {
		_angle -= 360;
	}*/
	if(sel==1)
	{ sel=0;
		_angle+=90;
	}
	else if(sel==2)
	{sel=0;
		_angle-=90;
	}

	else if(sel==3)
	{sel=0;
		scale_y*=-1;
	}

	else if(sel==4)
	{sel=0;
		scale_x*=-1;
	}
	else if(sel==5)
	{sel=0;
		alightx-=.1;
		alighty-=.1;
		alightz-=.1;
	}
	else if(sel==6)
	{sel=0;
		alightx+=.1;
		alighty+=.1;
		alightz+=.1;
	}
	else if(sel==7)
	{sel=0;
		scale_x*=1.5;
		scale_y*=1.5;
		//scale_z*=1.5;
		
	}
	else if(sel==8)
	{sel=0;
		scale_x*=.5;
		scale_y*=.5;
		//scale_z*=1.5;
		
	}
	if(_angle>360)
	{
		_angle-=360;
	}
	glutPostRedisplay();
	glutTimerFunc(1, update, 0);
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(600, 600);
	
	glutCreateWindow("Putting It All Together - videotutorialsrock.com");
	initRendering();
	
	glutDisplayFunc(drawScene);
	glutKeyboardFunc(handleKeypress);
	glutMouseFunc(mouse);
	glutReshapeFunc(handleResize);
	glutTimerFunc(1, update, 0);
	glutCreateMenu(options);
	glutAddMenuEntry("Rotate 90 degree",1);
	glutAddMenuEntry("Rotate -90 degree",2);
	glutAddMenuEntry("Flip Vertically",3);
	glutAddMenuEntry("Flip Horizontally",4);
	glutAddMenuEntry("Reduce Brightness",5);
	glutAddMenuEntry("Increase Brightness",6);
	glutAddMenuEntry("Zoom in",7);
	glutAddMenuEntry("Zoom out",8);
	glutAddMenuEntry("Move",7);
	glutAttachMenu(GLUT_RIGHT_BUTTON);
	glutMainLoop();
	return 0;
}









