
#include<stdio.h>
#include<windows.h>
#include<GL/glut.h>
#include<iostream>

using namespace std;

int i, q;
int score = 0;
int screen = 0;
bool isCollide = false;
char buffer[10];

int planeX = 200, planeY = 70;
int objectX[4], objectY[4];
int starX[4], starY[4], movd;

void star()
{
	for (i = 0; i < 300; i++)
	{
		glPointSize(1.0);
		glBegin(GL_POINTS);
		glColor3f(1.0, 1.0, 1.0);
		glVertex2f(starX[i], starY[i] + 20);
		glEnd();

		starY[i] = starY[i] - 6;

		if (starY[i] < -30)
		{
			if (rand() % 2 == 0)
			{
				starX[i] = 200;
			}
			else
			{
				starX[i] = 300;
			}
			starY[i] = 600;
		}
	}
}

void drawText(char ch[], int xpos, int ypos)
{
	int numofchar = strlen(ch);
	glLoadIdentity();
	glRasterPos2f(xpos, ypos);
	for (i = 0; i <= numofchar - 1; i++)
	{
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, ch[i]);
	}
}

void drawTextNum(char ch[], int numtext, int xpos, int ypos)
{
	int len;
	int k;
	k = 0;
	len = numtext - strlen(ch);
	glLoadIdentity();
	glRasterPos2f(xpos, ypos);
	for (i = 0; i <= numtext - 1; i++)
	{
		if (i < len)
			glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, '0');
		else
		{
			glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, ch[k]);
			k++;
		}

	}
}

void ovpos()
{
	glClearColor(0, 0, 0, 0);
	for (i = 0; i < 4; i++)
	{
		if (rand() % 2 == 0)
		{
			objectX[i] = 200;
		}
		else
		{
			objectX[i] = 300;
		}
		objectY[i] = 1000 - i * 160;
	}
}

void drawObjects() {
	for (i = 0; i < 4; i++)
	{
		glPointSize(10.0);
		glBegin(GL_TRIANGLE_FAN);
		glColor3ub(rand() % 256, rand() % 256, rand() % 256);
			glVertex2i(objectX[i] - 0, objectY[i] - 0);
			glVertex2i(objectX[i] + 20, objectY[i] -10);
			glVertex2i(objectX[i] + 20, objectY[i] + 10);
			glFlush();

			glVertex2i(objectX[i] - 0, objectY[i] - 0);
			glVertex2i(objectX[i] - 20, objectY[i] + 10);
			glVertex2i(objectX[i] - 20, objectY[i] - 10);
			glFlush();

			glVertex2i(objectX[i] - 0, objectY[i] - 0);
			glVertex2i(objectX[i] + 10, objectY[i] + 20);
			glVertex2i(objectX[i] - 10, objectY[i] + 20);
			glFlush();

			glVertex2i(objectX[i] - 0, objectY[i] - 0);
			glVertex2i(objectX[i] - 10, objectY[i] - 20);
			glVertex2i(objectX[i] + 10, objectY[i] - 20);
			glFlush();

		glEnd();

		objectY[i] = objectY[i] - 8;

		if (objectY[i] > planeY - 30 - 30 && objectY[i] < planeY + 30 + 30 && objectX[i] == planeX)
		{
			isCollide = true;
		}

		if (objectY[i] < -25)
		{
			if (rand() % 2 == 0)
			{
				objectX[i] = 200;
			}
			else
			{
				objectX[i] = 300;
			}
			objectY[i] = 600;
		}
	}
	glFlush();
}

void drawPlane()
{
	glPointSize(10.0);

	glBegin(GL_TRIANGLES);
	glColor3f(0, 1, 0);//left body
	glVertex2f(planeX - 5, planeY + 20);
	glVertex2f(planeX - 25, planeY + 5);
	glVertex2f(planeX - 5, planeY + 7);
	glEnd();

	glBegin(GL_TRIANGLES);
	glColor3f(0, 1, 0);//right body
	glVertex2f(planeX + 5, planeY + 20);
	glVertex2f(planeX + 25, planeY + 5);
	glVertex2f(planeX + 5, planeY + 7);
	glEnd();

	glBegin(GL_TRIANGLES);//up body
	glColor3f(0, 1, 0);
	glVertex2f(planeX - 0, planeY + 40);
	glVertex2f(planeX - 5, planeY + 20);
	glVertex2f(planeX + 5, planeY + 20);
	glEnd();

	glBegin(GL_QUADS);//center body
	glColor3f(0, 1, 0);
	glVertex2f(planeX - 5, planeY + 20);
	glVertex2f(planeX - 5, planeY - 1);
	glVertex2f(planeX + 5, planeY - 1);
	glVertex2f(planeX + 5, planeY + 20);
	glEnd();

	glBegin(GL_QUADS);//down body
	glColor3f(0, 1, 0);
	glVertex2f(planeX - 5, planeY - 1);
	glVertex2f(planeX - 15, planeY - 10);
	glVertex2f(planeX + 15, planeY - 10);
	glVertex2f(planeX + 5, planeY - 1);
	glEnd();
}

void Specialkey(int key, int x, int y)//allow to use navigation key for movement of car
{
	switch (key)
	{
	case GLUT_KEY_UP:
		for (i = 0; i <4; i++)
		{
			objectY[i] = objectY[i] - 10;
		}
		movd = movd - 30;
		break;
	case GLUT_KEY_DOWN:
		for (i = 0; i <4; i++)
		{
			objectY[i] = objectY[i] + 10;
		}
		movd = movd + 30;
		break;
	case GLUT_KEY_LEFT:planeX = 200;
		break;
	case GLUT_KEY_RIGHT:planeX = 300;
		break;

	}
	glutPostRedisplay();
}

void init()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0, 500, 0, 500);
	glMatrixMode(GL_MODELVIEW);
}

void display()
{
	glClear(GL_COLOR_BUFFER_BIT);

	star();
	drawPlane();
	drawObjects();

	movd = movd - 16;

	if (movd < -60)
	{
		movd = 0;
	}

	score = score + 1;
	glColor3f(0, 1, 0);
	drawText("Score : ", 0, 470);
	itoa(score, buffer, 10);
	drawTextNum(buffer, 6, 60, 470);
	glutSwapBuffers();

	for (q = 0; q <= 10000000; q++) { ; }
	if (isCollide == true)
	{
		glColor3f(255, 0, 0);
		drawText("Game Over", 200, 250);
		glutSwapBuffers();
		getchar();
	}
}

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
	glutInitWindowPosition(10, 10);
	glutInitWindowSize(500, 500);
	glutCreateWindow("2D Space Plane Game");
	ovpos();
	init();
	glutDisplayFunc(display);
	glutSpecialFunc(Specialkey);
	glutIdleFunc(display);

	glutMainLoop();
}
