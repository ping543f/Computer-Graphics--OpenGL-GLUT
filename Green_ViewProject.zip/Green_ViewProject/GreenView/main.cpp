//ROY ANINDITA       14-26385-1    Sec: E1
//sikti,soheli akter 14-26184-1
//Sultana,Mafruha    14-26377-1
//Haque,Sharmin      11-19335-2


#include<windows.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>
#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <cmath>
//#include <iomanip>//from refrns_code

float _move_boat1 = 0.00f;
float _speed_boat1 = 0.0025f;
float _move_sun = 1.00f;
float _move_cloud_1 = 0.00f;
float _move_cloud_2 = 0.00f;
float _move_boat = 0.00f;
float _move_dot = 0.00f;
float _move_dot1 = 0.00f;

void update_boat1(int value) {
    if(_speed_boat1>1 || _speed_boat1<0)
    {
        _speed_boat1 = 0.0f;
    }
    _move_boat1 -= _speed_boat1;
    if(_move_boat1 +1.3 < -1.0)
    {
        _move_boat1 = 1.5;
    }
	glutPostRedisplay(); //Notify GLUT that the display has changed

	glutTimerFunc(20, update_boat1, 0); //Notify GLUT to call update again in 25 milliseconds
}
void update_boat(int value) {
    _move_boat += 0.0025f;
    if(_move_boat-.3 > 1.0)
    {
        _move_boat = -1.5;
    }
	glutPostRedisplay();

	glutTimerFunc(20, update_boat, 0);
}
void update_dot(int value) {
    _move_dot += 0.0025f;
    if(_move_dot-1.3 > 1.0)
    {
        _move_dot = -1.5;
    }
	glutPostRedisplay();

	glutTimerFunc(.1, update_dot, 0);
}
void update_sun(int value){
    _move_sun -= 0.00055f;
    if(_move_sun+1.0 < -1.0)
    {
        _move_sun = 1.3;
    }
	glutPostRedisplay();

	glutTimerFunc(20, update_sun, 0);
}
void update_cloud_1(int value) {
    _move_cloud_1 += 0.0025f;
    if(_move_cloud_1-1.3 > 1.0)
    {
        _move_cloud_1 = -1.0;
    }
	glutPostRedisplay(); //Notify GLUT that the display has changed

	glutTimerFunc(20, update_cloud_1, 0); //Notify GLUT to call update again in 20 milliseconds
}
void update_cloud_2(int value){
    _move_cloud_2 -= 0.0025f;
    if(_move_cloud_2+1.3 < -1.0)
    {
        _move_cloud_2 = 1.0;
    }
	glutPostRedisplay(); //Notify GLUT that the display has changed

	glutTimerFunc(20, update_cloud_2, 0);
}
void specialKeys(int key, int x, int y) {
    switch (key) {
      case GLUT_KEY_UP:
          update_boat1(0);
          break;
      case GLUT_KEY_DOWN:
          exit(0);
          break;
    }
}
void keyboard(unsigned char key, int x, int y) {
    switch (key) {
      case 68:
          _speed_boat1+=0.0025f;
          update_boat1(0);
          break;
      case 70:
          _speed_boat1-=0.0025f;
          update_boat1(0);
          break;
    }
}
void sky(){
    //Sky
    if(_move_sun<=1.00f && _move_sun>=0.90f){
        glClear (GL_COLOR_BUFFER_BIT);
        glBegin(GL_QUADS);
        glColor3f(0.529, 0.808, 0.922);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(0.529, 0.808, 0.980);
        glVertex2f(1.0, 0.30);
        glVertex2f(-1.0, -0.30);
        glEnd();
    }
    else if(_move_sun<0.90f && _move_sun>=0.55f){
        glBegin(GL_QUADS);
        glColor3f(0.000, 0.749, 1.000);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(0.8, 1.000, 1.000);
        glVertex2f(1.0, 0.30);
        glVertex2f(-1.0, -0.30);
        glEnd();
    }
    else if(_move_sun<0.55f && _move_sun>=0.35f){
        glBegin(GL_QUADS);
        glColor3f(0.000, 0.749, 1.000);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(1.000, 0.961, 0.933);
        glVertex2f(1.0, 0.30);
        glVertex2f(-1.0, -0.30);
        glEnd();
    }

    else if(_move_sun<0.35f && _move_sun>=0.25f){
        glBegin(GL_QUADS);
        glColor3f(0.529, 0.808, 0.980);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(1.000, 0.855, 0.725);
        glVertex2f(1.0, 0.30);
        glVertex2f(-1.0, -0.30);
        glEnd();
    }

    else if(_move_sun<0.25f && _move_sun>=0.10f){
        glBegin(GL_QUADS);
        glColor3f(0.529, 0.808, 0.980);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(0.957, 0.643, 0.376);
        glVertex2f(1.0, 0.30);
        glVertex2f(-1.0, -0.30);
        glEnd();
    }
    else if(_move_sun<0.10f && _move_sun>=-0.10f){
        glBegin(GL_QUADS);
        glColor3f(1.000, 0.388, 0.278);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(0.957, 0.643, 0.376);
        glVertex2f(1.0, 0.30);
        glVertex2f(-1.0, -0.30);
        glEnd();
    }
    else{
        glBegin(GL_QUADS);
        glColor3f(0.412, 0.412, 0.412);
        glVertex2f(-1.0,1.0);
        glVertex2f(1.0,1.0);

        glColor3f(0.8, 1.000, 1.000);
        glVertex2f(1.0, 0.30);
        glVertex2f(-1.0, -0.30);
        glEnd();

        glPushMatrix();
        glTranslatef(0.0f, _move_sun, 0.0f);
        glTranslatef(0.80,1.05,0);
        glScalef(0.6,1,1);
        glColor3f(0.902, 0.902, 0.980);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(0.95,0.95,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-0.75,0.85,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-0.65,0.65,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(0.65,0.75,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-0.65,0.93,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-0.10,0.67,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(0.15,0.67,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-0.35,0.85,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(0.25,0.73,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(-0.72,0.63,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();
        glTranslatef(0.65,0.73,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0085;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }
}
void sun(){
    //Sun
    glLoadIdentity(); //Reset the drawing perspective
    glMatrixMode(GL_MODELVIEW);
    if(_move_sun<=1.00 && _move_sun>=0.95f){
       glPushMatrix();
        glTranslatef(0.0f, _move_sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 0.647, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else if(_move_sun<0.95f && _move_sun>=0.85f){
        glPushMatrix();
        glTranslatef(0.0f, _move_sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 0.843, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else if(_move_sun<0.85 && _move_sun>=0.65){
        glPushMatrix();
        glTranslatef(0.0f, _move_sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else if(_move_sun<0.65 && _move_sun>=0.45){
        glPushMatrix();
        glTranslatef(0.0f, _move_sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 0.843, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else if(_move_sun<0.45 && _move_sun>=0.25){
        glPushMatrix();
        glTranslatef(0.0f, _move_sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 0.647, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else if(_move_sun<0.25 && _move_sun>=0.10){
        glPushMatrix();
        glTranslatef(0.0f, _move_sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 0.549, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }

    else{
        glPushMatrix();
        glTranslatef(0.0f, _move_sun, 0.0f);
        glScalef(0.6,1,1);
        glColor3f(1.000, 0.271, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.125;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
    }
}
void cloud_left(){
    //Cloud on the left
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(_move_cloud_1, 0.0f, 0.0f);
        glTranslatef(-0.78,0.82,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_1, 0.0f, 0.0f);
        glTranslatef(-0.74,0.87,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_1, 0.0f, 0.0f);
        glTranslatef(-0.70,0.91,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_1, 0.0f, 0.0f);
        glTranslatef(-0.65,0.88,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.07;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_1, 0.0f, 0.0f);
        glTranslatef(-0.61,0.80,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_1, 0.0f, 0.0f);
        glTranslatef(-0.68,0.77,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_1, 0.0f, 0.0f);
        glTranslatef(-0.75,0.78,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
}
void cloud_right(){
    //Cloud on the right
    glLoadIdentity(); //Reset the drawing perspective
	glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glTranslatef(_move_cloud_2, 0.0f, 0.0f);
        glTranslatef(0.78,0.70,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_2, 0.0f, 0.0f);
        glTranslatef(0.74,0.75,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_2, 0.0f, 0.0f);
        glTranslatef(0.70,0.79,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_2, 0.0f, 0.0f);
        glTranslatef(0.65,0.76,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.07;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_2, 0.0f, 0.0f);
        glTranslatef(0.61,0.76,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_2, 0.0f, 0.0f);
        glTranslatef(0.68,0.65,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_2, 0.0f, 0.0f);
        glTranslatef(0.63,0.66,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.075;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();

    glPushMatrix();
    glTranslatef(_move_cloud_2, 0.0f, 0.0f);
        glTranslatef(0.75,0.66,0);
        glScalef(0.6,1,1);
        glColor3f(1.000, 1.000, 1.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.06;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
        glEnd();
        glPopMatrix();
}
void river(){
    glBegin(GL_QUADS);
    glColor3f(0.000, 1.000, 1.000);
    glVertex2f(1.0, 0.30);
    glVertex2f(-1.0, 0.30);
    glVertex2f(-1.0, -0.30);
    glVertex2f(1.0, -0.30);
    glEnd();
}
void dot(){
        glPushMatrix();//start_pushpop
        glTranslatef(_move_dot, 0.0f, 0.0f);
        glTranslatef(0.0, 0.03, 0.0);
        glScalef(0.1, 0.90, 0);
        glPushMatrix();
        glColor3f(0.65, 1., 1.000);
        glBegin(GL_QUADS);
        for(float i = -1; i<=1; i =i+0.25){
        glVertex2f(i,0.30);
        glVertex2f(i,0.29);
        glVertex2f(i+20,0.29);
        glVertex2f(i+20,0.30);
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();//start_pushpop
        glTranslatef(_move_dot, 0.0f, 0.0f);
        glTranslatef(0.0, 0.03, 0.0);
        glScalef(0.1, 0.90, 0);
        glPushMatrix();
        glColor3f(0.65, 1., 1.000);
        glBegin(GL_QUADS);
        for(float i = -10; i<=-5; i =i+0.25){
        glVertex2f(i,0.26);
        glVertex2f(i,0.25);
        glVertex2f(i+1,0.25);
        glVertex2f(i+1,0.26);
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();//start_pushpop
        glTranslatef(_move_dot, 0.0f, 0.0f);
        glTranslatef(0.0, 0.03, 0.0);
        glScalef(0.1, 0.90, 0);
        glPushMatrix();
        glColor3f(0.65, 1., 1.000);
        glBegin(GL_QUADS);
        for(float i = -14; i<=-4; i =i+0.25){
        glVertex2f(i,0.20);
        glVertex2f(i,0.19);
        glVertex2f(i+1,0.19);
        glVertex2f(i+1,0.20);
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();//start_pushpop
        glTranslatef(_move_dot, 0.0f, 0.0f);
        glTranslatef(0.0, 0.03, 0.0);
        glScalef(0.1, 0.90, 0);
        glPushMatrix();
        glColor3f(0.65, 1., 1.000);
        glBegin(GL_QUADS);
        for(float i = -16; i<=-8; i =i+0.25){
        glVertex2f(i,0.15);
        glVertex2f(i,0.14);
        glVertex2f(i+1,0.14);
        glVertex2f(i+1,0.15);
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();//start_pushpop
        glTranslatef(_move_dot, 0.0f, 0.0f);
        glTranslatef(0.0, 0.03, 0.0);
        glScalef(0.1, 0.90, 0);
        glPushMatrix();
        glColor3f(0.65, 1., 1.000);
        glBegin(GL_QUADS);
        for(float i = -12; i<=-6; i =i+0.25){
        glVertex2f(i,0.10);
        glVertex2f(i,0.09);
        glVertex2f(i+1,0.09);
        glVertex2f(i+1,0.10);
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();//start_pushpop
        glTranslatef(_move_dot, 0.0f, 0.0f);
        glTranslatef(0.0, 0.03, 0.0);
        glScalef(0.1, 0.90, 0);
        glPushMatrix();
        glColor3f(0.65, 1., 1.000);
        glBegin(GL_QUADS);
        for(float i = -6; i<=2; i =i+0.25){
        glVertex2f(i,0.05);
        glVertex2f(i,0.04);
        glVertex2f(i+1,0.04);
        glVertex2f(i+1,0.05);
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();//start_pushpop
        glTranslatef(_move_dot, 0.0f, 0.0f);
        glTranslatef(0.0, 0.03, 0.0);
        glScalef(0.1, 0.90, 0);
        glPushMatrix();
        glColor3f(0.65, 1., 1.000);
        glBegin(GL_QUADS);
        for(float i = -1; i<=4; i =i+0.25){
        glVertex2f(i,-0.02);
        glVertex2f(i,-0.03);
        glVertex2f(i+1,-0.03);
        glVertex2f(i+1,-0.02);
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();//start_pushpop
        glTranslatef(_move_dot, 0.0f, 0.0f);
        glTranslatef(0.0, 0.03, 0.0);
        glScalef(0.1, 0.90, 0);
        glPushMatrix();
        glColor3f(0.65, 1., 1.000);
        glBegin(GL_QUADS);
        for(float i = 1; i<=6; i =i+0.25){
        glVertex2f(i,-0.07);
        glVertex2f(i,-0.08);
        glVertex2f(i+1,-0.08);
        glVertex2f(i+1,-0.07);
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();//start_pushpop
        glTranslatef(_move_dot, 0.0f, 0.0f);
        glTranslatef(0.0, 0.03, 0.0);
        glScalef(0.1, 0.90, 0);
        glPushMatrix();
        glColor3f(0.65, 1., 1.000);
        glBegin(GL_QUADS);
        for(float i = 3; i<=5; i =i+0.25){
        glVertex2f(i,-0.15);
        glVertex2f(i,-0.16);
        glVertex2f(i+1,-0.16);
        glVertex2f(i+1,-0.15);
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();//start_pushpop
        glTranslatef(_move_dot, 0.0f, 0.0f);
        glTranslatef(0.0, 0.03, 0.0);
        glScalef(0.1, 0.90, 0);
        glPushMatrix();
        glColor3f(0.65, 1., 1.000);
        glBegin(GL_QUADS);
        for(float i =4; i<=7; i =i+0.25){
        glVertex2f(i,-0.24);
        glVertex2f(i,-0.25);
        glVertex2f(i+1,-0.25);
        glVertex2f(i+1,-0.24);
        }
        glEnd();
        glPopMatrix();

        glPushMatrix();//start_pushpop
        glTranslatef(_move_dot, 0.0f, 0.0f);
        glTranslatef(0.0, 0.03, 0.0);
        glScalef(0.1, 0.90, 0);
        glPushMatrix();
        glColor3f(0.65, 1., 1.000);
        glBegin(GL_QUADS);
        for(float i = 6; i<=8; i =i+0.25){
        glVertex2f(i,-0.28);
        glVertex2f(i,-0.29);
        glVertex2f(i+1,-0.29);
        glVertex2f(i+1,-0.28);
        }
        glEnd();
        glPopMatrix();
}
void boat(){
        glPushMatrix();//start_pushpop
    glTranslatef(_move_boat, 0.0f, 0.0f);
        glTranslatef(0.0, 0.15, 0.0);
        glScalef(0.55, 0.55, 0);
        glPushMatrix();
        glColor3f(0.647, 0.165, 0.165);
        glBegin(GL_QUADS);
        glVertex2f(0.35, 0.20);
        glVertex2f(0.75, 0.20);
        glVertex2f(0.95, 0.30);
        glVertex2f(0.15, 0.30);

        glEnd();
        glPopMatrix();
    glPushMatrix();
    glTranslatef(_move_boat, 0.0f, 0.0f);
        glTranslatef(0.12, 0.16, 0.0);
        glScalef(0.50, 0.50, 0);
        glColor3f(0.948,0.934,0.734);
        glBegin(GL_QUADS);
        glVertex2f(0.70, 0.30);
        glVertex2f(0.10, 0.30);
        glVertex2f(0.10, 0.45);
        glVertex2f(0.70, 0.45);

        glEnd();
        glPopMatrix();

}
void boat1(){
    glPushMatrix();//start_pushpop
    glTranslatef(_move_boat1, 0.0f, 0.0f);
        glColor3f(0.647, 0.165, 0.165);
        glBegin(GL_POLYGON);
        glVertex2f(0.75, -0.20);
        glVertex2f(0.45, -0.20);
        glVertex2f(0.40, -0.05);
        glVertex2f(0.80, -0.05);
        glEnd();
        glPopMatrix();
    glPushMatrix();//start_pushpop
    glTranslatef(_move_boat1, 0.0f, 0.0f);
        glColor3f(0.529, 0.808, 0.922);
        glBegin(GL_POLYGON);
        glVertex2f(0.75, -0.05);
        glVertex2f(0.45, -0.05);
        glVertex2f(0.45, 0.10);
        glVertex2f(0.75, 0.10);
        glEnd();
        glPopMatrix();
}
void tree(){
    //Park Tree 1
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(-0.84, -0.65);
    glVertex2f(-0.81, -0.65);
    glVertex2f(-0.82, -0.45);
    glVertex2f(-0.83, -0.45);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.196, 0.804, 0.196);
    glVertex2f(-0.88, -0.50);
    glVertex2f(-0.77, -0.50);
    glVertex2f(-0.825, -0.30);
    glVertex2f(-0.88, -0.50);
    glEnd();

    //Park Tree 2
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(-0.59, -0.65);
    glVertex2f(-0.56, -0.65);
    glVertex2f(-0.57, -0.45);
    glVertex2f(-0.58, -0.45);
    glEnd();

    glPushMatrix();
        glTranslatef(-0.595,-0.45,0);
        glScalef(0.6,1,1);
        glColor3f(0.000, 1.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-0.555,-0.45,0);
        glScalef(0.6,1,1);
        glColor3f(0.000, 1.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-0.575,-0.385,0);
        glScalef(0.6,1,1);
        glColor3f(0.000, 1.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    //Park Tree 3
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(-0.34, -0.65);
    glVertex2f(-0.31, -0.65);
    glVertex2f(-0.32, -0.45);
    glVertex2f(-0.33, -0.45);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.196, 0.804, 0.196);
    glVertex2f(-0.38, -0.50);
    glVertex2f(-0.27, -0.50);
    glVertex2f(-0.325, -0.30);
    glVertex2f(-0.38, -0.50);
    glEnd();

    //Flower Three 1
    glPushMatrix();
        glTranslatef(-0.20, -0.625,0);
        glScalef(0.6,1,1);
        glColor3f(0.824, 0.412, 0.118);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-0.22, -0.625,0);
        glScalef(0.6,1,1);
        glColor3f(0.824, 0.412, 0.118);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-0.24, -0.595,0);
        glScalef(0.6,1,1);
        glColor3f(0.133, 0.545, 0.133);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0425;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-0.18, -0.595,0);
        glScalef(0.6,1,1);
        glColor3f(0.133, 0.545, 0.133);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0425;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(-0.210, -0.570,0);
        glScalef(0.6,1,1);
        glColor3f(0.133, 0.545, 0.133);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0435;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    //Flower Three 2
    glPushMatrix();
        glTranslatef(0.20, -0.625,0);
        glScalef(0.6,1,1);
        glColor3f(0.824, 0.412, 0.118);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.22, -0.625,0);
        glScalef(0.6,1,1);
        glColor3f(0.824, 0.412, 0.118);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.030;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.24, -0.595,0);
        glScalef(0.6,1,1);
        glColor3f(0.133, 0.545, 0.133);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0425;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.18, -0.595,0);
        glScalef(0.6,1,1);
        glColor3f(0.133, 0.545, 0.133);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0425;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.210, -0.570,0);
        glScalef(0.6,1,1);
        glColor3f(0.133, 0.545, 0.133);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.0435;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

     //Park Tree 4
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(0.34, -0.65);
    glVertex2f(0.31, -0.65);
    glVertex2f(0.32, -0.45);
    glVertex2f(0.33, -0.45);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.196, 0.804, 0.196);
    glVertex2f(0.38, -0.50);
    glVertex2f(0.27, -0.50);
    glVertex2f(0.325, -0.30);
    glVertex2f(0.38, -0.50);
    glEnd();

    //Park Tree 5
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(0.59, -0.65);
    glVertex2f(0.56, -0.65);
    glVertex2f(0.57, -0.45);
    glVertex2f(0.58, -0.45);
    glEnd();

    glPushMatrix();
        glTranslatef(0.595,-0.45,0);
        glScalef(0.6,1,1);
        glColor3f(0.000, 1.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.555,-0.45,0);
        glScalef(0.6,1,1);
        glColor3f(0.000, 1.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    glPushMatrix();
        glTranslatef(0.575,-0.385,0);
        glScalef(0.6,1,1);
        glColor3f(0.000, 1.000, 0.000);
        glBegin(GL_POLYGON);
        for(int i=0;i<200;i++)
        {
            float pi=3.1416;
            float A=(i*2*pi)/200;
            float r=0.065;
            float x = r * cos(A);
            float y = r * sin(A);
            glVertex2f(x,y );
        }
    glEnd();
    glPopMatrix();

    //Park Tree 5
    glBegin(GL_POLYGON);
    glColor3f(0.824, 0.412, 0.118);
    glVertex2f(0.84, -0.65);
    glVertex2f(0.81, -0.65);
    glVertex2f(0.82, -0.45);
    glVertex2f(0.83, -0.45);
    glEnd();

    glBegin(GL_POLYGON);
    glColor3f(0.196, 0.804, 0.196);
    glVertex2f(0.88, -0.50);
    glVertex2f(0.77, -0.50);
    glVertex2f(0.825, -0.30);
    glVertex2f(0.88, -0.50);
    glEnd();
}
void field(){
    //field 1
    glBegin(GL_QUADS);
    glColor3f(0.498, 1.000, 0.000);
    glVertex2f(1.0, -0.30);
    glVertex2f(-1.0, -0.30);
    glVertex2f(-1.0, -1);
    glVertex2f(1.0, -1);
    glEnd();
}
void myDisplay(void){
    glLoadIdentity();
    sky();
    sun();
    river();
    dot();
    boat();
    boat1();
    cloud_left();
    cloud_right();
     field();
    tree();
    glFlush();
}

void myInit (void){
    glClearColor(1.0, 1.0, 1.0, 0.0);
    glColor3f(0.0f, 0.0f, 0.0f);
    glPointSize(4.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0.0, 1.0, 0.0, 1.0);
}
int main(int argc, char** argv){
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize (1366, 768);
    glutInitWindowPosition (0, 0);
    glutCreateWindow ("village");
    glutDisplayFunc(myDisplay);
    glutSpecialFunc(specialKeys);
    glutKeyboardFunc(keyboard);
    glutTimerFunc(20, update_cloud_1, 0);
    glutTimerFunc(20, update_cloud_2, 0);
    glutTimerFunc(20, update_sun, 0);
    glutTimerFunc(25, update_boat, 0);
    glutTimerFunc(1, update_dot, 0);
    myInit ();
    glutMainLoop();
}
